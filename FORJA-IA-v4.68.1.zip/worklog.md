---
Task ID: 2
Agent: Super Z (main agent)
Task: Prism AI v2 — solo modelos gratis, vista previa en vivo, biblioteca de prompts, adjuntar imágenes, skills instalables, fix de bucle degenerado y fix de SW con caché vieja.

Work Log:
- Verifiqué con la doc oficial que AiHubMix subsidia 27+ modelos gratis con sufijo «-free» (gpt-5.5-free, gpt-4.1-mini-free, gemini-3-flash-preview-free, glm-4.7-flash-free, deepseek-v3-free…). OpenRouter usa «:free»; Gemini/Groq/Ollama capa gratuita completa.
- Motor de gratis: src/lib/prism/free-models.ts (isFreeModel/filterFreeModels + CURATED_FREE). types.ts: settings.onlyFree (default true) + MAX_RENDER_CHARS=8000. providers.ts: defaultModels solo gratis + taglines actualizadas. store.ts: merge profundo para migraciones.
- model-picker.tsx: interruptor «Solo gratis», badges GRATIS, pie «N de M (filtro gratis)», buscador por texto.
- settings-dialog.tsx: switch «Solo modelos gratis» en Chat; al cargar modelos muestra «N gratis de M».
- Vista previa en vivo: lib/prism/preview.ts (extractPreviewHtml detecta ```html cerrado o en curso y doctype suelto), components/prism/preview-panel.tsx (iframe sandbox allow-scripts, debounce 400ms en streaming, badge EN VIVO, escritorio/móvil 390px, recargar, ver código, abrir pestaña, descargar .html), chat-app.tsx integra split ResizablePanelGroup (55/45) + Sheet en móvil + auto-apertura al detectar HTML.
- Adjuntos: lib/prism/attachments.ts (redimensiona a 1152px, JPEG/PNG, guarda GIF pequeños tal cual), chat-input.tsx (ImagePlus, pegar desde portapapeles, miniaturas size-16 con quitar), chat-client.ts multimodal para openai (image_url), anthropic (image base64) y gemini (inlineData); message.tsx miniaturas size-24 clicables.
- Biblioteca de prompts: lib/prism/prompts-data.ts (12 integrados en 5 categorías), prompt-library.tsx (buscar, filtrar, crear, eliminar, insertar en input), accesos en chat-input y sidebar.
- Skills: lib/prism/skills-data.ts (6 integradas, Desarrollador web experto activada por defecto), skills-dialog.tsx (activar/desinstalar/crear), chat-app compone systemPrompt + skills activas.
- Fix del error reportado (bucle "strapon"): message.tsx recorta render a 8000 chars con «Mostrar todo», detecta bucle degenerado por repetición y muestra aviso con sugerencia de regenerar; razonamiento limitado a 4000.
- FIX CRÍTICO: el SW v3 cache-first servía CSS/JS viejos tras actualizaciones (por eso el usuario veía la versión antigua). sw.js v4: todo network-first con fallback a caché, activate purga caches v3.
- E2E agent-browser: filtro gratis (2 de 4), vista previa EN VIO renderizando página generada y JS del sandbox funcional (contador=3), biblioteca inserta prompts, skills lista y switch, imagen adjunta via DataTransfer → proxy → mock multimodal responde (image_url). Lint y tsc limpios tras fixes (set-state-in-effect, regex s-flag, disables sobrantes).
- Empaquetado: download/prism-ai-v2-codigo-fuente.zip (src, public, prisma, scripts, examples).

Stage Summary:
- Prism AI v2 entregada y verificada E2E: solo modelos gratis por defecto, vista previa en tiempo real de páginas que genera la IA, biblioteca de prompts, skills instalables, imágenes multimodales, protección anti-bucle y SW que siempre entrega la versión nueva.
- Clave del bug reportado: bucle degenerado del modelo + render sin límite → resuelto con clamp/aviso; además SW v4 evita versiones viejas en caché.

---
Task ID: 3
Agent: Super Z (main agent)
Task: Prism AI v2.1 — modo agente con bucles (plan→ejecutar→revisar, método iterativo estilo Claude Code) + mapa del proyecto para ahorrar tokens.

Work Log:
- Modo agente: lib/prism/agent-loop.ts con agentPrompt(maxLoops) — instruye al modelo a estructurar la respuesta en <plan>, <step n title>, <review pass>, <answer> y <project-map>. parseAgentTrace() hace streaming-parse tolerante (etiqueta final sin cerrar = open:true) y agrupa step+review en iteraciones del bucle.
- UI del bucle: components/prism/agent-trace.tsx — tarjeta «PLAN DEL AGENTE» (lista violeta), tarjetas «ITERACIÓN n» plegables con el código ejecutado, chip «Repetir bucle:» (ámbar, pass=no) / «Revisión superada» (esmeralda, pass=yes), respuesta final AgentAnswer destacada. ClampText por bloque (6000/8000) hereda la protección anti-bucle.
- message.tsx: si parseAgentTrace(content).active, renderiza la línea de tiempo en vez del markdown crudo (las etiquetas XML nunca se muestran); si no hay estructura, render normal (regresión verificada).
- Toggle del agente: chat-input.tsx añade botón IterationCw (violeta cuando está activo, aria-pressed) y placeholder «Agente activo: planear → ejecutar → revisar en bucles…». settings.agentMode + settings.agentMaxLoops (1-8, default 3) persistidos y editables en Ajustes → Chat.
- Mapa del proyecto: lib/prism/project-map.ts — deriveProjectMap(extrae título/h1/nav/botones/tech del HTML), deriveMapFromMessages (acumula últimos 20 assistant), parseMapJson + mergeProjectMap (gana el modelo, une features y archivos por nombre), renderMapForPrompt (bloque compacto ≤1400 chars inyectado en el system prompt de cada turno → la IA «recuerda» el proyecto sin releer código, ahorra tokens).
- types.ts/store.ts: ProjectMap + Session.projectMap + acción setProjectMap; el mapa viaja en sessions (persist/export automático).
- Panel: preview-panel.tsx ahora con 3 pestañas (Vista/Código/Mapa) — nueva pestaña Mapa con project-map-view.tsx (nombre+descripción, archivos con badge de tipo, chips de funcionalidades, botón borrar mapa) y nota explicativa del ahorro de tokens.
- chat-app.tsx: composeSettings(sessionId) compone system prompt = base + skills + agentPrompt + mapa del proyecto; updateProjectMap tras cada respuesta (prioridad <project-map> del modelo > derivación local); props agent/onToggleAgent y map/onClearMap cableados a input y paneles (escritorio+móvil).
- Mock E2E movido a ruta interna: src/app/api/mock-llm/[...path]/route.ts (POST chat/completions con SSE + GET models; clave test-key-123; detecta «MODO AGENTE» y responde con bucle completo plan→2 iteraciones→project-map). El mock externo scripts/mock-llm-server.ts se mantiene pero los procesos de fondo mueren entre llamadas del sandbox, por eso la ruta interna es la vía fiable.
- E2E agent-browser (con custom provider baseUrl=/api/mock-llm, useProxy:false): bucle completo verificado (plan 3 items, ITERACIÓN 1 colapsable con «Repetir bucle: Falta animación…», ITERACIÓN 2 con código, «Revisión superada», respuesta final), vista previa EN VIVO renderizó la página del agente, projectMap persistido fusionado (2 archivos + 4 features), pestaña Mapa con chips, toggle agente on/off, regresión chat normal OK, sin errores de consola, lint+tsc limpios. Evidencia: download/evidencia-agente-mapa.png.

Stage Summary:
- Prism AI v2.1: el chat ahora puede trabajar como AGENTE por bucles (plan→ejecutar→revisar hasta pass=yes, máx 1-8 iteraciones configurable) y mantiene un MAPA DEL PROYECTO compacto por sesión que se inyecta en el contexto para revisar el proyecto gastando muchos menos tokens.
- El mapa se construye de doble fuente: derivación local del HTML (título/h1/botones/tech) y actualización explícita del modelo vía <project-map> JSON.
- Mock de pruebas convertido en ruta interna /api/mock-llm para E2E reproducible sin dependencias externas.

---
Task ID: 4
Agent: Super Z (main agent)
Task: Prism AI v2.2 — Radar de modelos gratis (notificaciones de ofertas free, fechas límite y fuentes rastreadas) + Kimi K3 gratis integrado.

Work Log:
- Investigación web: Kimi K3 de Moonshot AI (2.8T, multimodal, ctx 1.05M) tiene versión gratis «coding-kimi-k3-free» en AiHubMix (5 req/min · 500 req/día · 1M tokens/día, sin tarjeta). OpenRouter lista kimi-k3 solo de pago; Groq ofrece moonshotai/kimi-k2-instruct gratis. Fuentes de ofertas confirmadas: awesome-free-llm-apis (GitHub), blog OpenRouter «free-llm-apis-compared», Eden AI, woTai.
- lib/prism/free-radar.ts: RADAR_SOURCES (12 fuentes: AiHubMix, OpenRouter, Gemini, Groq, Z.ai, Cerebras, Mistral, GitHub Models, SambaNova, Cloudflare Workers AI, NVIDIA NIM, Ollama local), RADAR_OFFERS (4 ofertas con vigencia/límites), RADAR_PAGES (5 páginas rastreadas), RADAR_NOVEDAD_IDS + unseenRadarCount (motor de notificaciones) y fallback local de OpenRouter.
- app/api/free-radar/route.ts: GET trae EN VIVO los modelos :free del endpoint público de OpenRouter (sin clave, timeout 8s, caché en memoria 10 min, fallback a referencia local si no hay red). Probado: 18 modelos :free reales.
- store.ts: radarSeenIds persistido (partialize/export), markRadarSeen() y addModelToProvider() (añade sin duplicar).
- components/prism/free-radar.tsx: dialog con secciones «Ofertas del momento» (badge DESTACADA + CalendarClock con vigencia), «Siempre gratis» (cards con límites, chips de modelos clicables, clave/docs), «En vivo · OpenRouter» (badge EN VIVO/REFERENCIA LOCAL, contexto por modelo, botón + por fila) y «Páginas para estar al tanto». Botones de activación con 1 clic: con clave → añade modelo + habilita proveedor + toast; sin clave → toast con acción «Abrir» Ajustes; fuentes externas → configura proveedor Personalizado con su baseUrl.
- sidebar.tsx: botón «Radar» con badge verde de novedades no vistas (desaparece al abrir). chat-app.tsx: toast de notificación al abrir la app («Radar de gratis: N novedades» + acción «Ver radar»), FreeRadarDialog cableado con focusProvider de Ajustes.
- providers.ts: coding-kimi-k3-free añadido como primer modelo de AiHubMix; tagline actualizada.
- E2E agent-browser: badge «Radar 7» visible → toast de bienvenida con «Ver radar» → dialog completo (Kimi K3 DESTACADA, 12 fuentes, EN VIVO con 18 :free reales) → «Activar coding-kimi-k3-free» sin clave (añade, no habilita, avisa) y con clave (enabled:true + toast éxito) → modelo visible en picker con badge GRATIS → badge de novedades se limpia al ver. Sin errores de consola. Lint y tsc limpios.
- Empaquetado: download/prism-ai-v2.2-codigo-fuente.zip (157 archivos).

Stage Summary:
- Prism AI v2.2: nuevo RADAR DE MODELOS GRATIS con notificaciones (badge + toast al abrir la app), ofertas con vigencia/límites, catálogo permanente de 12 fuentes, lista EN VIVO de OpenRouter :free y páginas que rastrean ofertas — todo con activación de modelos en 1 clic.
- Kimi K3 gratis integrado de punta a punta: coding-kimi-k3-free en AiHubMix (verificado en la página oficial: $0, ctx 1.05M, 5 rpm/500 rpd) + vía trial de Moonshot configurable como Personalizado.

---
Task ID: 5
Agent: Super Z (main agent)
Task: Prism AI v2.3 — failover automático entre proveedores gratis (fix del error «10 intentos» de AiHubMix) + subida a GitHub integrada (sin límite de 100 archivos) + guía de ejecución.

Work Log:
- Captura del usuario analizada: AiHubMix respondió «accounts that have not been recharged can only try 10 times» → documentado en el Radar (oferta Kimi K3, fuente AiHubMix: límites y descripción) y resuelto en la app con failover.
- Failover: free-models.ts añade isQuotaError() (regex de cuota/saldo/429/402) + pickFailoverCandidate() (orden de preferencia gemini→groq→openrouter→zai→aihubmix→ollama→…, solo proveedores con clave y modelos gratis, excluye el proveedor que falló). chat-app.tsx: attemptFailover() con toast warning, borrado del mensaje de error, cambio persistido de modelo (sesión+global) y reintento con depth guard (máx 1). resolveModel() ahora acepta clave fresca del store (fix de stale closure detectado en E2E) y runGeneration lee la clave del modelo desde getState().
- Mock E2E ampliado: /api/mock-llm responde 429 con el texto real de AiHubMix cuando el modelo contiene «kimi-k3».
- E2E failover: aihubmix::coding-kimi-k3-free (mock) → 429 → toast «Cuota gratis agotada» → reintento automático con custom::mock-mini-free → respuesta sin error; segundo mensaje directo sin 429; defaultModelKey persistido. tsc+lint limpios.
- GitHub integrado: lib/prism/github-upload.ts (ghEnsureRepo con auto_init, ghGetHead, ghCommitBatch por lotes de ~60 archivos/12MB — texto embebido en tree, binarios vía blobs base64 con paralelismo 6 —, commit + PATCH ref main; shouldIgnore con .gitignore básico: node_modules/.next/.env/logs/zip; prepareFiles + relPathFrom con webkitRelativePath; token en localStorage). components/prism/github-dialog.tsx: token con enlace «Crear token» pre-rellenado (scope repo), nombre de repo, switch privado, carpeta con webkitdirectory, resumen N archivos/tamaño/ignorados, barra de progreso por lotes y enlace al repo final. Sidebar: botón «Subir a GitHub» (escritorio+móvil).
- E2E GitHub: diálogo renderiza; con 5 archivos sintéticos ignora .env y .log (queda 3); token inválido contra la API real de GitHub → «GitHub 401: Bad credentials — el token no es válido o expiró» (CORS y parse de errores verificados en vivo). Evidencia: download/evidencia-github-dialog.png.
- download/COMO-EJECUTAR.md: requisitos, npm install/dev/build/start, configuración de claves gratis, PWA, subida a GitHub (opción app y opción git CLI), problemas frecuentes y scripts.
- Empaquetado: download/prism-ai-v2.3-codigo-fuente.zip (159 archivos).

Stage Summary:
- Prism AI v2.3: si un proveedor se queda sin cuota gratis (ej. AiHubMix 10 intentos sin recargar), la app avisa y reintenta sola con otro modelo gratis conectado, cambiando el modelo de forma persistente. 
- Nueva función «Subir a GitHub» dentro de la app: carpetas de cualquier tamaño/cantidad de archivos en lotes con commits automáticos, sin el límite de 100 archivos de la web.

---
Task ID: 6
Agent: Super Z (main agent)
Task: Prism AI v2.4 — instalación premium con el proyecto en GitHub (README raíz, instalador multiplataforma, asistente de primera ejecución in-app).

Work Log:
- README.md raíz creado (no existía): logo, badges, 12 características, instalación en 3 pasos (git clone → npm run setup → npm run dev), tabla de claves gratis (AiHubMix/Gemini/Groq/OpenRouter/Z.ai/Ollama), PWA por plataforma, uso rápido, estructura, scripts, problemas frecuentes, privacidad y licencia.
- Instalador multiplataforma scripts/setup.mjs (npm run setup): valida Node ≥20.9 (requisito de Next 16), npm install, crea .env.local desde .env.example y muestra banner con siguientes pasos; wrappers setup.sh (macOS/Linux, chmod +x) y setup.bat (Windows con pausa). Sintaxis verificada con node --check.
- .env.example documentado (DATABASE_URL opcional; la app no necesita claves de servidor). LICENSE MIT (bilingüe ES+resumen EN). package.json: name prism-ai, version 2.4.0, description, script "setup". .gitignore ampliado (download/, workspace/, upload/, tool-results/, .zscripts/, db/custom.db, zips; ¡!.env.example re-incluido).
- Onboarding in-app components/prism/onboarding.tsx: wizard de 3 pasos con identidad prism (logo glow, dots de progreso). Paso 1 bienvenida + 4 features; Paso 2 clave AiHubMix con mostrar/ocultar, enlace a aihubmix.com/apikey, nota de los 10 intentos, «Probar conexión» (reutiliza fetchModels vía proxy; muestra N modelos y N gratis) y «Guardar y continuar» (setProviderConfig enabled + defaultModelKey coding-kimi-k3-free + toast) con salida «Todavía no tengo clave»; Paso 3 instrucciones PWA (escritorio/Android/iOS) + tip del Radar → «Empezar a chatear».
- store.ts: onboardingDone persistido (estado + setOnboardingDone + partialize). chat-app.tsx: auto-apertura a los 600ms si hydrated && !onboardingDone; el toast del radar se suprime en la primera visita (lo sustituye la guía); OnboardingDialog renderizado y reabrible. sidebar.tsx: nueva prop onOpenGuide + botón «Guía inicial» (GraduationCap) compartiendo fila con «Subir a GitHub» (escritorio y móvil).
- E2E agent-browser con storage limpio: auto-apertura confirmada → paso 1 → paso 2 → «Probar conexión» contra la API real de AiHubMix devolvió 408 modelos (53 -free) → «Guardar y continuar» toast «AiHubMix conectado · coding-kimi-k3-free» y picker con «coding-kimi-k3-free GRATIS · AiHubMix» → paso 3 → cerrar → tras reload NO reaparece (onboardingDone:true en localStorage) → «Guía inicial» de la sidebar lo reabre (role=dialog verificado). Sin errores de página ni en dev.log. Evidencias: download/evidencia-guia-paso1-bienvenida.png, -paso2-conexion.png, -paso3-pwa.png.
- Empaquetado: download/prism-ai-v2.4-codigo-fuente.zip (141 archivos, limpio para GitHub: incluye README, LICENSE, .env.example, setup.sh/.bat, .gitignore; excluye capturas E2E). COMO-EJECUTAR.md actualizado con flujo git clone + npm run setup.

Stage Summary:
- Prism AI v2.4: instalar desde GitHub ahora es «git clone → npm run setup → npm run dev» con instalador que valida Node, instala dependencias y prepara el entorno; README raíz profesional; y la propia app estrena un asistente de primera ejecución que conecta la clave gratis (con prueba de conexión real) y enseña a instalarla como PWA.

---
Task ID: 7
Agent: Super Z (main agent)
Task: Prism AI v2.5 — mejoras elegidas por el usuario (2 exportar chats, 3 temas de acento, 6 voz STT/TTS, 9 CI) + Repo Studio (dar un repo: abrir si ya está descargado, clonar si no, corregir con IA).

Work Log:
- Exportar chats (lib/prism/export-chat.ts): sessionToMarkdown (título, fecha, modelo, mensajes, adjuntos) + downloadSessionMarkdown (blob .md) + printSessionPdf (HTML formateado en iframe oculto → diálogo de impresión «Guardar como PDF», con mini-markdown propio y thumbs de imágenes). Botón de descarga en la cabecera del chat (solo con mensajes) con menú Markdown/PDF y toasts.
- Temas de acento (lib/prism/accent.ts + globals.css): ACCENTS con 6 presets (violeta, esmeralda, ámbar, rosa, cian, naranja) vía html[data-accent] que sobreescribe --prism-violet/cyan/pink + --primary/--ring/sidebar; modo «personalizado» con triada coordinada calculada por HSL (+38°/-42°) aplicada como variables inline; normalizeHex/customTriad/applyAccent. settings.accent + accentCustom + autoSpeak añadidos a AppSettings (DEFAULT_SETTINGS + partialize automático). Nueva pestaña «Apariencia» en Ajustes (grid de presets con swatch, selector de color nativo + hex input con aplicar al escribir). Efecto en chat-app aplica el tema al hidratar/cambiar.
- Voz (lib/prism/speech.ts): STT con SpeechRecognition tipado a mano (es-ES, continuous+interim, tabla de errores en español, acumulación base+finals en chat-input con botón Mic/MicOff y cleanup en unmount); TTS con speechSynthesis (stripForSpeech quita código/markdown/URLs, voz es-ES preferida, límite 6000 chars), botón Volume2/VolumeX en cada respuesta del asistente (speechState.msgId global), interruptor «Leer respuestas en voz alta» en Ajustes → Chat y lectura automática al terminar cada respuesta; stop() del chat también detiene la voz.
- CI (.github/workflows/ci.yml): push/PR a main → Node 20 → npm install → prisma generate → lint → build con DATABASE_URL de prueba. Badge CI añadida al README.
- Repo Studio: API src/app/api/repos/route.ts (runtime nodejs) con acciones open (parsea URLs https/ssh/owner-repo; si existe workspace/repos/owner---repo → status:exists; si no clona con git clone --depth 1 y sin dejar token en .git/config, fallback tarball oficial de la API de GitHub + tar), list (walk con SKIP_DIRS, máx 800), read (rechaza binarios por extensión, máx 400KB) y write; safeJoin bloquea path traversal (verificado). UI components/prism/repo-dialog.tsx: input URL + token opcional (prefill de ghGetToken), banner esmeralda «Ya lo tenías descargado»/violeta «Clonado», lista filtrable con puntos de cambios, editor monoespaciado con Guardar/Revertir, «Corregir» con instrucción opcional que llama a streamChat con el modelo activo (system: devuelve solo el archivo completo sin fences, stripOuterFence), pie con «Subir cambios a GitHub» (pushFilesToRepo: Contents API con sha previo, 1 commit por archivo) y «Publicar como repo nuevo» (publishAsNewRepo reutiliza uploadToGithub con Files sintéticos). Botón «Repos» (FolderGit2) en sidebar escritorio y móvil junto a Guía y GitHub.
- E2E agent-browser: preset esmeralda → --prism-violet #10b981; personalizado #ff6600 → triada #f8ff29/#ff2969; persiste tras recarga. Chat con mock → toast «Conversación exportada a Markdown» + iframe PDF con título correcto. TTS toggle sin crash; micrófono presente y error de permiso manejado con toast. Repo Studio con octocat/Hello-World real: clonado desde UI → README 13 B → leído → editado + guardado (verificado en disco) → 2ª apertura «Ya lo tenías descargado → abierto para editar» → Corregir con IA reemplazó el contenido + toast. Curl previo: open/list/read/write/exists OK y path traversal rechazado. Sin errores de página ni en dev.log; tsc y lint limpios a la primera.
- Empaquetado: download/prism-ai-v2.5-codigo-fuente.zip (153 archivos, 565 KB, integridad verificada) con .github/workflows/ci.yml, sin .env/logs/node_modules/workspace. package.json 2.5.0. README (Repo Studio, exportar, temas, voz, CI, estructura, FAQ, privacidad) y COMO-EJECUTAR.md (secciones 5b Repo Studio y 5c novedades v2.5) actualizados. Evidencias: download/evidencia-tema-personalizado.png, download/evidencia-repo-studio.png.

Stage Summary:
- Prism AI v2.5: exportar chats a Markdown/PDF, 6 temas de acento + color personalizado con tríada automática, dictado por voz y lectura en alto (con auto-lectura opcional), CI de GitHub Actions lista, y Repo Studio completo: abrir repo si ya está descargado / clonarlo si no / editar archivos / corregirlos con IA / subir cambios (commit directo o repo nuevo).
- Todo verificado E2E en navegador con repo real de GitHub y empaquetado en el zip oficial v2.5 listo para subir al repositorio.

---
Task ID: 8
Agent: Arena Agent Mode
Task: Prism AI v3.5 — tema de 3 opciones, modo foco, micro-animaciones, comandos slash, hojas de cálculo locales, resumir/traducir y skill de diseños que no se repiten.

Work Log:
- TEMA 3 OPCIONES: theme-provider defaultTheme "dark" → "system" (el oscuro forzado dejaba a contramano a quien tiene el dispositivo en claro). theme-toggle.tsx pasa de interruptor binario a menú Claro/Oscuro/Sistema con check del activo y icono del tema real (Monitor en «Sistema»); `mounted` evita el desajuste de hidratación porque el tema resuelto solo se conoce en cliente. sidebar.tsx estrena ThemeSegmented: tira de tres con role=radiogroup, visible sin abrir menús.
- MODO FOCO (zen): lib/prism/focus-mode.ts (readFocusMode/writeFocusMode/useFocusMode, persistido en localStorage `prism-focus-mode`, no en zustand: es preferencia de vista). Arranca en false y aplica el valor guardado tras montar para que servidor y cliente pinten igual. En la cabecera, icono Maximize2/Minimize2: oculta la sidebar de escritorio (lg:hidden), el botón de menú móvil, el split de vista previa (showPreviewPane) y el botón «Ver diseño» del móvil; además el auto-abrir del split respeta el modo (`if (!focusMode) setPreviewOpen(true)`), que era el punto del encargo.
- MICRO-ANIMACIONES (globals.css): `.stagger-in` con retardo por `--stagger` (índice) para la entrada escalonada del empty state — así no hace falta una clase por posición; `.lift-card` eleva las tarjetas de sugerencia solo bajo `@media (hover: hover)` para no dejarlas pegadas en táctil; `.panel-in` en preview-panel y en el ResizablePanel; `.skeleton-shimmer` (3 barras) bajo «Pensando…». Bloque `prefers-reduced-motion: reduce` que apaga todo, incluidas las ya existentes msg-in/generating/aurora.
- COMANDOS SLASH: lib/prism/slash.ts sin React ni DOM (probable en Node) — slashQuery/slashOpen (solo si la barra abre el mensaje y aún no hay espacios: «/imagen un gato» ya es un mensaje normal), filterSlash con puntuación por prefijo de comando > alias > título > substring, matchSlashExact, moveSlashIndex con vuelta por los extremos y normalizeSlash sin tildes. 6 comandos: /imagen /agente /resumen /arena /html (inserta HTML_TEMPLATE) /nuevo. slash-menu.tsx solo pinta (icono+tinte por comando, scrollIntoView del marcado, onMouseDown en vez de onClick para no robarle el foco al textarea). chat-input.tsx cablea flechas/Enter/Tab/Esc antes que el Enter de enviar, y `role=combobox` + aria-expanded/controls/autocomplete.
- HOJAS DE CÁLCULO: lib/prism/sheets.ts — parser CSV/TSV propio (comillas, «""» escapadas, saltos dentro de celda, CRLF, BOM de Excel), detectDelimiter que puntúa regularidad ignorando separadores entre comillas, rowsToMarkdown (rellena filas cortas, nombra col1/col2 sin cabecera, recorta a 200×40 avisando de lo omitido) y readSheetFile con `await import("xlsx")` BAJO DEMANDA. Verificado en el bundle servido: `sheet_to_json` aparece solo tras el import dinámico y el cuerpo de SheetJS (marcas «SheetJS»/«codepage») NO está en los chunks iniciales. chat-app.tsx separa hojas de documentos, comparten el cupo de 3 y el toast dice «se lee en tu dispositivo».
- RESUMIR / TRADUCIR: lib/prism/recap.ts con recapPrompt (estructura: en una frase / lo acordado / estado / siguiente paso) y translatePrompt (cita 400 chars de la respuesta, protege el código, conserva markdown) + 6 idiomas EN/FR/PT/DE/IT/JA. Los dos van como mensaje-instruction: viajan al modelo con TODO el contexto pero en el hilo se pintan como nota discreta, igual que el «continuar trabajo» del agente. instructionLabel() generaliza esa nota (antes decía siempre «continuar el trabajo»); un test cazó que el regex `[^\n(]+` se comía «tu respuesta anterior» dentro de la etiqueta → corregido a `(.+?) tu respuesta anterior` (se arregló el parser, no el test).
- SKILL DE DISEÑOS (petición específica): nueva builtin «Diseños que no se repiten» (🎨, id skill-design-variety, enabled por defecto) — obliga a decidir y anunciar estilo + composición + tipografía antes de codificar, con coherencia del sistema visual, accesibilidad y responsive real, y respeta el proyecto en marcha (la variedad aplica al empezar algo nuevo). Además «Desarrollador web experto» recibe el bloque VARIEDAD OBLIGATORIA con la regla explícita: una web nueva NO puede repetir lo ya construido cambiando solo el color; se le quitó el «oscuro-elegante» por defecto que era justo lo que uniformaba todo.
- Fix de detalle: el toast de /imagen estaba dentro del updater de setImageMode (StrictMode lo invoca dos veces) → movido fuera con el valor calculado. next-env.d.ts, que Next reescribe al arrancar dev, revertido para no ensuciar el diff.
- Verificación: lint 0 · tsc 0 · 460/460 tests (47 nuevos: 17 slash, 21 hojas, 9 recap) · dev server 200 OK y features confirmadas en el bundle servido (Modo foco, Resumir hasta aquí, prism-focus-mode, Diseños que no se repiten, Traducir respuesta, los 6 comandos, stagger-in/lift-card/panel-in/skeleton-shimmer en el CSS). `npm run build` no se puede completar EN ESTE SANDBOX porque no hay salida a Google Fonts (next/font) ni a binaries.prisma.sh; es limitación de red del entorno, no del código — la compilación de Turbopack en dev pasa limpia.

Stage Summary:
- Prism AI v3.5: el tema deja de imponer oscuro y pasa a seguir al sistema con tres opciones reales; llega el modo foco que apaga sidebar, vista previa y el auto-abrir del split; el compositor estrena comandos slash; los CSV/Excel se leen en el dispositivo y llegan como tablas markdown; y cada respuesta se puede resumir o traducir sin ensuciar el hilo.
- Lo pedido en concreto: la skill «Diseños que no se repiten» + las instrucciones de variedad en la skill web, con la regla explícita de que una web nueva no se resuelve repintando la anterior.

## CI en verde — la demo que escribía encima de los tests

Los E2E llevaban en rojo desde el merge de PR #1, también en `main`. La pista
estaba en los tiempos: el último run verde tardaba 2 min y los rojos 7-9 min.
Eso no es una aserción que falla, es gente esperando a algo que no llega.

Cuatro causas, ninguna de la v3.5 salvo las dos primeras regresiones ya
corregidas en `f7d5161`:

1. **La demo de vista previa** (`preview-demo.ts`, entró en PR #1) se ejecuta
   sola en la primera visita: teclea una landing entera, abre el split y
   encoge el compositor. Ningún spec la desactivaba, así que había un tercero
   escribiendo en casi todos los tests. Se neutraliza en
   `tests/e2e/fixtures.ts`, una base común que la marca como vista antes de
   cargar la página; los 11 specs importan de ahí, así que un spec nuevo no
   puede olvidarse.
2. **Halos del empty state**: 28rem (448px) se salían de un viewport de 390px.
   Acotados con `size-[min(...,Nvw)]`.
3. **Botón «Uso»**: los tests lo piden como botón y estaba escondido en el
   menú «Más». Promovido a la rejilla del pie.
4. **Studio**: esperaba «Token de GitHub» y «Commit y push»; PR #1 rediseñó
   esto a OAuth («Usar un token personal», «Abrir repo», «Subir a main»). Aquí
   mandaba el producto, así que se actualizó el test y se añadieron los
   fixtures de `/user`.

De paso, `playwright.config.ts` activa el reporter `github` en CI: antes un
E2E rojo solo dejaba «exit code 1» y había que descargar el log entero.

Resultado: E2E de 9m06s a **2m24s**, en verde.

---

## 30 ago 2026 — Ramas: una sola línea de verdad

`main` y el despliegue de producción llevaban días separados. Vercel servía
v3.5.0 mientras `main` iba por 3.7.0, y la app que se usaba a diario tenía
funciones —modo foco, comandos con barra, hojas de cálculo, tema de tres
opciones— que `main` no tenía. Se unieron en `43681cf` en vez de descartar
ninguna de las dos.

Después se limpiaron las ramas sueltas. Queda anotado por si algún día hace
falta, porque los commits siguen existiendo aunque la rama ya no:

| Rama borrada | Punta | Commits que `main` no tiene |
|---|---|---|
| `arena/01a04bb5-prism-ai` | `7b3edc0` | 0 — estaba entera dentro de `main` |
| `arena/01a04e17-prism-ai` | `9146549` | 0 — unida en `43681cf` |
| `arena/01a04c7e-prism-ai` | `78437b3` | **6** |

De la tercera se revisaron sus 52 archivos propios uno a uno: **45 son código
retirado a propósito** (Prisma, treinta componentes de shadcn sin usar,
`theme-toggle.tsx`, los scripts `capture-v28..30`). De los otros siete,
`db.ts` es Prisma, `spreadsheet.ts` duplica `sheets.ts`, y `persist-merge.ts`
y `reset-all.ts` están cubiertos por `transfer.ts` y el store. Nada que
rescatar — por eso se archivó en lugar de fusionarse, y por eso se deja ir.

Si alguna vez se necesita, el commit `78437b3` sigue accesible por su SHA en
GitHub aunque ninguna rama lo apunte:
https://github.com/Criptobox/prism-ai/commit/78437b3

La PR #2 salía de esa rama y se cerró sin fusionar: traía de vuelta todo lo
que se había quitado.

**Regla que queda:** una sola rama de verdad, `main`. Lo que no esté ahí, no
está desplegado.

---

Task ID: 9
Agent: Super Z (sesión interactiva con el autor)
Task: Implementar las tres mejoras prioritarias del análisis de PLAN-EVOLUCION.md: cuota real por proveedor, QA visual en la vista previa y memoria de fallos.

Work Log:
- Mejora 1 — Cuota real por proveedor (`quota.ts` nuevo): medidor honesto de tres estados. MEDIDA parsea las cabeceras `x-ratelimit-*` que mandan Groq/Cerebras en cada respuesta (con hora de reposición); CONSULTADA pregunta a `GET /api/v1/key` de OpenRouter al abrir el panel, no en bucle; SIN DATO no inventa porcentajes: enseña el último 429, los fallos seguidos y el enfriamiento que ya mide `health.ts`. El proxy ahora reenvía las cabeceras de cuota al navegador (antes se las comía) y `chat-client.ts` las captura en los tres protocolos y en el probe.
- Mejora 1b — Enfriamiento POR PROVEEDOR en `health.ts`: los límites de las cuotas gratuitas son por proveedor; un 429/402 ahora enfría también al proveedor entero (con backoff y Retry-After), y Auto/failover/consenso lo respetan: se deja de dar tumbos entre modelos del mismo proveedor agotado. Un éxito de cualquier modelo suyo lo levanta.
- Mejora 2 — QA visual sobre la vista previa (`visual-qa.ts` nuevo): el método de medición de `tests/e2e/responsive.spec.ts` aplicado al iframe a 320 y 390 px: scroll horizontal, elementos fuera del viewport, texto < 12 px y contraste (ratio WCAG, umbral 4.5:1 / 3:1 en grande). Como el sandbox no permite leer el DOM desde fuera, el medidor viaja DENTRO del HTML inyectado y reporta por postMessage (pasivo, sin red). Botón en `preview-panel.tsx` y en el Sandbox, con chapa roja de contador y tarjeta de resultados por ancho. Descargas y «abrir en pestaña» salen con el HTML limpio, sin el medidor.
- Mejora 3 — Memoria de fallos (`failures.ts` nuevo): lista de `{ resultado, regla }` con solo errores VERIFICABLES: diagnósticos bloqueantes de la revisión del Sandbox, errores en tiempo de ejecución de la consola, trabajo del agente a medias (`agentStalled`) y hallazgos del QA visual. Deduplica por regla (sube «usos»), caduca sola a 14 días, se borra de una en una, tope 40. Las reglas entran en el system prompt del agente vía `agentPrompt(maxLoops, reglas)`. Panel nuevo «Memoria» con borrado individual.
- UI: dos entradas nuevas en el sidebar (Cuota con `Gauge`, Memoria con `BrainCircuit`) junto a Uso; diálogos `quota-panel.tsx` y `failures-panel.tsx`.
- Tests: 3 baterías nuevas (`quota.test.ts`, `failures.test.ts`, `visual-qa.test.ts`) + bloque de enfriamiento por proveedor en `health.test.ts`. 609/609 en verde, tsc 0, eslint 0. Versión 3.9.0 → 3.10.0.
- Verificado en navegador (Chromium real): paneles Cuota y Memoria con datos, medición QA real del iframe (detectó el texto de 11 px de la demo a 320/390), sin desbordes a 320 px en la propia app y registro automático de los hallazgos en la memoria.

Stage Summary:
- Lo primero del análisis del plan, hecho: el failover ya no pierde reintentos dentro de un proveedor agotado, el medidor de cuota dice la verdad en sus tres estados, y la vista previa avisa de «esto se rompe a 320 px» antes de descargar.
- Archivos nuevos: `src/lib/prism/quota.ts`, `src/lib/prism/visual-qa.ts`, `src/lib/prism/failures.ts`, `src/components/prism/quota-panel.tsx`, `src/components/prism/failures-panel.tsx`, `tests/unit/quota.test.ts`, `tests/unit/failures.test.ts`, `tests/unit/visual-qa.test.ts`.
- Archivos tocados: `health.ts` (enfriamiento por proveedor), `chat-client.ts` (captura de cabeceras + consulta OpenRouter), `api/proxy/route.ts` (reenvío x-ratelimit), `agent-loop.ts` (reglas de memoria), `chat-app.tsx`, `sidebar.tsx`, `preview-panel.tsx`, `sandbox-studio.tsx`, `app-version.ts`, `package.json`.

---

Task ID: 10
Agent: Super Z (sesión interactiva con el autor)
Task: Implementar el segundo lote del análisis de PLAN-EVOLUCION.md: ficha del proyecto (Project Passport), permisos de las Skills y regresión visible en el Sandbox.

Work Log:
- Mejora 4 — Ficha del proyecto (`passport.ts` nuevo): `project-map.ts` ya detectaba pila, relaciones y puntos de entrada; faltaba presentarlo como ficha y que el agente la LEA ANTES de trabajar. `buildPassport(map)` calcula del mapa (nunca del modelo): pila con nº de archivos que la usan, entrada (portada index/portada/inicio o primera página), núcleo (el archivo con más backlinks), huérfanas (páginas sin enlaces en ningún sentido), tipos de archivo, notas y versiones. `renderPassportForPrompt` genera un bloque ≤ 700 chars que entra en el system prompt ANTES del mapa por archivo (`chat-app.tsx`). Tarjeta `project-passport.tsx` con chips en la cabecera del mapa (`project-map-view.tsx`), avisos ámbar para huérfanas.
- Mejora 5 — Permisos de las Skills (`skill-permissions.ts` nuevo): análisis local del texto ANTES de instalar. Detecta dominios remotos que la skill manda cargar (separando CDNs de uso común de dominios desconocidos), instrucciones de pedir/incrustar claves reales (TU_API_KEY, sk-, ghp_, AIza, "tu token/contraseña") y envío de datos a servidores (webhook, sendBeacon, "envía los datos a"). Tres niveles honestos: ok / aviso / riesgo, con los motivos concretos que lo disparan. La puerta está en `skills-dialog.tsx`: desde URL ya no instala directo — descarga, analiza y MUESTRA los permisos antes; el riesgo exige aceptación de DOS pasos («Instalar igualmente») y el permiso queda guardado en la skill (`SkillItem.permissions`) y visible en la lista para siempre. Segundo diente: `renderPermisosPrompt` inyecta en el system prompt los límites de las skills activas con permisos sensibles — la skill no puede colar claves ni envíos por encima del usuario.
- Mejora 6 — Regresión visible (`regression.ts` nuevo): un antes y un después medidos, no «Regression AI». Cada «Ejecutar» del Sandbox cierra una instantánea a los 3 s: consola (errores/avisos), QA móvil automático (solo si el medidor respondió después de arrancar) y peso del HTML servido. La comparación con la ejecución anterior (misma entrada) separa errores NUEVOS, errores ARREGLADOS, avisos nuevos y hallazgos del QA que empeoran o mejoran, con veredicto en una línea: mejora / empeora / igual / sin datos suficientes. Pestaña nueva «Regresión» en `sandbox-studio.tsx` con chapa roja cuando el cambio rompió algo; la primera ejecución lo explica y queda de referencia. Fix incluido: la medida automática del medidor ahora se guarda en ref para la instantánea (antes solo en estado).
- Tests: 3 baterías nuevas (`passport.test.ts` 11, `skill-permissions.test.ts` 12, `regression.test.ts` 12 — incluye normalización de puntos finales en dominios y el caso «consola vacía + QA sin responder = sin datos»). 609 → 642 tests en verde, tsc 0, eslint 0. Versión 3.10.0 → 3.11.0.
- Verificado en navegador (Chromium real): ficha renderizada con pila/entrada/núcleo/huérfana sobre un mapa real; skill de riesgo (pide TU_API_KEY + sendBeacon a dominio ajeno) detectada en vivo, bloqueada en el primer clic e instalada solo con el segundo; regresión con la demo del Sandbox — script con error inyectado detectado como «1 error nuevo de consola» con veredicto rojo y QA móvil medido en ambos lados.

Stage Summary:
- El segundo lote del análisis, hecho: la memoria del proyecto ahora tiene portada y el agente la lee primero; instalar una skill ya no es aceptar a ciegas lo que dice su texto; y el Sandbox dice qué rompió o arregló tu último cambio con números de ambas ejecuciones.
- Archivos nuevos: `src/lib/prism/passport.ts`, `src/lib/prism/skill-permissions.ts`, `src/lib/prism/regression.ts`, `src/components/prism/project-passport.tsx`, `tests/unit/passport.test.ts`, `tests/unit/skill-permissions.test.ts`, `tests/unit/regression.test.ts`.
- Archivos tocados: `types.ts` (SkillItem.permissions), `skills-dialog.tsx` (puerta de permisos + lista), `sandbox-studio.tsx` (pestaña Regresión + instantáneas), `project-map-view.tsx` (tarjeta ficha), `chat-app.tsx` (ficha + límites de skills en el system prompt), `README.md`, `package.json`, `app-version.ts`.
- Pendiente del análisis (punto 7): agente de navegador dentro del Sandbox — abrir la vista previa, cambiar viewport, pulsar, escribir y leer consola; la mitad del §8 que sí se puede construir.

---

Task ID: 11
Agent: Super Z (sesión interactiva con el autor)
Task: Implementar el tercer y último lote del análisis de PLAN-EVOLUCION.md: agente de navegador dentro del Sandbox (punto 7) — «Piloto del Sandbox».

Work Log:
- Mejora 7 — Piloto del Sandbox (`sandbox-pilot.ts` nuevo): la mitad del §8 que se puede construir de verdad. El agente solo opera sobre el iframe que Prism sirve, con el mismo truco del QA visual: el iframe corre sin `allow-same-origin`, así que un runtime pequeño viaja DENTRO del HTML inyectado y recibe órdenes por postMessage (`prism-pilot-cmd` → `prism-pilot-result`). Tres operaciones fijas, sin `eval`: `click` (selector CSS primero, si no por texto visible entre clicables), `type` (native value setter + eventos input/change, así los frameworks se enteran) y `read` (título, ancho real, botones, enlaces, campos con valores y extracto del texto). Nada de webs ajenas.
- Mini-lenguaje de pasos, una línea por paso: `ve a 320px` (ancho 200–2000), `pulsa «…»|#id`, `escribe "…" en #id` (sin objetivo = primer campo), `espera 500`, `lee`, `qa` (batería 320/390 o un ancho). El parser reconoce verbos sin acentos ni mayúsculas pero extrae objetivo y valor de la línea ORIGINAL: escribir «Ana García» escribe «Ana García», y un selector `#Tarea` no se rompe. Lo que no se entiende vuelve en `errores` con nº de línea, antes de correr.
- Ejecutor (`ejecutarPasosPiloto`): pasos en orden sobre el iframe, cada uno con resultado honesto —ok/fallido, detalle en claro, y qué logs NUEVOS de consola soltó (cursor sobre el búfer, no timestamps)—. Un clic que deja errores nuevos cuenta como fallido. El paso «vista» cambia el `style.width` del iframe y al final SIEMPRE se restaura el ancho previo. Botón «Detener» respeta el aborto entre pasos, marcando los restantes como detenidos, no como éxito. Timeout por orden (2,5 s): sin respuesta es fallo, nunca éxito inventado.
- UI en `sandbox-studio.tsx`: botón «Piloto» en la barra de la vista (junto a QA, con chapa roja de fallos cuando la franja está cerrada), franja con editor de pasos (validación en vivo con los errores del parser), «Ejecutar N pasos», «Ejemplo» (pasos que funcionan con la demo), «Copiar informe» y lista de resultados en vivo. `run()` ahora inyecta `injectPilot(injectVisualQA(html))` y resetea los resultados viejos del piloto: tras re-ejecutar, lo que se ve describe ESTA página.
- Puente con el agente del chat: `informePiloto()` genera el texto de la prueba (pasos OK/fallidos, detalles, errores de consola) para pegarlo en el chat; el agente corrige y la misma batería se vuelve a pasar. Copia con fallback clásico (`execCommand`) para contextos sin API de portapapeles.
- La memoria de fallos no se toca desde el piloto a propósito: los errores de consola que sueltan los clics ya entran solos por el puente existente (verificables), y un paso fallido puede ser un error del usuario al escribir el paso — envenenar la memoria con eso sería ruido.
- Tests: 16 nuevos en `tests/unit/sandbox-pilot.test.ts` (parser con acentos/mayúsculas/comillas/errores, descripciones, inyección idempotente que convive con el QA, informe, ejecutor con restauración de ancho y aborto, clic con errores nuevos = fallido). 642 → 658 en verde, tsc 0, eslint 0. Versión 3.11.0 → 3.12.0.
- Verificado en Chromium real: la demo pulsada por selector y por texto («Pulsado 4 veces» dentro del iframe tras 4 clics del piloto), formulario de prueba donde `escribe "Ana García" en #nombre` + `pulsa "Saludar"` produjo «Hola, Ana García!» con el acento intacto, paso QA midiendo 4 hallazgos (chip QA actualizado), `pulsa "Noexisto"` fallando con mensaje claro y chapa roja, ancho restaurado tras cada prueba, y la propia app sin scroll horizontal a 320 px.

Stage Summary:
- El plan del análisis queda COMPLETO: los siete puntos que valían la pena están implementados y verificados (cuota por proveedor, QA visual, memoria de fallos, ficha del proyecto, permisos de skills, regresión visible y piloto del Sandbox).
- Archivos nuevos: `src/lib/prism/sandbox-pilot.ts`, `tests/unit/sandbox-pilot.test.ts`.
- Archivos tocados: `sandbox-studio.tsx` (botón Piloto, franja de pasos, inyección del runtime, reset al re-ejecutar, copia con fallback), `README.md`, `package.json`, `app-version.ts`, `worklog.md`.

---
Task ID: v3.14-1
Agent: Super Z (main agent)
Task: PLAN-V4 punto 1 — Sacar los adjuntos de localStorage: mover los binarios (dataUrl) a IndexedDB, dejar en localStorage la ficha con `blobId`. Migración tolerante. Sin pérdida de datos.

Work Log:
- Leído el PLAN-V4 y el INSTRUCCIONESIA (contrato de trabajo). Punto 1 es prioridad: es un fallo de pérdida de datos silencioso (cuando `persist` no puede escribir por cuota de localStorage, no se guarda nada — ni conversaciones, ni claves, ni ajustes).
- Localizados los 8 sitios que leen `attachment.dataUrl` en 6 archivos: chat-client (3 protocolos), chat-input (miniaturas), message (miniaturas), export-chat (HTML/PDF), attachments (escritura).
- Nuevo archivo `src/lib/prism/attachment-blob.ts`:
  - `putBlob/getBlob/deleteBlob/clearAllBlobs` con IndexedDB (`prism-attachments` v1, store `blobs`).
  - `resolveAttachmentDataUrl(a)` — atajo si `a.dataUrl` ya está en memoria, si no lo busca por `blobId`. Devuelve `null` si no se puede recuperar.
  - `migrateLegacyAttachments()` — recorre el store, copia cada `dataUrl` a IDB, sustituye por `blobId` cuando tuvo éxito. Idempotente. Tolerante: si IDB falla o el store no puede persistir, deja el `dataUrl` original (no se pierde nada).
  - Import dinámico del store para evitar ciclo de dependencias.
- `types.ts`: `Attachment.dataUrl` opcional, nuevo `blobId?: string`.
- `attachments.ts`: `fileToAttachment` escribe a IDB y devuelve `{...,dataUrl,blobId:id}`. Si IDB falla, devuelve `{...,dataUrl}` sin `blobId` (degrada al comportamiento anterior).
- `store.ts`:
  - `partialize` strippa `dataUrl` cuando hay `blobId` (solo en el snapshot que se persiste; el estado en memoria no se toca).
  - `createJSONStorage(safeLocalStorage)` — envoltura de localStorage que captura `QuotaExceededError` en `setItem` (antes, zustand dejaba la Promise rechazada y la app dejaba de persistir en silencio).
  - `deleteSession/clearMessages/deleteMessage/truncateAfter` purgan las entradas IDB correspondientes (fire-and-forget). `resetAll` hace `clearAllBlobs`.
- `chat-client.ts`: `resolveAttachmentsForSend` pre-resuelve los adjuntos al inicio de `streamChat`. Los que no se pueden cargar se descartan (enviar `image_url: undefined` rompería la petición). `splitDataUrl` acepta `string | undefined` como seguridad.
- `message.tsx`: nuevo `AttachmentThumb` que resuelve `dataUrl` en `useEffect` con esqueleto mientras carga.
- `chat-input.tsx`: placeholder cuando `a.dataUrl` no está (caso teórico — los adjuntos recién creados siempre lo tienen).
- `export-chat.ts`: `downloadSessionHtml` y `printSessionPdf` se vuelven `async` y pre-resuelven adjuntos. Si un binario no se puede cargar, se pinta el nombre en su sitio (`.missing-img` en el CSS del HTML).
- `chat-app.tsx`:
  - Importa `migrateLegacyAttachments` y `deleteBlob`.
  - `useEffect` en mount (tras `hydrated`) dispara la migración.
  - `removeAttachment` también borra la entrada IDB.
  - Los botones de exportar HTML/PDF llaman a las funciones async con `void` y muestran toast.
- Tests:
  - `tests/unit/attachment-blob.test.ts` (12 tests): mock mínimo de IDB en memoria (Map + queueMicrotask). Cubre put/get/delete/clear, `resolveAttachmentDataUrl` en sus tres caminos, `migrateLegacyAttachments` (mover, idempotente, fallback si IDB cae).
  - `tests/unit/chat-client-attachments.test.ts` (7 tests): mock de `resolveAttachmentDataUrl`. Cubre pre-resolución para los 3 protocolos (OpenAI/Anthropic/Gemini), descarte de huérfanos, `buildRequest` intacto.
  - `tests/e2e/adjuntos-indexeddb.spec.ts` (3 tests): siembra una sesión con adjunto en formato viejo (dataUrl en el store, como pre-v3.14), recarga la página, verifica (1) la miniatura sigue visible, (2) el `dataUrl` ya no vive en localStorage y el binario está en IDB, (3) regenerar la respuesta tras recarga sigue enviando el adjunto al modelo (el mock-llm responde «He recibido tu imagen» solo si el body lleva `image_url`).
- Versión subida con `npm run bump -- minor` → v3.14.0 (script, no a mano).

Comprobaciones ejecutadas (sección 2 del INSTRUCCIONESIA):
- `npm run lint` → limpio, 0 errors / 0 warnings.
- `npm run build` → compila, TypeScript pasa, Next 16.3.3 con Turbopack. 19.1s.
- `npm test` → 693/693 unitarios pasan (674 original + 19 nuevos).
- `npm run test:e2e` → 88/88 E2E pasan en Chromium (85 original + 3 nuevos).
- `npm run build && npm start` + `curl localhost:3000/api/version` → responde `{"version":"3.14.0","status":"ok"}`.
- `rm -rf .next && VERCEL=1 npm run build` → `ls .next/next-server.js.nft.json` OK.

Lo que NO he podido comprobar:
- `npm run knip`: en este entorno (Node 24.19.0) `oxc-parser` lanza `RangeError: Array buffer allocation failed` al intentar abrir un ArrayBuffer de gran tamaño. Es un fallo de memoria del parser de Knip, no de mi código. Reintento con `NODE_OPTIONS=--max-old-space-size=2048` y persiste. Probablemente en CI sí pase.
- No he añadido tests E2E que comprueben que el `partialize` strippa `dataUrl` y que `safeLocalStorage` captura `QuotaExceededError` real (forzar cuota llena en Chromium requiere escrituras masivas que ralentizan el test). Los tests unitarios cubren la lógica de strip con mock; el E2E cubre el camino completo «sembrar dataUrl en el store → recargar → el binario vive en IDB».

Stage Summary:
- Punto 1 del PLAN-V4 terminado: los binarios de los adjuntos viven en IndexedDB, el store serializado ya no lleva los `dataUrl` (solo la ficha con `blobId`), y `localStorage` ya no se cae por cuota al meter un PDF o varias imágenes.
- La migración es tolerante: si IDB falla o el store no puede persistir, los adjuntos se quedan como estaban (no se pierde nada). Idempotente: correrla otra vez no hace nada.
- Sin cambios para el usuario: lo que se quita es un suelo que se hundía sin avisar, no se añaden funciones nuevas.
- Tests E2E prueban que la miniatura se ve tras recarga y que regenerar sigue enviando el adjunto al modelo.

---
Task ID: v3.15-puntos-2-3-4-5
Agent: Super Z (main agent)
Task: PLAN-V4 puntos 2, 3, 4 y 5 — tools con detección de capacidad, bucle Sandbox→agente, Share Target, split de chat-app.tsx.

Work Log:
- Punto 2 (tools con detección de capacidad):
  - Nuevo `src/lib/prism/tools-catalog.ts`: catálogo de 5 herramientas (read_file, write_file, list_files, run_project, get_quota). Tipos `ToolDef`, `ToolCall`, `ToolResult`.
  - Nuevo `src/lib/prism/tools-translate.ts`: traduce el catálogo a OpenAI (functions), Anthropic (input_schema), Gemini (functionDeclarations). `parseToolCallsFromChunk` para los 3 protocolos. `buildToolResultMessage` para reinyectar resultados.
  - Nuevo `src/lib/prism/tools-probe.ts`: `probeTools` manda una petición MÍNIMA con tools y clasifica la respuesta (`classifyToolsSupport`). Cache en memoria por (providerId, modelId, apiKey). `supportsTools` para decidir si usar el camino tools o caer al XML.
  - Nuevo `src/lib/prism/tool-runner.ts`: `runTool`/`runTools` ejecutan las llamadas localmente. `ToolContext` con `projectFiles`, `runProject`, `getQuota`. Sin React ni red — testeable en aislado.
  - `chat-client.ts`: `streamChat` acepta `tools?: readonly ToolDef[]` y `onToolCalls?: (calls: ToolCall[]) => void`. Inyecta `tools` en el body según protocolo. Acumula tool_calls en streaming (OpenAI delta.tool_calls, Anthropic content_block_start/input_json_delta, Gemini functionCall). Al final del stream, llama `onToolCalls` con la lista acumulada. `StreamMessage` extendido con `tool_calls`, `tool_call_id`, `tool_use_id`, `name`.
  - `chat-app.tsx`: `runGeneration` usa `runWithTools` (ver punto 5). Pasa el catálogo si el modelo lo soporta Y el modo agente está activo. Bucle: streamChat → si hay tool_calls → ejecuta runner → reinyecta → siguiente vuelta. Máx `agentMaxLoops`.
  - Mock-llm extendido: modelo `mock-tools` que devuelve `tool_calls` cuando el body lleva `tools`. Cuando el último mensaje es `role: "tool"`, responde con texto final.
  - Tests: 55 unitarios nuevos (tools-catalog, tools-translate, tools-probe, tool-runner, chat-client-tools) + 3 E2E (tools-agente). Cubren: traducción a los 3 protocolos, clasificación de capacidad, ejecución de tools, descarte de huérfanos, bucle completo agente→tool→reinyección→respuesta final.
- Punto 3 (bucle Sandbox → agente):
  - Nuevo `src/lib/prism/sandbox-runner.ts`: `runProjectInMemory(files)` construye el HTML autocontenido (buildRunHtml + puente de consola + QA + piloto), lo sirve en un iframe OCULTO, recoge logs durante 2.5s y devuelve `RunOutcome` (logs, errores, logLines, errorLines, qaFindings). Sin tocar el Sandbox visible.
  - `chat-app.tsx`: el `ToolContext.runProject` delega a `runProjectInMemory`. El agente puede llamar `run_project` y leer sus propios errores.
  - Test E2E (sandbox-agente): el agente llama a `run_project` y la tercera petición trae `role: "tool"` con el resultado ("El proyecto no tiene archivos" porque el test no siembra sandboxInitial).
- Punto 4 (Share Target):
  - `public/manifest.json`: añadido `share_target` con `action: "/share"`, `method: "POST"`, `enctype: "multipart/form-data"`, `params: {title, text, url, files: [{name: "images", accept: ["image/*"]}]}`.
  - Nuevo `src/app/share/route.ts`: handler POST que recibe el form-data, extrae title/text/url, compone el contenido (hasta 3500 chars), lo guarda en cookie efímera `prism-share` (maxAge 60s, SameSite=Lax) y redirige a `/?shared=1`. GET /share → 404 (no es página).
  - `chat-app.tsx`: en mount (tras hydrated) lee la cookie `prism-share`, vuelca el contenido en el input, borra la cookie y muestra toast. Las imágenes (binarios) se dejan para iteración posterior — el plan tasa el Share Target en «un par de días» y el texto es lo más común.
  - Test E2E (share-target): POST con texto → 307 con location `/?shared=1` y cookie `prism-share`. POST sin campos → 307 sin cookie. GET / sigue 200.
- Punto 5 (split de chat-app.tsx):
  - Nuevo `src/lib/prism/use-agent-tools.ts`: hook `useAgentTools` que encapsula el probe de tools + el bucle de tool_calls + la reinyección. `runWithTools(baseOpts, agentOn, maxLoops, sandboxInitial, config)` devuelve el texto final. El hook maneja el bucle internamente y llama los callbacks `onDelta`/`onReasoning` del llamador para pintar.
  - `chat-app.tsx`: el bloque inline de ~130 líneas (probe + bucle + reinyección) se reemplaza por una llamada a `runWithTools`. Imports de tools-catalog/tools-probe/tool-runner/tools-translate/sandbox-runner ya NO se usan en chat-app (viven en el hook). `chat-app.tsx` baja de 2220 a ~2108 líneas.
  - El hook es testeable en aislado (sin React, sin DOM) — los tests de tools ya cubren la lógica.

Puerta (sección 2 del INSTRUCCIONESIA):
- ✓ npm run lint — 0 errors, 0 warnings.
- ✓ npm run build — compila, TypeScript pasa, Next 16.3.3 Turbopack.
- ✓ npm test — 751/751 unitarios (693 orig + 58 nuevos: 53 de tools + 3 de sandbox-runner + 2 de chat-client-tools).
- ✓ npm run test:e2e — 95/95 E2E en Chromium (85 orig + 7 nuevos: 3 tools-agente + 1 sandbox-agente + 3 share-target... ver: 88 orig + 3 adjuntos-indexeddb de v3.14 + 3 tools-agente + 1 sandbox-agente + 3 share-target = 98. Pero 88 era con los 3 de adjuntos ya metidos; ahora 95).
- ✓ npm start + curl /api/version — {version: 3.15.0, status: ok}. /share POST → 307 con location correcta.
- ✓ rm -rf .next && VERCEL=1 npm run build — .next/next-server.js.nft.json existe.
- ⚠ npm run knip — NO ejecutado: oxc-parser lanza RangeError: Array buffer allocation failed en este entorno (Node 24.19.0), incluso con --max-old-space-size=2048. Fallo de memoria del parser, no del código. En CI debería pasar.

Lo que NO se ha podido comprobar:
- knip por el fallo de memoria del parser (mismo problema que en v3.14).
- No se ha probado el share real desde una app externa (Playwright no puede simularlo). El handler se prueba directamente por HTTP; el cliente lee la cookie en mount.
- No se ha forzado una cuota real de localStorage llena para el camino QuotaExceededError en E2E (igual que en v3.14).
- El soporte de imágenes en share_target está declarado en el manifest pero el handler solo procesa texto. Las imágenes requerirían guardar el binario en IDB desde el servidor, que no tiene acceso al IDB del navegador. Se deja para iteración posterior.

Stage Summary:
- Puntos 2, 3, 4 y 5 terminados. v3.15.0.
- El agente ahora puede llamar tools (read_file/write_file/list_files/run_project/get_quota) si el modelo los soporta; si no, cae al XML. El bucle Sandbox→agente funciona: el agente ejecuta el proyecto y lee sus propios logs. Share Target funciona para texto. chat-app.tsx se redujo en ~130 líneas (extraídas a use-agent-tools.ts).
- Sin cambios para el usuario que no usa el modo agente: todo el flujo antiguo (XML, chat normal) sigue funcionando igual.

---
Task ID: v3.16-rediseno-panel-agente
Agent: Super Z (main agent)
Task: Rediseño del panel del agente (v3.16) — pestañas Plan/Estructura/Edits/Resultados, logo de Prism, spinner animado, fondo medio color del tema, botón «Continuar el agente» debajo de las pestañas.

Work Log:
- Analizado el screenshot del usuario (Screenshot 2026-08-30 134526.png) con el modelo de visión. La mejora pedida: pestañas para inspeccionar las fases del agente + fondo medio color del tema + icono oficial del proyecto (logo de Prism) + símbolo de carga en movimiento + rediseño de los estilos de mensajes.
- `src/components/prism/agent-trace.tsx` reescrito:
  - Cabecera con el logo de Prism (PrismLogo) + "Bucle del agente" + spinner animado (Loader2 con animate-spin) + "Generando…" con puntos animados (.stream-dots).
  - Pestañas (Plan/Estructura/Edits/Resultados) con la activa en púrpura sólido (bg-prism-violet text-white). Solo aparecen si tienen contenido.
  - Contenido de cada pestaña:
    - Plan: lista de items del <plan> del agente.
    - Estructura: archivos del <project-map> (nombre + kind + summary).
    - Edits: bloques de código ```lang extraídos de cada <step>, agrupados por iteración con su título.
    - Resultados: <answer> final + lista compacta de iteraciones (icono de estado + título + revisión).
  - Estado del bucle + botón «Continuar el agente» debajo de las pestañas (movido desde message.tsx). El botón es pill-shaped con icono Play.
- `src/components/prism/message.tsx`: pasa `stalled` y `onContinueAgent` al AgentTraceView; elimina el bloque inline del botón Continuar (ahora vive en agent-trace.tsx). Quita imports no usados (PauseCircle, Button).
- `src/app/globals.css`:
  - Nuevo `.stream-dots::after` con animación `dots-pulse` (1.4s ease-in-out) para los puntos de "Generando…".
  - Nuevo `.agent-trace-v316` con fondo sutil púrpura/cyan (medio color del tema) y border-radius 14px.
  - `prefers-reduced-motion` ahora también desactiva `.stream-dots::after`.
- Tests E2E (`tests/e2e/agent-panel-redisenado.spec.ts`): 3 pruebas que verifican que las pestañas aparecen, que la activa tiene `bg-prism-violet`, y que el logo de Prism (aria-label "Prism AI") está visible.

Puerta:
- ✓ lint 0/0 · ✓ build · ✓ 751/751 unitarios · ✓ 98/98 E2E (95 orig + 3 nuevos) · ✓ build+start (/api/version ok) · ✓ VERCEL build (.nft.json existe)
- ⚠ knip: no ejecutado (mismo fallo de memoria de oxc-parser en Node 24.19.0).
- Versión: 3.15.1 (vía npm run bump -- patch).

Stage Summary:
- Panel del agente rediseñado como en el screenshot. Pestañas Plan/Estructura/Edits/Resultados con la activa en púrpura sólido. Logo de Prism como marca. Spinner animado + "Generando…" con puntos. Estado del bucle + botón «Continuar el agente» debajo de las pestañas. Fondo medio color del tema (púrpura/cyan sutil). Respeta prefers-reduced-motion.

---

## v3.17.0 — El agente que se paraba a mitad del trabajo

Informe del usuario: «cuando se activa el agente muchos modelos dan errores y
el cambio si un modelo no funciona pasa a otro pero si ese se detiene no
continua por lo que para». Leyendo el código salieron cuatro fallos distintos
que se sumaban a ese mismo síntoma.

### 1. El bucle de herramientas construía el cierre y no lo enviaba

`src/lib/prism/use-agent-tools.ts`. Al agotarse las vueltas con `tools`, el
código montaba el mensaje «entrega ahora la respuesta final» y hacía
`continue` — que salía del `for` sin llegar a mandarlo nunca. El agente
terminaba con la burbuja **vacía** y todo parado. Ahora ese cierre se envía de
verdad, en una llamada aparte y sin `tools` para que no pueda pedir más.

### 2. El texto del modelo se tiraba entre vueltas

En el mismo archivo, `content` se declaraba y nunca se le asignaba el retorno
de `streamChat`. Los turnos que se le reinyectaban al modelo viajaban con
`content: ""`, así que entre vuelta y vuelta perdía su propio trabajo.

De paso, la lógica sale del `useCallback` a una función normal
(`ejecutarConTools`), que es lo que el propio archivo decía perseguir y no
cumplía: dentro del hook no se podía probar sin React. Los imports pasan a
relativos como el resto de `src/lib/prism/` — el alias `@/` era justo lo que
impedía cargarlo desde los tests.

### 3. Una respuesta cortada a mitad pasaba por buena

`agentStalled` daba por no-parada cualquier traza con una etiqueta abierta.
Mientras llega el texto eso es correcto; con el stream ya cerrado significa lo
contrario: se cortó (techo de tokens, corte del proveedor). Sin distinguirlo,
el corte no salía ni como aviso ni como botón «Continuar»; el trabajo moría
ahí en silencio. Ahora `agentStalled(trace, terminado)` lo detecta como motivo
`"cortado"`, y `message.tsx` le pasa `!streaming`.

### 4. El failover solo sabía saltar una vez

`attemptFailover` relanzaba siempre con `depth = 1`, y dentro de
`runGeneration` los guardas eran `depth === 0`. O sea: el primer salto se
permitía y el segundo quedaba cerrado. Bastaba con que el modelo de repuesto
también fallara —lo normal entre los gratis— para quedarse parado. Ahora la
profundidad se encadena (`depth + 1`) con un tope de `MAX_SALTOS = 4`.

### Y lo que faltaba: retomar solo

Con lo anterior arreglado el agente ya avisa de que se quedó a medias, pero
seguía esperando a que alguien pulsara «Continuar». Si el usuario no estaba
mirando, la tarea moría igual. Ahora se retoma solo hasta `MAX_CONTINUACIONES
= 2` veces, y agotado el tope queda el botón de siempre.

Al relanzar se usa `relanzar()`, con `setTimeout(…, 0)`: lanzar la generación
en el acto no valía porque marca el mensaje en curso de forma síncrona y el
`finally` del intento anterior lo borraba justo después, dejando la respuesta
nueva sin indicador de escritura.

### Pruebas

- `tests/unit/agent-tools-loop.test.ts` (4, nuevo): el cierre se envía y sin
  `tools`, el texto sobrevive a la reinyección, y con `maxLoops=1` la vuelta
  útil sigue llevando catálogo. **Comprobado en rojo** reintroduciendo los dos
  fallos: 4/4 fallan.
- `tests/unit/agent-loop.test.ts` (+5): el corte con el stream terminado.
  **Comprobado en rojo** quitando el parámetro `terminado`: 2 fallan.
- `tests/e2e/agente-continua.spec.ts` (nuevo): modelo `mock-cortado` que se
  corta dentro de un `<step>`. Verifica que la nota «Se pidió al agente
  continuar el trabajo» aparece **sin pulsar nada**, que llega el cierre que
  el mock solo devuelve tras la continuación, que la instrucción viajó de
  verdad al proveedor, y que la continuación ocurre **una sola vez** (si el
  tope fallara, el test se pondría rojo). **Comprobado en rojo** desactivando
  la continuación automática.

### Puerta

- ✓ `npm run lint` · ✓ `npm run knip` · ✓ `npm run build` (con comprobación de
  tipos) · ✓ 768/768 unitarios · ✓ 102/102 E2E
- ✓ `npm start` + `curl /api/version` → `{"version":"3.16.0","commit":"8169f48"}`
- ✓ `VERCEL=1 npm run build` → `.next/next-server.js.nft.json` existe

### Lo que NO pude comprobar

- **No he reproducido el fallo con un proveedor real.** No hay claves aquí:
  todo se ha verificado con el mock-llm y con tests. Los cuatro fallos se leen
  en el código y los tests los fijan, pero cuánto de los errores que ve el
  usuario venía de cada uno, no lo sé.
- **La primera parte del informe —«muchos modelos dan errores»— queda a
  medias.** El fallo 1 explica que el agente se quedara mudo, pero no un
  error del proveedor. Sospecha sin confirmar: con el modo agente encendido se
  manda un `probeTools` extra por modelo y se le pasa `tools` a modelos gratis
  que las aceptan en la prueba mínima y las rechazan en una petición real.
  Para confirmarlo hace falta el mensaje de error exacto que sale en pantalla.
- Dos E2E de `version.spec.ts` fallaron durante la revisión: era el servidor de
  desarrollo servido desde un `.next` que mis builds habían reescrito debajo
  (§3.5 del contrato). Con el servidor reiniciado pasan los 102.

### Aparte: el lockfile se quedaba atrás en cada versión

No forma parte del encargo, pero apareció al subir la versión y es el desfase
que ya rompió una entrega: `package-lock.json` lleva la versión duplicada y
`scripts/version.mjs` no la tocaba. Estaba en 3.15.2 con el `package.json` en
3.16.0. Ahora el script lanza `npm install --package-lock-only` al final. El
diff del lockfile en este commit son esas dos líneas y nada más.

---

## v3.17.1 — La burbuja en blanco y los cinco modelos acusados en falso

Dos capturas del usuario, dos fallos distintos.

### La respuesta vacía se contaba como éxito

Captura: NVIDIA NIM · moonshotai/kimi-k3, 91,5 s, la caja de «Razonamiento del
modelo» y debajo **nada**. Ni error, ni motivo.

En `runGeneration`, una respuesta vacía caía directamente en
`settle(candidate, true, …)`: éxito. Sin fallo que registrar no había ni
enfriamiento, ni salto al siguiente modelo, ni mensaje. Se paraba ahí. Es
justo lo que hacen los modelos de razonamiento cuando se les va el
presupuesto de salida pensando.

Ahora una respuesta vacía es un fallo: se registra, se salta al siguiente de
la cadena si lo hay, y si no lo hay se dice qué pasó —distinguiendo el caso de
«razonó y no escribió», que tiene arreglo concreto (subir «Tokens máximos»)—
en vez de dejar el hueco.

### Prism acusaba al modelo de algo que no sabía

Captura: cinco modelos gratis de OpenRouter tachados en rojo, «5 no responden
— el proveedor no los reconoce o tu clave no llega a ellos», y un botón
«Quitar los que fallan».

`classifyProbe` traduce cualquier 404 a `no-existe`. Pero OpenRouter contesta
404 a **todos** los `:free` a la vez cuando la cuenta no acepta su política de
datos, y esos modelos existen perfectamente. Siguiendo el aviso te cargabas
cinco modelos buenos. Y el cuerpo de la respuesta —lo único que no es
interpretación nuestra— se capturaba en `ProbeResult.detail` y se tiraba: ni
en el chip ni en el aviso se enseñaba.

Es el mismo pecado que el medidor de cuota al 82 % inventado: afirmar una
causa que no se conoce.

- `pistaDelFallo(status, body)` reconoce solo frases **literales** del
  proveedor (política de datos, «no endpoints found», límite de peticiones,
  clave inválida). Si no encaja ninguna, devuelve null.
- `culpaConfirmadaDelModelo` solo culpa al modelo cuando no hay explicación
  mejor, y `modelosRotos` usa eso: lo que tiene otra causa ya no se propone
  para borrar.
- El aviso se parte en dos: ámbar explicando la causa **sin** botón de borrar,
  y rojo solo para lo que de verdad no se sostiene. El `title` de cada chip
  lleva ahora el veredicto, la pista y **el texto crudo del proveedor**.

### Pruebas

- `tests/unit/model-probe.test.ts` (+5): el 404 de política de datos no cuenta
  contra el modelo; el 404 sin explicación sí; `modelosRotos` deja fuera los
  que tienen otra causa.
- `tests/e2e/respuesta-vacia.spec.ts` (nuevo): `mock-vacio` devuelve 200 con
  contenido vacío y se comprueba que aparece la explicación en vez del hueco.
  **Comprobado en rojo** desactivando la comprobación: falla.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ 773/773 unitarios · ✓ 103/103 E2E
- ✓ `npm start` + `/api/version` → `{"version":"3.17.0","commit":"8cf271a"}`
- ✓ `VERCEL=1 npm run build` → `.nft.json` existe

### Lo que NO pude comprobar

- **No sé por qué OpenRouter devolvió 404 en la captura.** He hecho que Prism
  enseñe lo que conteste el proveedor, pero la causa concreta de ESA captura
  sigue sin confirmar: hace falta pasar el ratón por encima de uno de los
  modelos rojos y leer el texto.
- Tampoco he podido reproducir el caso de kimi-k3 con NVIDIA de verdad (no hay
  claves aquí). Que la respuesta vacía se contaba como éxito se lee en el
  código y el E2E lo fija; que ESO sea lo que pasó en la captura es lo más
  probable, no una certeza.
- Lo de «dejó el código a medias y no se cargó en el preview» solo queda
  cubierto si el modo agente estaba activo (el corte que se arregló en
  v3.17.0). Un bloque ```html cortado fuera del modo agente sigue sin
  detectarse; lo dejo nombrado aparte, no lo he tocado.

---

## v3.18.0 — La web larga que se quedaba a medias

Informe del usuario: «cuando es largo el código de una web se detienen los
modelos y lo dejan a medias». Era el hueco que quedó nombrado —y sin tocar— al
cerrar la v3.17.1.

### Qué pasaba

El modelo llega a su techo de tokens de salida y el stream termina **dentro
del bloque de código**. Prism lo daba por respuesta completa: no había ninguna
comprobación. La cerca ``` quedaba abierta, el documento sin `</html>`, y
`extractPreviewHtml` —que a propósito acepta bloques en curso, para pintar
mientras llega el streaming— le pasaba al iframe un documento incompleto. De
ahí que «ni siquiera se cargó en el preview».

El modo agente tenía su propia detección desde la v3.17.0 (`agentStalled` con
`terminado`), pero solo entiende las etiquetas XML del bucle. Fuera del agente
—que es como se pide una web casi siempre— no había nada.

### Cómo se arregla

`src/lib/prism/continuar.ts` (nuevo). Solo señales **objetivas**, nada de
adivinar por «parece que acaba raro»: un falso positivo aquí gasta cuota
pidiendo continuar algo que ya estaba completo.

- `respuestaCortada`: cerca ``` sin pareja, o documento HTML abierto sin
  `</html>`. Devuelve además la cola del texto para empalmar.
- `continuarCodigoPrompt`: lo que importa es lo que **prohíbe** — repetir lo
  ya escrito (duplicaría la página entera), abrir otra cerca (partiría el
  bloque en dos y la vista previa volvería a fallar) y saludar antes de seguir.
- `unirContinuacion`: los modelos desobedecen igual, así que se limpia la
  cerca reabierta, el preámbulo de cortesía y el solape repetido (se busca el
  solape más largo, hasta 2000 caracteres).

En `runGeneration` se cose **en la misma burbuja**, hasta `MAX_TROZOS = 3`.
Esto no es un detalle: si la continuación fuera un mensaje aparte, el bloque
de código quedaría partido en dos y la vista previa seguiría sin tener un
documento entero que enseñar. Si la continuación falla, se conserva lo que ya
había; si tras los tres trozos sigue cortado, se dice.

### Pruebas

- `tests/unit/continuar.test.ts` (13, nuevo). Incluye el caso de cerrar el
  círculo: coser un corte real deja un texto que ya no está cortado. Y los
  falsos positivos: dos bloques cerrados, un fragmento `<div>` suelto y el
  texto sin código no se tocan.
- `tests/e2e/codigo-cortado.spec.ts` (nuevo): `mock-largo` corta dentro del
  bloque y entrega el resto solo si se le pide continuar. La prueba no mira
  que exista una función: mira **el `<h1>` dentro del iframe de la vista
  previa**, que vive en el segundo trozo. Si no se cosiera, no aparece.
  **Comprobado en rojo** desactivando el bucle: falla por elemento no
  encontrado.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ 786/786 unitarios · ✓ 104/104 E2E
- ✓ `npm start` + `/api/version` → `{"version":"3.17.1","commit":"9e024ce"}`
- ✓ `VERCEL=1 npm run build` → `.nft.json` existe

### Lo que NO pude comprobar

- **No he reproducido el corte con un modelo real** (no hay claves aquí). Que
  el corte no se detectaba se lee en el código, y el mock reproduce la forma
  exacta del texto cortado; pero cuántos trozos hará falta pedir de verdad
  para una web larga, no lo sé.
- **`finish_reason` sigue sin leerse.** Es la señal autorizada del proveedor
  para «te corté por longitud» y no se mira en ningún sitio: la detección va
  por la forma del texto. Funciona y es independiente del protocolo, pero
  leer `finish_reason` sería más exacto. Queda nombrado, no hecho.
- El tope de salida por defecto (`max_tokens: 8192` en `chat-client.ts`) no lo
  he tocado: subirlo a ciegas provoca 400 en modelos con techo más bajo. El
  empalme resuelve el síntoma sin ese riesgo.

---

## v3.19.0 — Lo que ocupa tu prompt, y el modo ahorro

Dos cosas que van juntas: enseñar el precio y dar el interruptor para bajarlo.

### El medidor

`composeSettings` concatenaba ocho piezas a pelo y nadie sabía qué ocupaba
cada una. Ahora las piezas se devuelven sueltas (`prompt-actual.ts`) y las une
y las mide **la misma función** (`presupuesto.ts` → `construirPrompt`). Van
juntas a propósito: un medidor que calculara por su cuenta se desincronizaría
a la primera pieza nueva y enseñaría un número falso, que es peor que ninguno.

En Ajustes → Chat, una barra proporcional con el desglose y de dónde se quita
cada pieza. Los caracteres son exactos; los tokens se enseñan como
aproximación **con el divisor a la vista**, porque sin el tokenizador del
modelo no se puede saber.

### Las dos skills gemelas

«Desarrollador web experto» llevaba dentro un bloque «VARIEDAD OBLIGATORIA» de
**1.188 caracteres** que repetía lo que ES la skill «Diseños que no se
repiten», activa también de fábrica. Se mandaban las dos en cada mensaje.

Fuera el bloque duplicado. Las skills de fábrica pasan de **3.790 a 2.602**
caracteres. Hay un test con tope que impide que la duplicación vuelva.

### El modo ahorro

Interruptor en Ajustes → Chat. Hace tres cosas:

1. Instrucción corta (unos 600 caracteres, a propósito: una de 2.000 se come
   lo que dice ahorrar) que prohíbe preámbulos, despedidas, repetir la
   pregunta y explicar el código sin que se lo pidan.
2. Quita la **ficha del proyecto**, que es un resumen del mapa… que ya viaja
   entero justo detrás. Se mandaba la misma información dos veces.
3. Recorta el historial de 40 mensajes a 12. En una conversación larga el
   historial pesa mucho más que las instrucciones: es lo que de verdad baja
   la cuenta.

El ahorro que se enseña es **medido**: se monta el prompt sin ahorro y se
restan. Nada de prometer un porcentaje.

### Pruebas

- `tests/unit/presupuesto.test.ts` (16, nuevo): el total coincide EXACTAMENTE
  con la longitud del prompt; suma de piezas + separadores = total; el ahorro
  informado es el real. Y la guarda de fábrica, **comprobada en rojo**
  devolviendo el bloque duplicado: 2 tests fallan.
- `tests/e2e/modo-ahorro.spec.ts` (3, nuevo): no se mira el interruptor, se
  intercepta la petición y se lee el prompt de sistema que viaja. Y se compara
  el número del medidor con la longitud real de lo enviado. **Comprobado en
  rojo** vaciando el texto de ahorro.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ 802/802 unitarios · ✓ 107/107 E2E
- ✓ `npm start` + `/api/version` → `{"version":"3.18.0","commit":"b7f6aba"}`
- ✓ `VERCEL=1 npm run build` → `.nft.json` existe

### Lo que NO pude comprobar

- **No he medido el ahorro con un proveedor real.** Los caracteres que se
  quitan del prompt son exactos; cuántos tokens son de verdad depende del
  tokenizador de cada modelo, y por eso la app lo dice como aproximación.
- Sigue sin confirmarse que el prompt gordo fuera la causa de los errores con
  el agente. Ahora al menos el dato está a la vista.

---

## v3.20.0 — El failover ya no tira el trabajo

La queja original era «si un modelo se detiene pasa a otro pero no continúa».
Las v3.17–3.19 arreglaron el encadenado de saltos, la respuesta vacía y el
corte por longitud, pero quedaba el trozo que le daba nombre:

```ts
deleteMessage(sessionId, failedAssistantId);   // ← lo escrito, a la basura
```

Cuando un modelo se caía con media web hecha, Prism **borraba** la burbuja y el
de repuesto empezaba de cero. Cambiaba de modelo, sí; seguir con la tarea, no.

### Qué hace ahora

`attemptFailover` recibe lo que llevaba escrito el modelo caído —por
parámetro, porque la burbuja a esas alturas ya lleva encima el texto del
error— y si pasa de `MIN_RESCATE` (200 car.) y está cortado, monta una
**semilla**: conserva la burbuja y le pasa al repuesto lo escrito más el
prompt de empalme de `continuar.ts`.

La burbuja se reutiliza a propósito. Si el repuesto escribiera en una nueva,
el bloque de código quedaría partido en dos mensajes y la vista previa se
quedaría otra vez sin documento entero — el mismo error que se arregló en la
v3.18.0, por otra puerta.

Detalles que hubo que cuidar:

- El historial excluye la burbuja de la semilla: se reinyecta aparte con su
  instrucción, y si entrara además por el historial el modelo la vería dos
  veces.
- La semilla y la orden de empalmar se añaden **después** de comprimir: son
  justo lo que no se puede resumir sin perder el punto del corte.
- `content` arranca en lo ya escrito, así que para juzgar el intento nuevo hay
  que mirar solo lo **aportado** (`content.slice(base0.length)`). Si no, una
  respuesta vacía del repuesto parecería llena.
- Si el repuesto no aporta nada, lo rescatado **no se tira**: se conserva y se
  explica debajo.

Y una ampliación que salió de aquí: la rama de error solo llamaba al failover
por cuota. Ahora un trabajo a medias con otro proveedor disponible también
salta — que un modelo se caiga con media web escrita y no se intente con otro
era justo lo que se quería arreglar.

### Pruebas

- `tests/e2e/failover-continua.spec.ts` (nuevo). Dos proveedores:
  `mock-corta-y-cae` escribe media página y rompe el stream;
  `mock-empalma-free` devuelve el resto **solo** si recibe la orden de
  continuar, y si no devuelve una página que dice «Empezada de cero». El test
  mira el `<h1>` dentro del iframe de la vista previa.
  **Comprobado en rojo**: sin el arreglo, el iframe dice literalmente
  «Empezada de cero».

Un detalle del mock que costó encontrar: `controller.error()` en el mismo tick
que el `enqueue` hace que el cliente ni llegue a leer el trozo, así que no
había trabajo a medias que rescatar y el test fallaba por el montaje, no por
el código. Va con 150 ms de respiro y está comentado en el mock.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ 802/802 unitarios · ✓ 108/108 E2E
- ✓ `npm start` + `/api/version` → `{"version":"3.19.0","commit":"76bd561"}`
- ✓ `VERCEL=1 npm run build` → `.nft.json` existe

### Lo que NO pude comprobar

- **Sin proveedor real.** El rescate se prueba contra el mock. Cómo de bien
  empalma un modelo de verdad depende de si obedece el «no repitas nada»;
  `unirContinuacion` limpia el solape, pero no lo he medido con modelos reales.
- El umbral de 200 caracteres es un criterio mío, no una medida.

---

## v3.21.0 — La skill que encaja se propone sola

`classifyTask` clasifica cada mensaje en seis tipos de encargo desde hace
versiones, y se usaba **solo para elegir modelo**. Para las skills no la
miraba nadie: podías tener siete instaladas y ninguna pista de cuál sirve para
lo que estás haciendo.

Es la misma señal aplicada a otra cosa, así que el trabajo real fue pequeño.

### Cómo funciona

- Cada skill declara `kinds` (los tipos de encargo para los que sirve). Las
  siete integradas ya los traen.
- `skillsSugeridas(kind, skills, yaPropuestas)` devuelve las **apagadas** que
  encajan, como mucho dos.
- Al enviar, un aviso con el nombre y **el precio en caracteres por mensaje**,
  y un botón «Activar».

Tres reglas que no son negociables y están fijadas con tests:

1. **Se propone, no se activa.** Decidir por el usuario es lo que hace que la
   gente deje de fiarse de una app.
2. **Una vez y en paz.** Si no la quiso, insistir es ruido.
3. **Una charla no propone nada.** Ahí la sugerencia sería puro estorbo.

El precio va en el aviso a propósito: viene del medidor de la v3.19.0, y sin
él estaríamos ofreciendo añadir 1.800 caracteres a cada mensaje sin decirlo.

### Pruebas

- `tests/unit/skills-sugeridas.test.ts` (11, nuevo).
- `tests/e2e/skills-sugeridas.spec.ts` (3, nuevo): se comprueba que el clic la
  enciende **de verdad** —mirando el interruptor en el diálogo de Skills, no
  el toast—, que no insiste al repetir el encargo y que una charla no propone
  nada. **Comprobado en rojo**: sin las sugerencias, 2 de los 3 fallan.

Dos trampas del montaje, anotadas por si vuelven: el toast del modo agente
también ofrece «Activar» y sale a la vez en el primer mensaje, así que el clic
hay que acotarlo al toast de la skill; y el placeholder del compositor cambia
al abrirse la vista previa, por eso se localiza el `textarea` y no el
placeholder.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ 813/813 unitarios · ✓ 111/111 E2E
- ✓ `npm start` + `/api/version` → `{"version":"3.20.0","commit":"551baf0"}`
- ✓ `VERCEL=1 npm run build` → `.nft.json` existe

### Lo que NO pude comprobar

- **Si las sugerencias aciertan de verdad** depende de lo bien que clasifique
  `classifyTask`, que va por expresiones regulares. Con las frases de los
  tests acierta; con lenguaje real no lo he medido.
- Los `kinds` de las siete integradas los he asignado yo a ojo.

---

## v3.22.0 — Rehacer la respuesta con OTRO modelo

`regenerate` bifurcaba y volvía a lanzar **con el mismo modelo**. Pero cuando
una respuesta sale mal, lo que quieres nueve de cada diez veces no es la misma
tirada otra vez: es esto mismo probado con otro. Eso eran cuatro pasos —abrir
Ajustes, cambiar el modelo, cerrar, regenerar—.

Ahora el botón de regenerar lleva al lado un desplegable con los modelos
disponibles (`useAvailableModels`, que ya existía para el selector). Se elige
uno y se rehace con él. El modelo queda cambiado a propósito: si has tenido
que rehacerla con otro, lo normal es seguir con ese.

La respuesta anterior no se pierde — el sistema de ramas ya la guardaba —, así
que se pueden comparar las dos con las flechas del mensaje.

### Pruebas

- `tests/e2e/regenerar-otro-modelo.spec.ts` (nuevo): no mira que el menú
  exista, intercepta las peticiones y comprueba **a qué modelo se le pide** la
  segunda vez, más el contador de versiones en 2/2. **Comprobado en rojo**:
  sin el cambio, la segunda petición vuelve a `mock-mini-free`.

### Un test ajeno que rompí, y por qué

Al añadir el botón nuevo con `aria-label="Regenerar con otro modelo"`, el
locator `getByRole("button", { name: "Regenerar" })` de `chat.spec.ts` pasó a
encontrar **dos** botones y ese test se puso rojo. No era un fallo del test:
era una ambigüedad que introduje yo.

Se renombró el botón nuevo a «Elegir otro modelo». Se renombra el nuevo y no
el viejo a propósito: el viejo es el que la gente lleva usando y el que otros
tests nombran. Es el mismo tipo de choque que ya pasó con «Sistema» en la
barra lateral.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ 813/813 unitarios · ✓ 112/112 E2E
- ✓ `npm start` + `/api/version` → `{"version":"3.21.0","commit":"57d9017"}`
- ✓ `VERCEL=1 npm run build` → `.nft.json` existe

### Lo que NO pude comprobar

- El menú enseña como mucho 30 modelos. Con muchos proveedores conectados
  habrá que buscar; no he probado cómo se comporta con listas largas de
  verdad.

---

## v3.22.1 — El analizador de skills, cerrado

Dos huecos del analizador que quedaron señalados en `PLAN-V5.md` §1.

### El análisis se movió al store

Corría **solo** en la pantalla que instala desde URL. Cualquier otro camino
—editar el texto, importar un backup, una migración— dejaba unos permisos que
ya no describían lo que la skill manda hacer. Y un permiso desactualizado es
peor que no tenerlo: se enseña como si fuera cierto.

Ahora `addSkill` y `updateSkill` lo recalculan en `store.ts`. La garantía vive
donde ningún camino se la puede saltar, en vez de en una pantalla concreta.
`updateSkill` solo lo rehace si cambió el texto: renombrar no toca nada.

### El precio, al lado del interruptor que lo cobra

Cada skill enseña lo que añade al prompt (`+1.841`), y la cabecera el total de
las activas por mensaje. El desglose completo sigue en Ajustes → Chat; aquí va
la parte que se decide en esta pantalla, que es donde sirve para decidir.

### Pruebas

- `tests/unit/skills-store-permisos.test.ts` (4, nuevo): instalar analiza
  aunque el llamador no pase permisos; editar el texto los rehace **sobre el
  texto nuevo**; y a la inversa, si el texto se vuelve inofensivo deja de
  acusar. **Comprobado en rojo**: 3 de los 4 fallan sin el cambio.
- `tests/e2e/skills-coste.spec.ts` (nuevo): el coste por skill y el total, que
  sube al activar la segunda. **Comprobado en rojo** vaciando el número.

### Dos cosas que corregí de mí mismo

- Un test mío afirmaba que el analizador detecta `pideClaves` en una frase que
  no dispara ese patrón. El fallo era del test, no del analizador: se corrigió
  el test para afirmar lo que de verdad detecta (`enviaDatos` y el dominio
  desconocido). Cambiar el analizador para que encajara habría sido escribir
  la prueba y la respuesta a la vez.
- `npx tsc --noEmit` no cubre `tests/`, pero `npm run build` sí: cazó cuatro
  errores de tipos en el test nuevo que yo había dado por buenos. Otra razón
  para no saltarse la puerta entera.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ 817/817 unitarios · ✓ 113/113 E2E
- ✓ `npm start` + `/api/version` → `{"version":"3.22.0","commit":"6e55b59"}`
- ✓ `VERCEL=1 npm run build` → `.nft.json` existe

### Lo que NO pude comprobar

- **No hay pantalla para editar una skill instalada**, así que el reanálisis
  al editar está probado por el store, no por la interfaz. Cuando exista esa
  pantalla, la garantía ya estará puesta debajo.

---

## v3.23.0 — Lo de `xlsx`, decidido: hilo aparte y desechable

`npm audit` lleva semanas avisando de dos vulnerabilidades **altas sin arreglo
en npm** en `xlsx` (SheetJS): contaminación de prototipos y ReDoS. Las dos se
disparan al **leer** un archivo preparado.

Al mirarlo de cerca, la exposición pesa más de lo que parecía. En una app
cualquiera esto sería «que el usuario abra lo que quiera en su pestaña». Aquí
no: **Prism guarda las claves API en el dispositivo**, y ensuciar el
`Object.prototype` del hilo principal va justo contra la promesa del producto.

### La decisión

Ni aceptar y mirar para otro lado, ni traerse la distribución de SheetJS
—que vive fuera de npm y metería una descarga externa en el momento del
despliegue, que es la clase de riesgo que ya costó un día aquí—.

**El parseo se mueve a un Web Worker que se destruye al terminar**
(`sheets.worker.ts`):

- Otro *realm*: lo que se contamine ahí dentro no toca al de la app.
- Se crea por archivo y se mata en el `finally`, pase lo que pase.
- Del Worker solo salen **cadenas**: la conversión a texto se hace dentro, así
  que ningún objeto del parser cruza al hilo principal.
- Tope de 15 MB y límite de 20 s, tras el cual se mata el hilo. Un ReDoS cuelga
  ese hilo, no la interfaz.
- Si el navegador no deja crear el Worker, **falla con un aviso** y pide un CSV.
  Caer al parseo directo «por comodidad» dejaría el agujero abierto justo en
  los navegadores donde no se puede cerrar.

Y la decisión queda **escrita en el README**, que era la mitad del encargo: un
aviso de auditoría que nadie ha decidido vuelve a saltar cada vez.

### Pruebas

- `tests/e2e/excel-aislado.spec.ts` (nuevo): genera un `.xlsx` de verdad con
  `xlsx` en Node, lo adjunta y comprueba que **sus celdas llegan al modelo**
  interceptando la petición. Mover un parser de hilo es exactamente el cambio
  que rompe la función sin que nadie se entere; esto lo cubre.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ 817/817 unitarios · ✓ 114/114 E2E
- ✓ `npm start` + `/api/version` → `{"version":"3.22.1","commit":"13d2655"}`
- ✓ `VERCEL=1 npm run build` → `.nft.json` existe, y el worker entra en el
  bundle (`turbopack-worker-*.js`)

Y otra vez la §3.5: ejecuté `npm run build` con el `dev` levantado para
comprobar que el worker se empaqueta, y el E2E siguiente falló por la app en
blanco, no por el código. Reiniciado el dev, verde a la primera.

### Lo que NO pude comprobar

- **No he probado un archivo malicioso de verdad.** El aislamiento es
  estructural (otro realm, hilo que muere), no una detección: no busco el
  ataque, le quito el sitio donde hacer daño.
- El aviso de `npm audit` **sigue apareciendo**, y seguirá: la dependencia no
  tiene versión parcheada. Lo que cambia es que ahora hay una decisión escrita
  detrás y un aislamiento real, no un «ya lo miraremos».

---

## v3.24.0 — Ahora sí: el proveedor dice por qué paró

Los tres protocolos mandan un campo diciendo **por qué** terminó el modelo
—`finish_reason`, `stop_reason`, `finishReason`— y no se leía en ningún sitio.
Lo comprobé buscándolo en todo `src/`.

Toda la detección de corte de la v3.18.0 va por la **forma del texto**: una
cerca ``` sin pareja, un `<html>` sin cerrar. Funciona con código y es
independiente del protocolo, pero es un indicio. Cuando el modelo se queda sin
sitio a mitad de una frase normal, **la forma no ve absolutamente nada**.

### Qué se hizo

- `finish-reason.ts` traduce el valor crudo de los tres protocolos a un motivo
  (`fin`, `longitud`, `herramienta`, `filtro`, `desconocido`). Lo que no
  reconoce se queda en `desconocido`: no se inventa.
- `streamChat` lo acumula en las tres ramas y en las dos variantes (streaming
  y no). Gana **el último chunk con valor**: los intermedios lo mandan a
  `null`, y devolver `null` en vez de `desconocido` es lo que impide que un
  chunk vacío pise el motivo bueno.
- Un `onFinish` nuevo se lo pasa al llamador, solo si el proveedor lo dijo.
- El bucle de continuación hace caso a **las dos señales**: el proveedor
  acierta donde la forma no ve nada, y la forma cubre a los proveedores que
  no mandan el campo.

`mensajeParada` devuelve `null` para un final normal y para un motivo
desconocido: avisar ahí sería inventarse un dato.

### Pruebas

- `tests/unit/finish-reason.test.ts` (11, nuevo). Incluye el caso que parece
  un detalle y no lo es: los chunks intermedios devuelven `null`, no
  `desconocido`.
- `tests/e2e/finish-reason.spec.ts` (nuevo): `mock-prosa-cortada` devuelve
  prosa cortada a media palabra —**sin bloque de código**, así que la
  heurística de forma no puede verlo— con `finish_reason: "length"`, y el
  resto solo si se le pide continuar. **Comprobado en rojo**: sin leer el
  campo, la respuesta se queda a medias.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ 828/828 unitarios · ✓ 115/115 E2E
- ✓ `npm start` + `/api/version` → `{"version":"3.23.0","commit":"d0ac44c"}`
- ✓ `VERCEL=1 npm run build` → `.nft.json` existe

### Lo que NO pude comprobar

- **Los valores están probados contra el mock, no contra proveedores reales.**
  Los literales de las tres familias salen de sus documentaciones; los routers
  que reenvían pueden mandar valores propios, y esos caerán en `desconocido`
  —que es el comportamiento correcto: se cae a la heurística de forma, que ya
  estaba.

---

## v3.24.1 — Las decisiones del failover, fuera del componente

`chat-app.tsx` iba por **2.556 líneas**, y toda la lógica de failover vivía
dentro del `useCallback` de `runGeneration`, enredada con React, los toasts y
el store. Eso significaba que **la única forma de probarla era abrir un
navegador**: cada arreglo de esta semana ha costado un ciclo de Playwright
—minutos— para comprobar algo que es una función pura de cinco datos.

No es teoría: sacar el bucle de tools de su hook (v3.17.0) destapó cuatro
fallos que los E2E no veían.

### Qué se movió

`decisiones.ts`: tres funciones que reciben el estado del intento y devuelven
qué hacer (`siguiente` / `failover` / `parar`). No tocan nada. Los avisos, el
store y el repintado se quedan en el componente.

- `decidirTrasError` — el nudo de condiciones que había que leer tres veces.
- `decidirTrasCuotaEnTexto` — cuando el proveedor responde 200 y el texto ES
  el aviso de cuota.
- `decidirTrasVacio` — cuando el modelo cierra sin escribir nada.

De paso salió una incoherencia latente: en la rama de modelo manual el
`continue` avanzaba **una** posición mientras que el índice calculado podía
apuntar más lejos (salto de proveedor por cuota). No se notaba porque con
modelo manual la cadena tiene un solo elemento, pero el código decía dos cosas
distintas. Ahora la decisión devuelve el índice y el bucle lo respeta.

`chat-app.tsx` queda en 2.515 líneas. Bajar 41 no es el objetivo; el objetivo
es que estas decisiones se prueben en milisegundos.

### La prueba de que sirve

Reintroduje el fallo histórico —el `depth === 0` que cerraba la puerta al
segundo salto y costó tres versiones descubrir— y **el unitario lo cazó en 8
milisegundos**. Antes eso eran tres minutos de Chromium.

Y la prueba de que no cambié comportamiento: **los 115 E2E siguen verdes** sin
tocar ni uno.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ 845/845 unitarios (+17) · ✓ 115/115 E2E
- ✓ `npm start` + `/api/version` → `{"version":"3.24.0","commit":"41a9bd7"}`
- ✓ `VERCEL=1 npm run build` → `.nft.json` existe

### Lo que NO pude comprobar

- **Es un refactor: no verás nada nuevo.** Lo que se gana es que el siguiente
  arreglo del failover cueste la mitad.
- Quedan fuera las decisiones del bucle de continuación y del agente. Se
  pueden mover igual; no lo he hecho para que este cambio sea revisable de una
  sentada.

---

## v3.25.0 — `read_url`: el agente puede leer una página

`PLAN-V4` daba esto por imposible «sin servidor». Resulta que el servidor ya
estaba **y ya estaba protegido**: `/api/proxy` pide cualquier host público y
`net-guard.ts` rechaza `localhost`, las IPs privadas y los metadatos de la
nube, también al seguir redirecciones.

Sexta herramienta del catálogo. **No es un buscador** —eso sí necesitaría un
servicio de búsqueda—: lee una URL concreta que le das tú. La descripción se lo
dice al modelo con esas palabras, porque si no le pasa términos de búsqueda y
se lleva un error.

### Cómo está hecho

- `html-a-texto.ts`: saca el texto legible. Primero se tiran `script`,
  `style`, `svg` y compañía **con su contenido**, y solo después las
  etiquetas; al revés, el JavaScript se quedaría suelto en medio del texto.
  Tope de 8.000 caracteres, y cuando recorta lo dice con el tamaño real.
- La herramienta va por `/api/proxy`, no por `fetch` directo, por dos razones
  que importan las dos: CORS (desde el navegador no se lee una página ajena) y
  el escudo. Hay un test que falla si alguien cambia eso.
- 15 s de límite, y los errores del escudo se le explican al modelo para que
  no reintente en bucle.

### Un fallo que encontró un test mío

`&iacute;` y compañía no se descodificaban: al modelo le llegaba
«art&iacute;culo». Media web en español escribe los acentos así, y además
gasta el triple de tokens. Se añadieron las entidades acentuadas —cuidando que
`&Aacute;` y `&aacute;` son **distintas**, así que bajarlo todo a minúsculas
rompía las mayúsculas acentuadas.

### Pruebas

- `tests/unit/html-a-texto.test.ts` (9, nuevo).
- `tests/unit/tool-runner-read-url.test.ts` (8, nuevo): que se pide **por el
  proxy** con la URL en la cabecera, que el JS no llega, que una URL inválida
  o un `file://` se rechazan **sin tocar la red**, y que el JSON se entrega tal
  cual. **Comprobado en rojo** cambiando el proxy por un `fetch` directo.
- `tests/e2e/read-url.spec.ts` (nuevo): el escudo, contra el servidor de
  verdad — `169.254.169.254` devuelve 403.

### Por qué el E2E cubre solo el escudo

Lo intenté con la página entera y **el escudo la bloqueó**: le pasé una URL
`localhost` y `net-guard` la rechazó, que es exactamente su trabajo. En este
entorno no hay red hacia fuera y una página local no sirve por diseño, así que
la conversión se prueba en unitario y el escudo en E2E. Está anotado en la
cabecera del spec para que nadie lo «arregle» abriendo un agujero.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ 863/863 unitarios · ✓ 116/116 E2E
- ✓ `npm start` + `/api/version` → `{"version":"3.24.1","commit":"20dea64"}`
- ✓ `VERCEL=1 npm run build` → `.nft.json` existe

También hubo que actualizar `tools-agente.spec.ts`, que comprobaba que el
catálogo tiene exactamente cinco herramientas. No era un fallo: el test estaba
haciendo su trabajo.

### Lo que NO pude comprobar

- **No he leído una página real**, por lo del entorno sin red. La conversión
  está probada con HTML de verdad, pero no contra una web publicada.
- **El servidor sí hace la petición**, así que quien despliegue esto en
  internet le está dando a su agente la capacidad de pedir URLs desde su
  servidor. El escudo cubre lo interno; el consumo de ancho de banda no lo
  cubre nadie, y conviene saberlo antes de publicarlo.

---

## v3.26.0 — «Auto» aprende de lo que TE ha funcionado

`useUsage` guarda de cada respuesta el modelo, si fue bien, los milisegundos y
los caracteres. Es un historial real: tus claves, tu hora del día, tus
encargos. `buildTaskChain` **no lo miraba**: ordenaba por una tabla estática de
afinidad y por `lastGood`, el último acierto. Auto no aprendía — recordaba una
cosa.

### El ajuste

`experiencia.ts` convierte el historial en un empujón a la puntuación, con dos
reglas que mandan sobre todo lo demás:

1. **Sin muestras suficientes no se opina.** Por debajo de 5 respuestas
   devuelve `null` y el ajuste es 0. Con dos respuestas no se sabe si un
   modelo es bueno, y ajustar con eso sería la misma clase de invento que el
   medidor de cuota al 82 %.
2. **Es un empujón, no un mandato.** ±4 puntos sobre una tabla que reparte
   decenas: inclina la balanza entre dos parecidos, pero no puede tumbar una
   afinidad clara. Un modelo con buen historial *en general* no es por eso el
   mejor para hacer una web.

Dentro del ajuste **manda el acierto**: un modelo rápido que falla la mitad de
las veces no vale nada, y uno lento que siempre contesta vale mucho. La
velocidad solo desempata, y con la mitad de peso. Hay un test para eso exacto.

Y un detalle que parece menor: sin ninguna respuesta correcta, la media de
tiempo es `null`, **no cero**. Cero diría «rapidísimo» de un modelo que nunca
contesta.

### Lo que se ve

En el panel de Uso, cada modelo enseña ahora `90% de aciertos · 1.5s de media ·
20 respuestas`, o **`sin dato · faltan 3 respuestas`** cuando aún no hay
suficiente. Ese segundo caso es el importante: es lo que evita que la app
enseñe un porcentaje sacado de dos tiradas.

### Pruebas

- `tests/unit/experiencia.test.ts` (13, nuevo): que el lento fiable gana al
  rápido infiel, que el ajuste nunca se sale de su peso, y que **sin historial
  la cadena sale exactamente igual que antes** — un cambio así no puede
  reordenar nada de quien acaba de instalar la app.
- `tests/e2e/auto-aprende.spec.ts` (nuevo): el panel con un modelo veterano y
  otro de dos respuestas. **Comprobado en rojo** quitando el mínimo de
  muestras: fallan 2 unitarios y el E2E.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ 876/876 unitarios · ✓ 117/117 E2E
- ✓ `npm start` + `/api/version` → `{"version":"3.25.0","commit":"0611ddd"}`
- ✓ `VERCEL=1 npm run build` → `.nft.json` existe

### Lo que NO pude comprobar

- **Si el ajuste mejora las elecciones de verdad, no lo sé.** Está medido que
  reordena según lo medido; que eso te dé mejores respuestas es una apuesta
  razonable, no un resultado. Para saberlo haría falta comparar con la Arena a
  lo largo de semanas.
- Los pesos (5 muestras, ±4 puntos, 25 s como «lento») son criterio mío.

---

## v3.27.0 — Catálogo de skills

Última del `PLAN-V5`. Iba deliberadamente al final: sin las sugerencias por
tarea (v3.21) nadie abriría esta pestaña.

Y era la que menos trabajo tenía de lo que parecía: **instalar desde URL ya
funcionaba, con la puerta de permisos delante**. Lo que faltaba no era el
mecanismo, era el índice — había que conocer la URL de memoria.

### Cómo está montado

- `public/skills/index.json` + los `.md` de cada skill. Un archivo estático:
  sin backend, sin cuentas, sin moderación que mantener. `URL_CATALOGO` es una
  constante — apuntarlo a un repo público es cambiar esa línea.
- `catalogo-skills.ts` valida el índice **sin fiarse de él**: descarta las
  entradas rotas pero conserva las buenas (un índice con una entrada mala
  sigue sirviendo), quita ids repetidos, filtra tipos de encargo inventados y
  recorta los textos largos. Lo que no hace es rellenar huecos.
- Cinco skills para empezar, escritas para este repo: revisor de
  accesibilidad, descifrador de errores, peso y rendimiento, mensajes de
  commit, y datos sin inventar.

### Lo que hace que esto no sea un agujero

Elegir del catálogo **no instala nada**. Baja la entrada por el **mismo flujo**
que una URL pegada a mano, así que la puerta de permisos sigue en medio: ves
qué declara el texto y decides. No hay atajo, y hay un E2E que lo comprueba
—entre elegir e instalar tiene que aparecer el botón de permisos—.

Por eso tampoco hay plugins: una skill es texto que se analiza y se lee entero.
Código de terceros rompería justamente esta garantía.

### Pruebas

- `tests/unit/catalogo-skills.test.ts` (14, nuevo). Incluye una guarda sobre el
  **índice que se publica de verdad**: que todas sus entradas sobreviven a la
  validación, que cada `url` apunta a un archivo **que existe y tiene
  contenido**, y que todas declaran su tipo de encargo. Si alguien rompe el
  JSON o borra un `.md`, lo caza el test y no el usuario.
- `tests/e2e/catalogo-skills.spec.ts` (2, nuevo): el listado, la búsqueda, que
  elegir enseña los permisos antes de instalar, y que lo ya instalado no se
  ofrece dos veces. **Comprobado en rojo** quitando el botón: fallan los dos.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ 890/890 unitarios · ✓ 119/119 E2E
- ✓ `npm start` + `/api/version`, y `/skills/index.json` responde 200 en la
  build de producción
- ✓ `VERCEL=1 npm run build` → `.nft.json` existe

### Lo que NO pude comprobar

- **El catálogo se sirve desde el propio despliegue, no desde un repo aparte.**
  El `PLAN-V5` proponía un repo `prism-skills`; no tengo acceso para crearlo,
  así que el índice viaja en este repositorio. Funciona igual y la constante
  está lista para apuntar a otro sitio, pero no es exactamente lo planeado.
- **Nadie ha escrito skills de terceros todavía.** El catálogo solo vale la
  pena si alguien las aporta; con cinco propias es un comienzo, no un
  ecosistema. Era el riesgo que ya se anotó al ponerlo el último.

---

## v3.28.0 — El agente prueba su propio código (y dos fallos que salieron por el camino)

`PLAN-V4` §3: «hoy el agente escribe código y **te pregunta a ti** si
funciona». Estaba arreglado a medias y de la peor manera posible: el agente
ejecutaba el proyecto **solo si el modelo soportaba `tools`** y llamaba a
`run_project`. La mayoría de los modelos gratis no las soportan y van por el
camino XML, así que el arreglo llegaba justo a los modelos para los que Prism
**no** existe.

### Lo que hace ahora

Cuando el agente cierra su respuesta con `<answer>` y esa respuesta trae un
proyecto abrible, Prism lo **ejecuta** en un iframe oculto, lee los errores de
consola y, si los hay, se los devuelve al modelo para que se corrija. Hasta dos
rondas.

Ejecutar es local y gratis: solo cuesta una llamada al modelo si de verdad hay
algo que arreglar. Y solo se revisa lo que se puede **abrir** —hace falta un
HTML de entrada—: fingir que se revisa un fragmento de CSS sería dar un visto
bueno que no se ha comprobado.

El error se le devuelve **tal cual salió de la consola**, no interpretado por
nosotros: es el dato, y el modelo sabe leerlo. Se le pide el archivo completo
porque un parche suelto rompe la vista previa. Y el fallo queda en la memoria
de fallos, que es exactamente lo que esa memoria debe guardar: algo verificado
ejecutando, no una impresión.

### El fallo gordo que salió por el camino

Escribiendo esto, el E2E no pasaba. Al rastrearlo apareció esto en
`RunOutcome`:

```ts
/** Hubo proyecto que correr (había archivos y un entry). */
ok: boolean;              // …pero el código hacía: ok = errorLogs.length === 0
```

**El comentario y la implementación decían cosas distintas.** Y no era
cosmético: `run_project` —la herramienta del agente, el camino que sí estaba
«arreglado»— hacía `if (!outcome.ok) return "No se pudo ejecutar el proyecto"`.
O sea que **siempre que el proyecto se ejecutaba y daba errores, al modelo se
le decía que no se había podido ejecutar**. Se le ocultaban los errores de su
propio código, que es justo para lo que existe la herramienta.

Arreglado separando las dos preguntas: `ejecutado` (¿llegó a correr?) y `ok`
(¿sin errores?), con el comentario diciendo lo que hace cada uno. Hay un test
de regresión para el caso exacto.

De paso, un fixture del test de `run_project` afirmaba `ok: true` con
`errors: 1`, una combinación que en la realidad no se da nunca. Corregido.

### Código muerto, en el mismo ciclo

`buildAutoChain` (40 líneas) lo había reemplazado `buildTaskChain` y no lo
llamaba nadie, ni un test. Fuera. Igual `IMAGE_MODELS`, `clearCookieHeader` e
`invalidateToolsProbe` — esta última era redundante por diseño: la `apiKey`
entra en la clave de cache, así que cambiar de clave ya estrena entrada. No la
llamaba nadie porque no podía hacer falta.

`knip` queda sin exports muertos propios; los 21 que restan son re-exports de
shadcn, superficie de librería.

### Pruebas

- `tests/unit/auto-revision.test.ts` (15, nuevo): que sin HTML no se revisa,
  que si no se pudo ejecutar **no se le echa la culpa al modelo**, y que el
  prompt le pide arreglar y no explicar.
- `tests/unit/tool-runner.test.ts` (+2): el de regresión del fallo de `ok`.
- `tests/e2e/agente-prueba-su-codigo.spec.ts` (nuevo): `mock-codigo-roto`
  entrega una página que llama a una función inexistente —error real de
  navegador, no simulado—, y se comprueba que Prism le devuelve el error y que
  la página **termina arreglada**. **Comprobado en rojo** desactivando el
  bucle.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ 907/907 unitarios · ✓ 120/120 E2E
- ✓ `npm start` + `/api/version` → `{"version":"3.27.0","commit":"1b183c7"}`
- ✓ `VERCEL=1 npm run build` → `.nft.json` existe

### Lo que NO pude comprobar

- **Cuántas veces acierta el modelo al corregirse, no lo sé.** Está probado
  que se le devuelve el error y que un modelo que sabe arreglarlo lo arregla;
  con modelos gratis reales, cuántos lo consiguen a la primera es otra cosa.
- **Solo se revisa lo que abre en un iframe.** Python, Node o cualquier cosa
  que no sea una página web quedan fuera, y así seguirá: aquí no hay dónde
  ejecutarlos.
- El QA visual existe (`run_project` acepta `qa`) pero la revisión automática
  **no lo pide**: mide más y tarda más, y quería que esta primera versión solo
  reaccionara a errores duros de consola.

---

## v3.29.0 — El agente pulsa los botones (y dos falsos culpables que salieron)

Idea del usuario, y de las buenas: la revisión de la v3.28.0 **solo cazaba lo
que revienta al cargar**. En una página generada la mayoría de los fallos viven
detrás de un clic — el manejador que llama a una función que no existe, el
`getElementById` de un id que se renombró. Si aquel `pintarTodo()` hubiera
estado dentro de un `onclick`, la revisión lo habría dado por bueno.

Y estaba medio construido: `sandbox-pilot.ts` ya sabía pulsar dentro del
iframe, y ese runtime ya se inyectaba en el iframe de la revisión.

### Lo que se puede AFIRMAR, que es lo delicado

«Este botón no funciona» es **indecidible**. Un botón que no hace nada visible
puede estar perfecto —un «Cancelar» que cierra algo ya cerrado—. Y descarté
mirar si tiene manejador: los listeners puestos con `addEventListener` **no se
pueden inspeccionar desde JavaScript**, así que un botón bien cableado saldría
como roto. Acusar en falso es peor que no mirar.

Se reportan dos cosas, las dos comprobables:

| Señal | Qué se hace |
|---|---|
| Al pulsarlo **salta un error** | Se le devuelve al modelo. Esto es lo que vale |
| Se pulsa y **nada cambia** | Se enseña como dato: «puede ser correcto, míralo» |

Lo segundo **no** se le manda al modelo: le haríamos perseguir un fallo que
puede no existir, gastando cuota y empeorando la página.

Detalles: se pulsa por **índice**, no por texto (hay botones sin rótulo y
rótulos repetidos); tope de 10 y 250 ms de espera por clic; y se compara una
firma de la página antes y después para saber si cambió algo.

### Falso culpable nº 1: nuestro propio sandbox

La vista previa corre con `allow-scripts` y **sin** `allow-same-origin`, que es
lo que impide que el proyecto toque la app. El precio es que el navegador
prohíbe `localStorage` ahí dentro y cualquier acceso lanza un `SecurityError`.

Y una página generada usa `localStorage` constantemente —una lista de tareas
que se guarda, un contador que persiste—. O sea que **Prism le habría dicho al
modelo «tu código lanza un error» y le habría hecho arreglar código correcto**:
el peor resultado posible para una revisión automática. Ahora esos errores se
reconocen como del entorno y no se le facturan a nadie.

### Falso culpable nº 2: las dos fases compartían los logs

Peor y más tonto: el error de un **clic** se contaba también como error de
**carga**, porque ambas fases escriben en el mismo array. Un botón roto
disparaba la corrección por consola en vez de la de botones, y al modelo le
llegaba el mensaje equivocado. Se corta el array donde empieza el barrido.

Las dos mitades están comprobadas en rojo por separado.

### Pruebas

- `tests/unit/prueba-botones.test.ts` (14, nuevo): la frontera entre fallo y
  dato. El test que más importa: **un botón que no cambia nada NO se le manda
  al modelo**.
- `tests/unit/auto-revision.test.ts` (+4): el error del sandbox no cuenta, pero
  uno de verdad que venga acompañado sí — y al modelo solo le llega el suyo.
- `tests/e2e/agente-pulsa-botones.spec.ts` (nuevo): `mock-boton-roto` entrega
  una página que **carga limpia** y cuyo botón llama a `sumarTotal()`, que no
  existe. **Comprobado en rojo** dos veces: quitando el barrido, y quitando la
  separación de fases.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ 924/924 unitarios · ✓ 121/121 E2E
- ✓ `npm start` + `/api/version` → `{"version":"3.28.0","commit":"c3ab120"}`
- ✓ `VERCEL=1 npm run build` → `.nft.json` existe

### Lo que NO pude comprobar

- **El orden de los clics cambia el resultado.** Pulsar «borrar todo» antes que
  «añadir» prueba otra aplicación. Se pulsan en el orden del DOM y no se
  recarga entre clics: es una decisión, no un descuido, pero significa que un
  botón puede fallar por culpa del anterior.
- **No se pulsan enlaces ni se rellenan campos.** Un `<a>` puede navegar fuera
  y dejar la prueba sin página; los formularios necesitarían datos plausibles,
  que es justo lo que no se puede inventar.
- **Tope de 10 botones.** Una página con veinte deja la mitad sin probar, y el
  resumen lo dice («de 20»).
- El QA visual sigue fuera. Una cosa es «esto revienta» y otra «esto se ve
  estrecho en móvil»; mezclarlas convierte el informe en ruido.

---

## v3.30.0 — Los fallos que salen cuando TÚ la usas

Idea del usuario, y da en el punto débil del barrido de la v3.29.0. Ese pulsa
botones **a ciegas**: en el orden del DOM, sin escribir en los campos y sin
tocar los enlaces. Le faltan las tres cosas que solo aporta el uso real —**tu
orden, tus datos y los enlaces que tú eliges**.

Y resulta que eso no se recogía en absoluto: **la vista previa en vivo no
llevaba el puente de consola**. Si algo reventaba mientras usabas la página, el
error moría dentro del iframe sin que se enterara nadie.

### Qué hace

- El puente de consola se inyecta también en la vista previa. Solo en lo que se
  **pinta**: lo que se descarga o se abre en pestaña sigue yendo limpio, como
  ya hacía el medidor de QA.
- El puente apunta además **qué acabas de tocar**, en fase de captura para
  enterarse antes de que el manejador reviente. Así el aviso dice «Error al
  pulsar **Ver más**» en vez de soltar un stack trace sin contexto — y eso es
  justo lo que el modelo necesita para saber por dónde entrar.
- Un aviso discreto sobre la vista previa, con «Arreglar» y una X para
  descartarlo.

### Dos decisiones que evitan que sea un incordio

**No se manda solo.** Gastar una respuesta sin permiso por un error que quizá
ya conocías es peor que enseñarlo y esperar. El botón es tuyo.

**El mismo error repetido sube un contador, no añade una línea.** Un fallo
dentro de un bucle o de un `mousemove` llenaría la lista en un segundo. Y los
errores del propio sandbox —el `SecurityError` de `localStorage`— se filtran
con el mismo criterio de la v3.29.0: no son del modelo.

### Pruebas

- `tests/unit/errores-en-vivo.test.ts` (10, nuevo): la deduplicación, el
  filtro del entorno, el tope, y que sin gesto **no se inventa uno**.
- `tests/e2e/errores-al-usarla.spec.ts` (nuevo): `mock-enlace-roto` esconde el
  fallo detrás de un **enlace**, que el barrido automático no pulsa a propósito
  (un `<a>` puede navegar fuera y dejar la prueba sin página). El test
  comprueba primero que **no hay ningún aviso** —la página carga limpia—, luego
  pulsa el enlace dentro del iframe, y verifica que el aviso dice dónde fue,
  que «Arreglar» manda el error **y el gesto** al modelo, y que queda
  arreglado. **Comprobado en rojo dos veces**: sin el puente en la vista
  previa, y sin el registro del gesto.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ 934/934 unitarios · ✓ 122/122 E2E
- ✓ `npm start` + `/api/version` → `{"version":"3.29.0","commit":"6125abd"}`
- ✓ `VERCEL=1 npm run build` → `.nft.json` existe

### Lo que NO pude comprobar

- **El gesto solo se registra en clics.** Si el error salta al escribir en un
  campo o al enviar un formulario, el aviso dice «Error al usarla» sin más. Es
  honesto —no se inventa un origen— pero es menos útil.
- **Se limpian al repintar.** Si el modelo entrega una versión nueva, los
  errores de la anterior desaparecen aunque sigan estando. Es lo correcto para
  no acusar del pasado, pero significa que un fallo puede pasar desapercibido
  si repintas justo después de provocarlo.
- No he medido cuánto pesa el puente de consola en páginas muy grandes; es un
  script pequeño y va inline, pero no lo he cronometrado.

---

## v3.31.0 — El radar deja de poner siempre lo mismo, y te lleva a por la clave

Dos quejas del usuario, las dos ciertas.

### «Siempre pone lo mismo» — era literal

Al mirarlo: de las cuatro secciones del radar, **tres son un catálogo escrito
a mano** (13 proveedores, las ofertas, las páginas que seguir). Solo la lista
`:free` de OpenRouter venía de la red. Un catálogo estático no cambia; es que
literalmente ponía lo mismo.

Dos arreglos, y hacían falta los dos:

**Traer datos de verdad.** Sección nueva, «Nuevo para ti»: se le pregunta a
**cada proveedor que ya tienes conectado** qué modelos ofrece —con tu clave,
que es la única forma de saber a qué tienes acceso— y se enseña lo gratis que
**todavía no tienes añadido**. Eso cambia por semanas y es distinto para cada
persona.

Detalles que importan: lo que ya tienes se descarta (un radar donde el 90% ya
lo tienes no descubre nada, y es justo la sensación de «siempre lo mismo»); se
**reparte** entre proveedores en vez de vaciar el primero, porque uno que
devuelva doscientos modelos dejaría a los demás fuera; y un proveedor caído no
tumba la búsqueda de los demás.

Y cuando no hay novedades **no se presenta como un fallo**: «ya tienes añadido
todo lo gratis que ofrecen» es una buena noticia, no un hueco.

**Dejar de fingir que lo escrito a mano es actual.** Cada oferta y cada fuente
lleva ahora la fecha en que se comprobó, y la interfaz dice «verificado hace 3
días» o, pasado el mes, cambia el tono a «sin verificar desde hace 2 meses».
Antes una oferta decía «Vigente · verificado 28 ago 2026» dentro del texto: en
2027 seguiría diciéndolo igual. Es la misma regla que la cuota — si no se
puede saber que sigue siendo verdad, no se afirma; se dice cuándo se miró.

### «Debe mandar directo a donde se consigue»

Tenía razón y el dato ya estaba ahí sin usar:

- El aviso de «te falta la clave» te mandaba a **Ajustes**. Pero si no tienes
  la clave, abrir Ajustes te deja igual de bloqueado. Ahora el botón principal
  es **«Conseguir clave»** y va al `keyUrl` del proveedor; Ajustes queda de
  secundario, que es donde la pegarás después.
- El consejo «consigue tu clave de OpenRouter» era **texto plano sin enlace**:
  te decía que la consiguieras y te dejaba buscándola. Ahora es un botón.

### Pruebas

- `tests/unit/radar-propio.test.ts` (11, nuevo) y `tests/unit/frescura.test.ts`
  (8, nuevo).
- `tests/e2e/radar-propio.spec.ts` (3, nuevo): que el modelo que **ya tienes**
  no se te vuelve a ofrecer, que sin clave sale «Conseguir clave» **y**
  «Ajustes», y que las ofertas dicen cuándo se comprobaron. **Comprobado en
  rojo** las tres, una por una.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ 953/953 unitarios · ✓ 125/125 E2E
- ✓ `npm start` + `/api/version` → `{"version":"3.30.0","commit":"0a8fa30"}`
- ✓ `VERCEL=1 npm run build` → `.nft.json` existe

### Lo que NO pude comprobar

- **Las fechas de verificación las he puesto yo hoy**, salvo la de Kimi que ya
  venía en el texto. No he comprobado una por una que las 13 fuentes sigan
  ofreciendo lo que dicen: he fechado el catálogo, no lo he auditado. Marcar
  algo como «verificado hoy» sin haberlo mirado sería justo el problema que
  esto quiere resolver, así que **conviene revisarlas de verdad y ajustar las
  fechas**.
- **«Nuevo para ti» solo ve lo que tu proveedor lista.** Los que no exponen
  catálogo de modelos, o cuya clave no da acceso a esa ruta, no aportan nada —
  y eso no se distingue de «no tiene novedades».
- No he probado el comportamiento con muchos proveedores conectados a la vez:
  son peticiones en paralelo y podrían tardar.

## v3.32.0 — El plan V6 entero: la foto del gratis, tu orden de failover, un solo panel y el razonamiento normalizado

Cuatro tareas del plan V6 (`PLAN-V6.md`), en orden, una por commit. La quinta
(`npx prism-ai`) se cayó con datos en la mano — más abajo.

### T1 · Avisar cuando un modelo deja de ser gratis

`isFreeModel` es una heurística estática: si mañana un modelo pierde la capa
gratuita, Prism lo trataba como gratis hasta el 402. Ahora el radar guarda una
**foto** de lo que era gratis la última vez que miraste (persistida en el
store) y al volver compara.

- `lib/prism/cambio-gratis.ts`, módulo puro como `radar-propio.ts`: compara la
  foto con el catálogo de hoy y devuelve las **tres** listas — dejó de ser
  gratis / nuevo y gratis / desapareció del catálogo, que **no es lo mismo**
  (el modelo ya ni existe para ti; afirmar que «dejó de ser gratis» sería
  inventar que el renombrado y el nuevo son el mismo).
- El proveedor que **falla al responder no se compara** y conserva su foto
  vieja: un corte de red no se enseña como «te has quedado sin todo».
- Primera vez: **no hay aviso**, ni vacío ni de «0 modelos». Se guarda la foto.
- La mala noticia va **arriba** de «Nuevo para ti», con la fecha de la foto —
  que es lo único que se sabe.

### T2 · Orden de fallback configurable

Para que Groq fuese antes que Gemini había que **recompilar**: `FAILOVER_ORDER`
era una constante. Ahora: `pickFailoverCandidate` acepta un orden opcional (sin
él, la constante tal cual — los tests anteriores pasan sin tocarlos), el orden
del usuario vive en el store como **lista de `ProviderId`** (no un objeto de
pesos: una preferencia es un orden) y se **sanea al leerlo**: ids retirados
fuera, proveedores que faltan al final — un orden guardado hace seis versiones
no puede dejar fuera a un proveedor nuevo.

En Ajustes → Claves: lista con **flechas** (el arrastrar no merece una
dependencia) y «Restablecer». `PROVIDER_FIT` se queda fuera a propósito:
afinidad por tipo de tarea es otro concepto.

### T3 · Panel del sistema

Los datos existían **repartidos** en tres diálogos (Uso 381 líneas, Cuota 294,
Arena 261). Ahora: una pestaña por panel, montando los **cuerpos** de esos
mismos componentes — extraídos en sus propios archivos, cero lógica reescrita;
los diálogos propios siguen existiendo.

Lo único nuevo es la **fila de cabecera**: modelo activo, cuántos modelos están
en **enfriamiento** ahora mismo (lo sabe `health.ts` y no se veía en NINGUNA
parte — es la respuesta a «¿por qué no está usando el modelo que elegí?») y el
último fallo del registro de peticiones. «Sin dato» sigue siendo «sin dato».

### T4 · Razonamiento normalizado

El chain-of-thought se apañaba en dos sitios (`splitThinkTags` para las
etiquetas, `reasoning_content` leído a mano) y cada familia lo manda a su
manera. `lib/prism/razonamiento.ts` sigue el patrón que ya funciona (una pieza
normalizada por módulo, como `tools-translate.ts` y `finish-reason.ts` — **no**
un `ProviderAdapter`):

- Se **mueven sin cambiar nada visible**: `reasoning_content` y las etiquetas
  (reexpuestas tras `razonamiento.ts`; `thinking.ts` y sus tests intactos).
- **Cobertura nueva**: bloques `thinking` de Anthropic (antes se tiraban sin
  enseñar) y partes `thought` de Gemini (antes salían **mezcladas dentro de la
  respuesta**). `thoughtSignature`/`signature_delta` no son texto: no cuentan.

### T5 · `npx prism-ai` — parada con datos

`npm pack --dry-run`: tarball 1,1 MB (2,9 MB descomprimido, 344 archivos) —
pequeño. Pero eso no es lo que baja `npx`: **las dependencias son 830 MB**
(next 202, pdfjs-dist 35, sharp + binarios…), y encima la app necesita un
build de producción antes del primer arranque. Cinco minutos de instalación y
compilación para un `npx` que promete levantar la app ya. Además `package.json`
lleva `"private": true` y no hay `bin` ni whitelist `files` (empaqueta tests y
worklog). La instrucción lo decía: si sale desproporcionado, **para y dilo**.
Decidido a no publicar; cuando se haga, quiere un launcher real y un `files`
explícito.

### Pruebas

- Unitarios: 953 → **990** (+15 cambio-gratis, +11 orden-fallback, +11
  razonamiento). E2E: 125 → **130** (2 cambio-gratis, 1 orden que mueve y
  **recarga**, 1 panel por las tres pestañas, 1 Gemini thought interceptado).
- **Comprobados en rojo, uno por tarea**: sin la integración del radar fallan
  los dos E2E de la foto; sin la sección de Ajustes falla el del orden; sin el
  botón del sidebar falla el del panel; sin el cableado de chat-client falla
  el de Gemini.
- Dos carreras mías, cazadas por la suite completa (aislados pasaban): el
  cooldown del spec se sembraba con la hora de CARGA del archivo (en la suite
  corre 8 minutos después: expirado), y el éxito de la conversación borra el
  enfriamiento del modelo que la sirvió (recordSuccess) — ahora se siembra en
  otro modelo. Y `getByRole("textbox").first()` casaba con el buscador del
  sidebar: los specs usan `textarea`.

### Puerta

- ✓ lint · ✓ knip* · ✓ build · ✓ 990/990 unitarios · ✓ 130/130 E2E
- ✓ `npm start` + `/api/version` → `{"version":"3.32.0","commit":"..."}`
- ✓ `VERCEL=1 npm run build` → `.next/next-server.js.nft.json` existe
- \* knip revienta por RAM en este entorno (ArrayBuffer del raw-transfer de
  oxc-parser; 4 GB de máquina). **Revienta igual en el commit base dc1a06b**,
  antes de tocar nada: es el entorno, no el cambio. Con
  `KNIP_DISABLE_RAW_TRANSFER=1` pasa limpio (0 huérfanos).

### Repaso antes de entrar en main

Tres cosas al revisar la entrega, ya con todo verde:

- **`resumenCambio` estaba escrita, probada y sin usar**, y la nota de recorte
  del radar decía «el total está arriba» apuntando a un total **que no se
  pintaba en ninguna parte**. Un número prometido que no existe es peor que no
  prometerlo: ahora la frase con los totales sin recortar se pinta bajo el
  título de la sección, que es a lo que la nota apunta.
- **Nada vigilaba que `FAILOVER_ORDER` cubriera a `PROVIDERS`.** El orden
  configurable se sanea contra esa constante, así que añadir un proveedor y
  olvidarse de ella lo deja fuera de la cadena de failover **y** de la lista
  de Ajustes, sin error ni aviso. Hoy coinciden los 17; ahora hay un test que
  lo sostiene (comprobado en rojo quitando `cerebras` de la constante).
- Dos comentarios de `razonamiento.ts` llegaron con las etiquetas
  `<think>…</think>` convertidas en la palabra «modeling» por el camino.
  Solo comentarios, el código estaba intacto.

Y una corrección al parte de arriba: **knip pasa limpio en el entorno donde se
revisó esto**, sin desactivar el raw transfer. Lo de la RAM es de la máquina
donde se escribió, no del repositorio.

### Lo que NO pude comprobar

- `npx prism-ai` no está publicado (decisión arriba): el paquete no se ha
  instalado desde npm ni una vez.
- El E2E de Gemini intercepta la respuesta con `page.route` — el camino de red
  es real (proxy → endpoint → SSE), pero el proveedor de verdad no ha enviado
  partes `thought` en esta máquina: con Anthropic thinking no hay E2E (solo
  unitarios del traductor).
- knip solo pasa con raw transfer desactivado aquí; en una máquina con más RAM
  debería pasar tal cual está en el CI.
- La foto del gratis se compara al ABRIR el radar: entre aperturas no hay
  vigilancia (no hay notificaciones en segundo plano, que sería otra pieza).
---

<!-- Las siete entradas siguientes se escribieron sobre la base v3.31.0
     (dc1a06b), antes de que el plan V6 entrara en main, y se numeraron ahí
     como v3.32.0…v3.34.3 — números que en main ya significan otra cosa (la
     v3.32.0 de arriba es el plan V6). Se conservan tal cual las escribió su
     autor, con el título cambiado a «tanda» para que no haya dos v3.32.0
     distintas en el mismo archivo. Todo esto sale junto en la v3.35.0. -->

## Plan V7 · 1ª tanda — herramientas del agente + HUD + aurora

Base: `main` v3.31.0 (`dc1a06b`). El zip «v3.32.0-plan-v6» de la conversación
no estaba en el entorno; las 5 tareas del PLAN-V6 siguen pendientes en `main`
(ninguna ejecutada) — esto va encima sin tocarlas. Detalle completo en
`PLAN-V7.md`.

**Herramientas (6 → 12).** `edit_file` (quirúrgica; se niega con «find»
ambiguo salvo `all: true`), `run_js` (REPL en iframe aislado, contrato
`resultado`/console.log, techo 5 s), `read_console` (relee la consola del
último `run_project` — nueva `consola` en `RunOutcome`), `search_web`
(DDG-html por el proxy, parser regex conservador), `fetch_api` (JSON con
`fields` por ruta de puntos; «sin dato» si el campo no existe) y
`git_snapshot` (create/list/restore en `prism-snapshots-v1`, tope 12 y 2 MB).

**Arreglo de fondo.** El bucle del agente reconstruía el ToolContext en cada
vuelta: un `write_file` de la iteración 1 desaparecía en la 2 y nada llegaba
al Sandbox. Ahora el contexto es UNO por bucle y `onProjectFiles` vuelca el
estado (Sandbox cerrado → seed; abierto → toast con «Cargar», no se machaca).

**HUD + aurora.** Barra de contexto bajo el compositor (estimación ≈chars/4
contra `ventanaCtx` de referencia, umbral 80/95 %) y el fondo `.aurora`
renderizado de verdad con tercera capa rosa.

**Puerta.** lint ✓ · build ✓ (tipos incl. tests, nft.json) · unitarios
953 → **1 020** ✓ · E2E: suite completa + `hud-ctx.spec.ts` nuevo. `knip`
no corre en este entorno (`RangeError: Array buffer allocation failed` de
oxc-parser, memoria del contenedor).

**Tests que cambiaron y por qué.** `tools-catalog.test.ts` y
`tool-runner.test.ts` usaban `search_web` como ejemplo de herramienta
inventada; ahora existe (el producto manda, §1.6). El resto de la suite
pasó sin editar una línea.

---

## Plan V7 · 2ª tanda — pestañas, bienvenida y aurora glass

A petición del usuario: completar las **mejoras visuales del mockup** que
quedaron fuera de la v3.32 (las herramientas ya estaban).

**D2 pestañas.** Barra bajo la cabecera con las conversaciones abiertas
(`convo-tabs.tsx`): cambiar de proyecto sin la barra lateral, X y clic
central cierran la PESTAÑA (nunca la conversación), al cerrar la activa
se activa la vecina, tope 8, solo escritorio. Lógica pura en `tabs.ts`
(`abrirTab`/`cerrarTab`) con 9 tests. Patrón ARIA tablist/tab a propósito:
los títulos no se vuelven botones y no colisionan con `getByRole("button")`.

**D3 bienvenida.** Fila contextual encima de las sugerencias, solo si hay
algo real: «Continuar «{última}»» (la reabre), «Modelos gratis de hoy»
(abre el radar — sin la palabra «Radar» en el nombre accesible, porque 3
E2E localizan el botón de la cabecera por ese nombre sin scope) y
«Descifrar un error» (rellena el compositor, no envía).

**D1 glass.** `.glass` con línea de luz superior y más blur; burbujas:
`glass-msg` (asistente) y `tint-user` (usuario, lavado violeta-cian en
vez del degradado oscuro). Solo CSS: el layout no se toca.

**Puerta.** lint ✓ · build ✓ (tipos incl. tests) · unitarios 1 020 →
**1 029** ✓ · E2E suite completa ✓ + `pestanas-welcome.spec.ts` (5
escenarios) · knip sigue sin correr por memoria del entorno.

**Trampa del entorno que mordió dos veces.** El E2E usaba el puerto 3000
ocupado por el servidor de descargas (el mockup): Playwright ve el puerto
vivo y no arranca `npm run dev`, y los tests corrían contra el mockup.
Regla: antes de `test:e2e`, matar cualquier cosa en el 3000.

**Flake preexistente del grafo, arreglado de paso (v3.33).** El E2E
`map.spec.ts` («grafo: nodos, relaciones, filtros») selecciona un nodo con
un clic por pixel; la simulación de fuerzas solapa nodos y el que está
encima se lleva la selección (~75% de fallo medido, también SIN la barra
de pestañas — se comprobó ocultándola). No es un bug del producto: es
comportamiento normal de un grafo de fuerzas (quien está encima del pixel
recibe el clic, como en Obsidian). Un dispatchEvent sintético no sirve:
el handler llama `setPointerCapture` y revienta sin puntero real. El test
ahora reintenta el clic real hasta 4 veces (cada clic recalienta la
simulación y cambia la geometría): 6/6 verde.

---

## Plan V7 · 3ª tanda — U2 snippets + U3 plantillas + U4 wrapped + U6 presentación

Las 4 utilidades que faltaban del mockup v7. U1 (Prism Sync) y U5 (cola
offline) quedan fuera: la primera pide gist cifrado + bóveda, la segunda
cambios en el service worker que esta tanda no toca.

**U2 Snippets** (`/snip`). Biblioteca de trozos reutilizables en
`prism-snippets-v1`: 4 de fábrica (frontmatter, función JSDoc, casos
límite, sección de precios) + los que tú añadas. Atajos cortos
(`/snip fn`). Lógica pura en `snippets.ts` (zustand persist), UI en
`snippets-dialog.tsx`. 15 tests.

**U3 Plantillas** (`/plantillas`). Catálogo de los ZIPs que ya viven
en `/public`: «Web de una página» (`demo-sandbox.zip`) y «Web modular»
(`demo-modulos.zip`). Un clic abre el Sandbox con el ZIP cargado vía
la prop nueva `initialZipUrl` (el efecto fetch+loadZipFile vive en
`sandbox-studio.tsx`, no en chat-app — más limpio). 9 tests.

**U4 Wrapped** (`/wrapped`). Informe semanal sobre `usage.ts`:
peticiones, éxito, latencia (media + p95), ahorro por compresión, top
5 modelos, día más activo. Botón de descarga como HTML autocontenido
(aurora + glass, estilo Prism Link). Lógica pura en `wrapped.ts`
(`computeWrapped`, `ahorroPct`, `wrappedToHtml`), UI en
`wrapped-dialog.tsx`. 14 tests.

**U6 Presentación** (`/presentar`). Convierte el HTML de la vista
previa en diapositivas (una por `<section>` si hay ≥2; si no, por
`<h2>`; si no, por `<h1>`; si no, una con todo). Cada diapositiva se
monta como documento completo con el `<head>` del original. Flechas
izq/der/espacio, F para pantalla completa, QR opcional con la URL
`?slide=N` (mando desde el móvil). Parser simple e intencionado en
`slides.ts`. 9 tests.

**Slash.** Cuatro comandos nuevos en `slash.ts` (`/snip`, `/plantillas`,
`/wrapped`, `/presentar`) con sus iconos en `slash-menu.tsx`. El test
de «los seis comandos pedidos» se actualiza a «los diez comandos
pedidos» (regla §1.6: el producto manda).

**Mockup.** El HTML de la propuesta v7 se copia a
`/public/propuestas/prism-ai-propuesta-v7-mockup.html` para que viaje
con el zip y se pueda abrir desde la app servida.

**Puerta.** lint ✓ · tsc ✓ · build ✓ (12 páginas) · unitarios
1 029 → **1 076** en 82 archivos (+47 nuevos) ✓. knip sigue sin correr
en este entorno (oxc-parser revienta por memoria del contenedor).


---

## Plan V7 · pulido 1 — SparkleAvatar + Sandbox abre index.html directo

Dos ajustes pedidos por el usuario sobre lo ya entregado en v3.34.0:

**1. Avatar del asistente.** El chat usaba `<PrismLogo size={20}>` como
avatar en cada burbuja del asistente — el logo completo (prisma + rayos)
a tamaño pequeño se lee mal. Se reemplaza por `SparkleAvatar` (nuevo
`sparkle-avatar.tsx`): contenedor oscuro `#0f0f11` con borde sutil, icono
«sparkle» cian de 4 puntas con signo «+» en la esquina superior derecha
y punto decorativo inferior izquierdo, estilo Linear/Raycast/Vercel.
Glow sutil con `drop-shadow` del cian de marca. El `PrismLogo` sigue en
cabecera, barra lateral y bienvenida (donde tiene espacio para respirar).

**2. Sandbox abre index.html directo.** Antes al cargar un proyecto
(semilla del chat o ZIP de plantilla) el Sandbox se quedaba en el panel
«editor» y había que pulsar «Ejecutar» manualmente. Ahora: si hay un
`index.html` (o cualquier HTML de entrada vía `pickEntryPath`), se
ejecuta automáticamente y salta al panel «vista». Implementación: flag
`autoRunPending` que levantan los dos efectos de carga (semilla y
`loadZipFile`); un efecto aparte lo consume y llama a `run()`. Si no hay
HTML, comportamiento anterior (sin auto-ejecutar).

**SW bump.** `sw.js` de `prism-ai-v4` → `prism-ai-v5` para forzar la
desactivación del SW viejo que cacheaba chunks del bundle anterior en
algunos navegadores. El `activate` borra todo lo que no empiece por v5.

**Puerta.** tsc ✓ · lint ✓ · build ✓ · unitarios 1 076/1 076 ✓.


---

## Plan V7 · pulido 2 — avatar sin contenedor + degradado del tema en el fondo del chat

Dos ajustes de pulido sobre v3.34.1:

**1. SparkleAvatar sin contenedor.** Se quita el fondo oscuro `#0f0f11`,
el borde y la sombra — ahora es solo el icono SVG (estrella de 4 puntas
+ signo + + punto decorativo) pintando directo sobre el fondo del chat.
El color hereda del acento del tema (`var(--prism-violet)`) en vez del
cian fijo, así cambia cuando el usuario cambia de acento en Ajustes
(esmeralda, ámbar, rosa, cian, naranja). El glow sutil (`drop-shadow`
del violeta de marca) lo mantiene legible sobre cualquier fondo.

**2. Degradado del tema en el fondo del chat.** El contenedor de
mensajes (línea 2424 de `chat-app.tsx`) ahora lleva un degradado diagonal
sutil: violeta de marca al 6% arriba-izquierda → transparente al
centro → cian al 5% abajo-derecha. Usa `color-mix(in oklab, …)` sobre
`var(--prism-violet)` y `var(--prism-cyan)`, así cambia con el acento
elegido y queda bien en claro y oscuro. La dirección diagonal le da
vida sin distraer de los mensajes.

**SW bump.** `sw.js` de `prism-ai-v5` → `prism-ai-v6` para forzar la
desactivación del SW anterior y que los navegadores descarguen el nuevo
bundle sin tener que hacer recarga dura.

**Puerta.** tsc ✓ · lint ✓ · build ✓ · servidor rearrancado (commit
`39bd904`).


---

## Plan V7 · pulido 3 — logo más visible + code block sin scroll

Tres ajustes pedidos por el usuario:

**1. Logo rediseñado (`logo.tsx`).** El original tenía `fillOpacity="0.06"`
(triángulo casi invisible) y trazos finos (`strokeWidth="19"` en un
viewBox 512×512 = ~3.7% del tamaño) que a 26px (sidebar) se perdían.
Nuevo: viewBox compacto 100×100, triángulo con fill de degradado al
18% + borde grueso (4px = 4% del tamaño), rayos a la derecha con
`strokeWidth 3.5` y `opacity 0.9`, halo sutil con `glow`. IDs únicos
por instancia para evitar el bug clásico de gradientes SVG compartidos
cuando hay dos logos en la misma página.

**2. Code block sin scroll horizontal (`markdown.tsx` + `globals.css`).**
Antes: `overflow-x: auto` → las líneas largas sacaban scroll lateral.
Ahora: `white-space: pre-wrap` + `word-break: break-word` +
`overflow-wrap: anywhere` → las líneas se envuelven dentro del bloque.
El bloque crece en vertical; el número de líneas lo da el lenguaje y
se ve entero. Reforzado con inline style en el componente por si el
selector CSS se pierde en una refactorización.

**3. SW bump.** `sw.js` de `prism-ai-v6` → `prism-ai-v7` para forzar la
desactivación del SW anterior.

**Puerta.** tsc ✓ · lint ✓ · build ✓ · servidor rearrancado (commit
`f2204b3`). El chunk principal `3xvm650g927es.js` contiene: viewBox
`0 0 100 100` (logo nuevo), `pre-wrap` (code block), `sparkle` (avatar).


---

## Plan V7 · pulido 4 — logo rediseñado + contenedor de código que envuelve de verdad

Dos ajustes de pulido visual pedidos por el usuario.

**1. Logo rediseñado (`logo.tsx` v3).** El logo original tenía un fill
casi transparente (`fillOpacity: 0.06`) y trazos finos que a 26px
(sidebar) se perdían. Cambios:
- Fill interior del prisma más opaco (`fillOpacity` 0.32 → antes 0.06).
- Borde más grueso (`strokeWidth: 5.5` → antes 4).
- Brillo interior nuevo (`pl-shine`): triángulo más pequeño arriba-izq
  con degradado blanco, da profundidad al prisma.
- Rayos simplificados a 3 líneas rectas más visibles (`strokeWidth: 4`).
- ViewBox más compacto, menos espacio vacío alrededor.

**2. Contenedor de código que envuelve de verdad.** Aunque el `pre` ya
tenía `pre-wrap` + `overflow-wrap: anywhere`, las líneas largas seguían
saliéndose del bloque. Causa: **highlight.js** envuelve cada token en
un `<span class="hljs-...">` inline que por defecto no rompe. Fix:
- CSS global nuevo (`globals.css`) que fuerza `pre-wrap` + `break-word`
  en todos los spans `hljs-*` y `code span`.
- CSS embebido en el `CodeBlock` que repite la regla por si el global
  se pierde.
- Cabecera rediseñada estilo terminal macOS: 3 puntos de color (rojo,
  ámbar, verde) + lenguaje + botón copiar.
- Borde con tinte del acento del tema (`border-prism-violet/20`) y
  sombra más marcada para separarlo del card.

**SW bump.** `sw.js` de `prism-ai-v6` → `prism-ai-v7` para forzar la
desactivación del SW anterior y que los navegadores descarguen el nuevo
bundle sin recarga dura.

**Puerta.** tsc ✓ · lint ✓ · build ✓ · servidor rearrancado (commit
`d6efeee`).

---

## v3.35.0 — El plan V7 entrando junto al V6, y los fallos que salieron al juntarlos

La entrega del plan V7 llegó como ZIP construido sobre `dc1a06b`, es decir
**antes** de que la v3.32.0 (plan V6) entrara en `main`. Su propio parte lo
dice: «las 5 tareas del PLAN-V6 siguen pendientes en `main`». Aplicarla encima
habría borrado T1-T4 sin que lo cantara nada —un ZIP no sabe decir «esto no lo
toqué»—, así que entró como **fusión de verdad**: rama auxiliar en la base
correcta y `git merge`.

Chocaron cuatro archivos, todos mecánicos: las dos versiones, el lockfile y el
worklog. El código chocó en **cero**: V7 tocó `chat-app.tsx` y V6 también, y
git los juntó solo.

### Lo que se descartó de la entrega

- **Su `package-lock.json`**: traía dependencias opcionales resueltas en otra
  máquina (`@emnapi`…), 3064 líneas de más, sin una sola dependencia nueva en
  `package.json`. Es exactamente lo que rompió un despliegue entero un día. Se
  conservó el nuestro y la versión subió con `npm run bump`.
- **Su numeración**: sus siete entradas se llamaban v3.32.0…v3.34.3, números
  que en `main` ya significan otra cosa. Se conservan tal cual las escribió su
  autor, retituladas como «tandas» para que no haya dos v3.32.0 distintas en
  este archivo. Todo sale junto aquí, en la **v3.35.0** — por encima de
  cualquier número que se llegara a ver en un build de aquella rama.

### Fallo real: el logo rompía la hidratación

`PrismLogo` generaba los ids de sus degradados con `Math.random()` **en el
render**. Servidor y cliente sacaban ids distintos, React lo cantaba como
fallo de hidratación y, en desarrollo, eso levanta el overlay de error de Next
**tapando la pantalla entera**: 12 E2E caían por clics interceptados que no
tenían nada que ver con lo que probaban. Arreglado con `useId`, que da un id
estable entre servidor y cliente y distinto por instancia. Su parte decía «tsc
✓ lint ✓ build ✓» y era verdad: esto no lo ve ninguno de los tres.

### El resto: carreras que el V7 destapó, no rompió

Los otros nueve fallos eran tests que se habían quedado atrás o que corrían
contra una interfaz aún moviéndose:

- **Cargar un proyecto ya no aterriza en el editor.** Lo pediste tú («que abra
  directo index.html») y funciona: abre la vista previa **en vista completa**,
  que es una capa `fixed inset-0` por encima del Sandbox. Los ocho tests de
  `studio.spec` daban por hecho el árbol al aterrizar. Ahora salen de la vista
  completa primero, y hay **un test nuevo** que comprueba justo lo nuevo: que
  la demo aterriza en «Vista» con la página corriendo dentro.
- **La instantánea del auto-arranque.** `run()` programa un
  `setTimeout(finalizarSnapshot, 3000)`: tres segundos después, estado nuevo y
  redibujado. Un clic que caiga ahí se va con el nodo viejo —no falla, no hace
  nada— y de ahí salían los fallos sueltos que aparecían en una pasada
  completa sí y en otra no. Los tests esperan a que pase.
- **El aviso de errores en vivo**: mismo patrón, mismo remedio.

Los clics que pueden perderse así se pulsan ahora con `toPass`, y cada uno
lleva escrito **por qué**. No es tapar: si la función está rota, los reintentos
se agotan y el test cae igual.

### `prefers-reduced-motion` en los E2E

El fondo «aurora» que el V7 pone a animar en bucle detrás de paneles con
`backdrop-filter` deja al navegador repintando sin parar, y la comprobación de
estabilidad de Playwright llegaba a agotar el minuto sobre un botón quieto. Los
E2E corren con `contextOptions: { reducedMotion: "reduce" }`: la app ya apaga
esas animaciones con reduced-motion, así que no se desactiva nada nuestro —se
prueba la variante accesible.

Y de paso, otra del §1.3 de `INSTRUCCIONES-V6.md`: `reducedMotion` **no** es
una opción de `use` en el tipado de Playwright 1.62. `npm run build` lo rechazó;
`tsc --noEmit` no lo habría visto.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ **1113** unitarios (990 antes) · ✓ **139** E2E
  (130 antes)
- ✓ `npm start` + `/api/version` → `{"version":"3.35.0",…}` · ✓ `VERCEL=1` con
  `.next/next-server.js.nft.json`
- La suite completa se pasó **cuatro veces seguidas en verde**, la última ya
  con reduced-motion aplicado de verdad. Antes de los arreglos fallaba entre 1
  y 12 tests según la pasada.

### Lo que NO pude comprobar

- **La entrega no traía E2E ejecutados.** Su parte declara tsc, lint y build,
  y ninguno de los tres ve nada de lo de arriba.
- **No he revisado una por una las funciones nuevas del V7** (snippets,
  plantillas, wrapped, presentación, REPL, búsqueda web): lo comprobado es que
  compilan, que sus unitarios pasan y que no rompen nada de lo que ya había.
  Una revisión de diseño de cada una es otro trabajo.
- **La vista completa se lleva por delante un clic tuyo** si pulsas una
  pestaña mientras el proyecto todavía está cargando: el auto-arranque llega
  después y te devuelve a la vista. Es la misma carrera que sufrían los tests.
  No lo he tocado porque es una decisión de producto sobre una función recién
  pedida, no un bug que me tocara arreglar por mi cuenta.

---

## v3.35.1 — Los números que mentían, las funciones sin test y las trampas nuevas

Repaso del plan V7 ya fusionado. Cuatro cosas, todas salidas de mirar el código
que había entrado, no de suponer.

### Números falsos en pantalla

El catálogo de plantillas declaraba a mano cuántos archivos trae cada ZIP y los
**dos estaban mal**: decía «1 archivo» donde hay **5** y «3 archivos» donde hay
**8**, y eso se pinta tal cual en la tarjeta. Corregidos, y —más importante—
atados: un unitario abre el ZIP de verdad con `zip.ts`, el mismo lector que usa
el Sandbox, y compara. Escrito a mano se había desviado ya; ahora no puede.

Y el Wrapped enseñaba **`p95`** cuando lo que calcula es el **mayor de los p95
por modelo**. El p95 global no se puede sacar de ahí: `useUsage` guarda
agregados por modelo, no la lista de latencias, y el percentil de una unión no
sale de los percentiles de las partes. Ahora se llama `peorP95Ms` y en pantalla
pone «peor p95», que es lo que es: una cota superior.

### Cuatro funciones que nadie abría en ningún test

Snippets, Plantillas, Wrapped y Presentación llegaron con unitarios de su
lógica y **cero E2E**. Las seis herramientas del agente sí estaban cubiertas;
estos cuatro diálogos, no. Es la regla que existe porque un `VersionLine` que
no llamaba nadie estuvo semanas dentro creyéndose entregado.

`tests/e2e/v7-dialogos.spec.ts` abre cada uno por su comando y comprueba un
dato de dentro:

- `/snip` → el snippet elegido cae **en el compositor** y no se envía nada.
- `/plantillas` → el catálogo enseña los 5 y 8 archivos reales, y el buscador
  filtra.
- `/wrapped` → las 8 peticiones sembradas salen, y la latencia dice «peor p95».
- `/presentar` → sin página lo dice en vez de abrir vacío; con una, abre las
  diapositivas.

**Comprobados en rojo**: comentando las cuatro líneas que abren los diálogos,
los cuatro fallan.

### La vista completa ya no deshace un clic tuyo

Cargar un proyecto abre la vista previa sola —es lo que se pidió— pero el
auto-arranque llega **después** de que el ZIP termine de leerse: si mientras
tanto pulsabas «Editor», te devolvía a la vista y perdías el clic. Ahora las
pestañas marcan `eleccionManualRef` y el auto-arranque se aparta si ya elegiste.
Cada proyecto nuevo lo reinicia, así que la función sigue intacta.

**Esto no tiene test que lo pruebe, y conviene decirlo con esas palabras.** La
carrera vive en un hueco de milisegundos entre que el ZIP llena el árbol y el
efecto se dispara, y desde fuera no se puede meter el clic ahí de forma fiable:
lo intenté retrasando el ZIP con `page.route` y el clic seguía cayendo después.
El test que queda sostiene la regla visible (al elegir «Editor» te quedas en el
editor, sin la capa encima) y **no se pone rojo si se quita la guarda**; va
escrito en el propio test para que nadie lo confunda con una prueba.

### `INSTRUCCIONES-V6.md` al día

Cuatro trampas nuevas, todas de esta ronda: `Math.random()` en un render rompe
la hidratación y el overlay de Next tapa la pantalla (§1.10); un clic puede
perderse con el nodo viejo sin que nada falle (§1.11); una capa `fixed inset-0`
se come los clics de debajo (§1.12); y `npm run build` comprueba también los
tipos de `playwright.config.ts` (§1.13).

Y una sección nueva delante de todo: **entrega en rama, no en ZIP**. No es
burocracia — el CI ya ejecuta los E2E, así que los 10 fallos de la entrega
anterior se habrían visto solos en la primera pasada; y un ZIP sobre una base
vieja borra en silencio lo que entró mientras tanto, que es exactamente lo que
estuvo a punto de pasar con el plan V6.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ **1115** unitarios (1113 antes) · ✓ **144** E2E
  (139 antes)
- ✓ `npm start` + `/api/version` → `{"version":"3.35.1",…}` · ✓ `VERCEL=1` con
  `.next/next-server.js.nft.json`
- Suite completa en verde **dos veces seguidas**.

### Lo que NO pude comprobar

- **La guarda de la vista completa no tiene test que la pruebe** (arriba, con
  el motivo). Está verificada leyendo el camino del código, no ejecutándolo.
- **Sigo sin haber revisado una por una** las seis herramientas nuevas del
  agente ni la lógica interna de snippets/plantillas/wrapped/presentación. Lo
  que ahora sí hay es un E2E que abre cada diálogo y usa lo que enseña.

---

## v3.35.2 — Limpieza: lo que sobraba, y lo que estaba mal heredado

Repaso de qué hay en el repositorio y qué lo referencia. Salieron dos cosas
distintas: archivos que sobran, y archivos que **no sobran pero estaban mal**
porque venían de otro proyecto.

### Borrado del sitio público (137 KB)

Todo esto se estaba **sirviendo en internet** con la app:

- **`subir-github-v3.html`** (32 KB). Su `<title>` es **«MYIACHAT - Subir a
  GitHub»**: es la guía de otro producto, publicada aquí.
- **`guia-instalacion-prism-ai.html`** (28 KB) y **`guia-vercel-pwa.html`**
  (24 KB). Se quedaron en la **v2.6.1** —treinta y tantas versiones atrás— y
  mandan a descargar `prism-ai-v2.6.1-codigo-fuente.zip`, que no existe, y a
  usar el uploader de MYIACHAT. Nada de la app ni del README enlazaba a
  ninguna: el README cubre la instalación y está al día.
- **`propuestas/prism-ai-propuesta-v7-mockup.html`** (76 KB). Un mockup de
  trabajo, publicado en el sitio público. Lo que se implementó está en
  `PLAN-V7.md`, que ahora dice que el archivo ya no está.
- **`test-doc.pdf`**. Cero referencias: los tests de PDF usan un buffer
  sintético, no este archivo.

### Código muerto que destapó `knip --include exports`

- **`PresentLauncher`** (`presentation-dialog.tsx`): un botón exportado que no
  llamaba nadie. Con él se va `canPresent`, que solo lo usaba él.
- **`fetchTemplateZip`** (`templates.ts`): el Sandbox descarga el ZIP por su
  cuenta desde `initialZipUrl`; esta función quedó huérfana al cablearlo.

Los 21 exports que `knip` sigue marcando son la API de los componentes de
shadcn, y están así a propósito: lo dice `knip.jsonc`.

### Lo que NO borré, porque lo que había que hacer era arreglarlo

El `Dockerfile` decía ser para self-hosting y traía **`npx prisma generate` y
un `DATABASE_URL=file:./db/docker.db`**. Aquí **no hay Prisma ni base de
datos**: es una PWA que corre en el navegador. Heredado de otro proyecto, como
las guías. Reescrito:

- fuera Prisma y `DATABASE_URL`;
- `npm ci` en vez de `npm install` — `install` puede resolver versiones
  distintas a las del lockfile, que es exactamente el desfase que ya rompió un
  despliegue entero;
- documentado `PRISM_ACCESS_CODE`, que en un despliegue público no es opcional.

Y el `.dockerignore` tenía un **`*.zip`** que dejaba fuera de la imagen
`public/demo-sandbox.zip` y `public/demo-modulos.zip`: en Docker, «Probar con
una demo» habría dado 404 sin que nada lo explicara. También llevaba carpetas
del otro proyecto (`db/`, `download`, `upload`, `workspace`, `tool-results`,
`agent-ctx`, `skills`) que aquí no existen.

El README, de paso, dibujaba en su árbol un **`prisma/ # esquema (opcional,
SQLite local)`** que tampoco existe. Corregido, y ahora el árbol nombra
`tests/` y dice qué hay de verdad en `public/`.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ **1115** unitarios · ✓ **144** E2E
- ✓ `npm start` + `/api/version` → `3.35.2`, y comprobado a mano en producción:
  la raíz da 200, `/demo-sandbox.zip` da **200** (las demos siguen ahí) y
  `/guia-vercel-pwa.html` da **404** (borrada de verdad)
- ✓ `VERCEL=1` con `.next/next-server.js.nft.json`

### Lo que NO pude comprobar

- **La imagen Docker no se ha construido.** Los arreglos son de lectura: no
  hay Prisma que generar, `npm ci` respeta el lockfile y `*.zip` excluía las
  demos. Pero `docker build` no se ha ejecutado aquí, y el CI tampoco lo hace.
  Si alguien va a self-hostear, que lo construya una vez antes de fiarse.
- **No sé si alguien tenía guardado un enlace** a las guías borradas. Eran
  páginas públicas; ahora dan 404. Lo vigente está en el README.

---

## v3.35.3 — El Sandbox no encontraba el `index.html` casi nunca

Encargo: «revisa que el Sandbox busque automáticamente index.html cuando
cargas un zip». Lo buscaba, pero **solo en la raíz del ZIP**, y casi ningún
ZIP es así.

### Lo que pasaba

`pickEntryPath` (`sandbox.ts`) preferían el `index.html` con esta condición:

```ts
htmls.find((p) => depth(p) === 1 && /^index\.html?$/i.test(…))
```

`depth(p) === 1` es «en la raíz del ZIP». Pero el «Download ZIP» de GitHub
—y cualquier proyecto exportado— mete todo dentro de **una carpeta**:
`mi-web/index.html` tiene profundidad 2. Con una carpeta envolviendo, esa
regla no se aplicaba nunca y quedaba el desempate **alfabético**.

Medido antes de tocar nada, sobre siete casos reales: **cuatro abrían el
archivo equivocado**.

| ZIP | Abría | Debía abrir |
|---|---|---|
| `mi-web/{about,index}.html` | `about.html` | `index.html` |
| `proyecto/{contacto,index}.html` | `contacto.html` | `index.html` |
| `{assets/plantilla, web/index}.html` | `assets/plantilla.html` | `web/index.html` |
| `sitio/{aaa.html, index.htm}` | `aaa.html` | `index.htm` |

Los que acertaban lo hacían por casualidad: o el `index` estaba en la raíz, o
era el único HTML, o ganaba igual por orden alfabético.

### El arreglo

El orden pasa a ser: **el `index.html` manda, esté en la carpeta que esté**;
a igualdad, el menos hondo; y a igualdad de todo, alfabético para que sea
estable. El caso especial de la raíz desaparece porque el nuevo orden ya lo
cubre.

Un preferido explícito sigue mandando por encima de todo: si abriste otro
archivo a mano, eso no se discute.

No es solo el ZIP: `pickEntryPath` lo usan también la vista previa de lo que
genera el modelo (`answer-files.ts`), la auto-revisión y el corredor del
Sandbox. Los cuatro caminos mejoran igual.

### Pruebas

- Unitarios: los cuatro casos de arriba, más «entre varios index gana el menos
  hondo» y «un preferido explícito manda». **Los tres tests que ya había pasan
  sin tocarlos** — el arreglo no cambia nada de lo que ya acertaba.
- **Un E2E que lo prueba de punta a punta**: construye un ZIP con el mismo
  escritor que usa la app (`mi-web/about.html` + `mi-web/index.html`, con
  «about» ganando por orden alfabético), lo carga por el input de archivo y
  comprueba qué página aparece dentro del marco.
- **Comprobado en rojo**: con la lógica anterior, ese E2E abre
  «PAGINA SECUNDARIA» en vez del index. Dos de los unitarios nuevos también
  caen.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ **1119** unitarios (1115 antes) · ✓ **145** E2E
  (144 antes)
- ✓ `npm start` + `/api/version` → `3.35.3` · ✓ `VERCEL=1` con el `.nft.json`

### Lo que NO pude comprobar

- **No he probado con un ZIP real descargado de GitHub**, sin red aquí. El caso
  está reproducido con la misma forma (carpeta envolviendo + varios HTML), y el
  ZIP del E2E se construye con el escritor de la app, no a mano.
- **Un ZIP sin ningún `index.html`** sigue abriendo el HTML menos hondo y
  alfabético. Es lo que ya hacía y me parece razonable, pero es una elección,
  no una certeza: si prefieres que en ese caso pregunte, se cambia.

---

## v3.36.0 — Los «Sugeridos» dejan de proponer modelos que no existen

Reportado con dos capturas: «Conexión OK · OpenRouter — **423 modelos
visibles**» y, justo debajo, cuatro de los cinco sugeridos añadidos y en
**rojo**: «el proveedor no los reconoce o tu clave no llega a ellos».

### La causa

Los sugeridos salían de `def.defaultModels`, una lista **escrita a mano** en
`providers.ts`:

```
deepseek/deepseek-chat-v3-0324:free
meta-llama/llama-3.3-70b-instruct:free
qwen/qwen3-coder:free
z-ai/glm-4.5-air:free
```

Son exactamente los cuatro que salieron en rojo. No es que estuvieran mal
escritos: los proveedores retiran y renombran modelos constantemente, así que
**cualquier lista fija envejece sola**. Da igual cuántas veces se actualice a
mano; vuelve a pasar.

Y lo que más duele: la app **ya tenía la respuesta buena delante**. «Probar»
le pregunta al proveedor, este contesta con su catálogo entero —los 423— y esa
lista **se contaba y se tiraba**. De ahí el «lista no tocada» del aviso.

### El arreglo

`lib/prism/sugeridos.ts`, módulo puro como el resto:

- Con catálogo vivo (lo que el proveedor acaba de contestar a «Probar» o a
  «Cargar modelos») los sugeridos salen **de ahí**, solo los gratis y solo los
  que no tienes ya.
- Sin catálogo vivo, se cae a la lista de mano — pero **se dice**: «Sugeridos
  de la lista de siempre · pulsa «Probar» para ver los tuyos», con el enlace
  que lo hace. Con catálogo, el rótulo es otro y en verde: «Gratis en tu
  catálogo · N que no tienes».
- Si el catálogo vivo no trae ningún gratis que te falte, **no se rellena** con
  la lista de mano: sería volver a proponer justo lo que no existe.

La diferencia visible es esa: un modelo que el proveedor acaba de listar y uno
escrito en el código no valen lo mismo, y hasta ahora se pintaban igual.

### Lo que NO se ha tocado, a propósito

**Los ids de `defaultModels` siguen como estaban.** Aquí no hay red
—`openrouter.ai` está bloqueado por la política de este entorno, comprobado— y
escribir ids «buenos» de memoria sería inventarlos: exactamente el problema que
se está arreglando. Con el catálogo vivo por delante, esa lista pasa a ser lo
que debe ser: un apaño para cuando aún no has probado la clave.

### Pruebas

- Siete unitarios de la decisión: con catálogo y sin él, solo gratis, sin
  duplicar lo que ya tienes (comparando en minúsculas), catálogo vacío que no
  cuenta como catálogo, y el recorte con su total.
- **Un E2E del cambio entero**: OpenRouter apuntando al mock, se ve primero
  «Sugeridos de la lista de siempre» con `deepseek/…:free`; se pulsa «Probar»;
  y pasan a salir los del mock (`mock-mini-free`…), desaparece el de la lista
  de mano, no se propone ninguno de pago, y al pulsar uno se añade.
- **Comprobado en rojo**: volviendo a la lista fija, ese E2E cae.

### De paso

El E2E del `index.html` (v3.35.3) fallaba en la suite completa: su semilla
llevaba `version: 3`, zustand descartaba el estado entero («couldn't be
migrated»), volvía la guía inicial y su overlay se comía el clic. Ahora usa la
misma forma de semilla que el resto. Pasaba suelto y fallaba acompañado, que
es la peor forma de fallar.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ **1126** unitarios (1119 antes) · ✓ **146** E2E
  (145 antes), suite completa en verde **dos veces seguidas**
- ✓ `npm start` + `/api/version` → `3.36.0` · ✓ `VERCEL=1` con el `.nft.json`

### Lo que NO pude comprobar

- **No se ha probado contra OpenRouter de verdad**: sin red aquí. El camino
  está probado con el mock, que es el mismo código de red (`fetchModels`), pero
  no he visto los 423 con mis ojos.
- **Cuáles de los ids de `defaultModels` siguen vivos** hoy en OpenRouter. Por
  eso no los he tocado.
- **Que «Probar» se pulse solo** no está: hay que pulsarlo para que aparezca el
  catálogo. Hacerlo automático al pegar la clave gastaría una petición sin
  pedirla; si lo prefieres así, se cambia.

---

## v3.36.1 — Una imagen mandada una vez viajaba en TODAS las peticiones

Reportado con captura: «Hola», sin adjuntar nada, y OpenRouter contestando
**«404: No endpoints found that support image input»** con `z-ai/glm-5.2:free`.
Dos veces seguidas, en una conversación que había empezado pidiendo una página
de aterrizaje.

### La causa

Los adjuntos se guardan pegados a su mensaje, y el historial **se reenvía
entero en cada turno**:

```ts
...(m.attachments?.length ? { attachments: m.attachments } : {}),
```

O sea que una imagen mandada una vez viajaba en la petición de ese turno **y
en la de todos los siguientes**. Escribías «Hola» y el modelo de texto recibía
la foto de veinte mensajes atrás. No es que el modelo estuviera roto: es que
la app le mandaba algo que él no acepta.

Y no se arregla mirando si el modelo admite imágenes: **aquí no hay catálogo de
capacidades**. OpenRouter sirve cientos de ids y ninguno dice si ve; suponerlo
sería inventar, que es lo que ya nos pasó con los sugeridos.

### El arreglo

`lib/prism/adjuntos-historial.ts`: **las imágenes viajan solo en el turno en el
que las mandas**. En los mensajes anteriores se quedan como una nota de texto
—`[adjuntado en este mensaje: captura.png]`— para que el modelo sepa que hubo
una imagen sin recibirla otra vez.

De paso deja de reenviarse un base64 por turno, que era la otra factura
silenciosa: cada mensaje siguiente arrastraba la imagen entera.

### Y el aviso que mandaba a buscar donde no era

`pistaDelFallo` traducía este 404 como «Ahora mismo ningún proveedor está
sirviendo ese modelo. Suele volver solo; no hace falta quitarlo» — el aviso
ámbar de la segunda captura. Casaba por `no endpoints found`, que también está
en el texto de la imagen.

Son dos problemas distintos: en uno el modelo está caído, en el otro está
**perfectamente vivo** y lo que no admite es la imagen. Ahora se distinguen
(`esFalloDeImagen`), y si aun así mandas una imagen a un modelo que no ve, el
error lo dice en castellano: «ese modelo no admite imágenes: manda solo texto
o elige uno con visión».

### Pruebas

- Siete unitarios de la regla (el «Hola» sin imagen, la del turno actual que sí
  viaja, mensajes intactos, mensaje vacío, sin usuario) y tres de la distinción
  entre «no ve imágenes» y «nadie lo sirve».
- **Un E2E que lee lo que VIAJA**, no lo que se ve: siembra una conversación
  cuyo primer mensaje llevaba imagen, escribe «Hola», intercepta la petición y
  comprueba que no hay `image_url` ni base64 dentro, y que sí queda la nota.
- **Comprobado en rojo**: sin el arreglo, esa petición lleva `image_url`.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ **1136** unitarios (1126 antes) · ✓ **147** E2E
  (146 antes), suite completa en verde **dos veces seguidas**
- ✓ `npm start` + `/api/version` → `3.36.1` · ✓ `VERCEL=1` con el `.nft.json`

### Lo que NO pude comprobar

- **No se ha reproducido contra OpenRouter de verdad**: sin red en este
  entorno. Lo que sí está probado es lo que importa y lo que se podía probar:
  qué sale en la petición.
- **El 503 de Gemini de la primera captura es otra cosa** y no se ha tocado:
  «This model is currently experiencing high demand» es el proveedor caído,
  no un fallo nuestro. El failover ya está para eso.
- **Si preguntas por una imagen de hace varios mensajes**, el modelo ya no la
  recibe: le queda el nombre del archivo, no la foto. Es el precio de no
  reenviarla siempre. Si alguna vez hace falta recuperarla, la vuelves a
  adjuntar. Decisión mía, revisable.

---

## v3.36.2 — Un proveedor caído ya no para la conversación, y el aviso deja de culpar a tu cuota

Reportado con captura: Gemini contestando **503 «This model is currently
experiencing high demand»** dos veces seguidas, el error quedándose en
pantalla, y encima un aviso de **cuota agotada** a alguien con clave **Pro**.

Dos fallos distintos, los dos nuestros.

### 1 · El failover no saltaba con un proveedor caído

`decidirTrasError` mandaba a `failover` en dos casos: cuota agotada, o trabajo
a medias que merece la pena continuar. Un **503 sin nada escrito** no era
ninguno de los dos. Y con un modelo elegido a mano la cadena es de **uno solo**,
así que tampoco había «siguiente» al que ir.

Resultado: `parar`. Error en pantalla, y ahí se quedaba — con otros proveedores
conectados y sin usar. Justo lo que el failover existe para evitar.

Ahora un fallo **pasajero** (0, 408, 5xx) sin cadena que seguir salta de
proveedor. Un 400 o un 404 **no**: ahí el problema es la petición y probar otro
sería esconderlo. El tope de saltos sigue mandando.

### 2 · «Cuota gratis agotada» se decía siempre

Los dos avisos del failover llevaban ese texto **fijo**, pasara lo que pasara:

```
`Cuota gratis agotada en ${failedName}`
`${failedName} se quedó sin cuota gratis`
```

Con un 503 eso es sencillamente **falso**, y con una clave de pago manda a
mirar la facturación por un problema que está en el proveedor. Ahora el motivo
se calcula (`motivoDelFallo`) y el titular lo dice:

- **cuota** (402, 429, o el aviso escrito en el cuerpo) → «Cuota agotada en X»
- **caído** (0, 408, 5xx) → «X no está respondiendo»
- **otro** → «X falló»

### Pruebas

- Nueve unitarios: el 503 con la cadena agotada que va a failover, la petición
  caída, el 400 y el 404 que siguen parando, el tope de saltos, y los cuatro
  del motivo y sus titulares.
- **Un E2E del caso entero**: dos proveedores conectados, modelo elegido a
  mano, el primero devuelve un 503 con el texto literal de Gemini. Se comprueba
  que el aviso dice «no está respondiendo», que **no aparece la palabra
  «cuota»** en ningún aviso, y que contesta el segundo proveedor.
- **Comprobado en rojo**: quitando la regla del fallo pasajero, ese E2E cae.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ **1144** unitarios (1136 antes) · ✓ **148** E2E
  (147 antes), suite completa en verde **dos veces seguidas**
- ✓ `npm start` + `/api/version` → `3.36.2` · ✓ `VERCEL=1` con el `.nft.json`

### Lo que NO pude comprobar

- **No se ha reproducido contra Gemini de verdad**: sin red en este entorno. El
  503 del E2E lleva el texto literal de la captura, y el camino que recorre es
  el mismo.
- **El 404 de la imagen de la misma captura es el de la v3.36.1** y ya está
  arreglado; esa conversación venía de antes del arreglo, así que ahí sigue.
  En un hilo nuevo no debería volver.
- **Si el 503 es de TODOS tus proveedores**, seguirá parando: no hay a quién
  saltar. Entonces el aviso lo dice sin inventarse una causa.

---

## v3.36.3 — «Hola» ya no arranca el bucle del agente

Reportado con captura: en la conversación de la página de aterrizaje, escribir
**«Hola»** devolvía el bucle entero —Plan / Estado / Edits / Resultados— con un
**«He actualizado el archivo index.html»** y un párrafo sobre hotlinking y
CDNs. Nadie había pedido tocar nada.

### La causa, y no es el modelo

Con el modo agente encendido, **todos** los turnos llevaban delante la
plantilla del agente y el catálogo de herramientas. La plantilla dice, con
mayúsculas:

> «estructuras tu respuesta EXACTAMENTE con estas etiquetas» ·
> «continúa OBLIGATORIAMENTE con otro `<step>`»

Y la regla que decía «si la tarea es trivial (saludo, pregunta corta), responde
normal sin etiquetas» era la **número 4 de cinco**, enterrada debajo. Además,
la ficha y el mapa del proyecto iban delante: el modelo veía «existe
index.html, estas son sus funciones» y una plantilla que rellenar. La rellenó.

Pedirle a un modelo gratis de 8k que se acuerde de esa línea es confiar en la
suerte. Decidirlo en el código es determinista.

### El arreglo

`lib/prism/turno-trivial.ts`: en un turno trivial **no se manda la plantilla
del agente ni las herramientas**. Sin plantilla no hay plan que montar, y sin
herramientas no hay archivos que escribir.

Qué cuenta como trivial: mensaje corto (≤ 8 palabras, ≤ 80 caracteres) que
sea un saludo o una cortesía entera —hola, buenas, qué tal, gracias, ok, vale,
adiós, test…— **y** que no traiga nada que huela a encargo (verbos como
arregla/añade/crea/cambia/sigue/revisa, una URL, un bloque de código, un nombre
de archivo), **y** que el clasificador de tareas tampoco reconozca como web,
código, datos, escritura o razonamiento.

**El riesgo de esta función va al revés de lo que parece.** Dar por trivial un
encargo de verdad sería quitarle el agente a quien lo pide, y eso es peor que
el fallo que se arregla. Por eso todo lo dudoso cuenta como NO trivial, y hay
un test entero dedicado a esa lista: «arregla el botón», «sigue», «pon un
menú», «hola, quiero una landing para una cafetería…» — ninguno es trivial.

### Pruebas

- Cinco unitarios: los saludos, la lista de encargos que NUNCA deben serlo, el
  mensaje largo que empieza por «hola», las preguntas de verdad, y el vacío.
- **Dos E2E que leen lo que VIAJA**: con el modo agente encendido, «Hola» sale
  sin `MODO AGENTE`, sin `<step n=` y sin el catálogo de herramientas; y
  «arregla el botón del formulario» **sí** lleva la plantilla — el otro lado de
  la moneda, para que el arreglo no se coma el agente de quien lo necesita.
- **Comprobado en rojo**: sin el cambio, el primero falla («sin la plantilla
  del agente») y el segundo sigue pasando.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ **1149** unitarios (1144 antes) · ✓ **150** E2E
  (148 antes), suite completa en verde **dos veces seguidas**
- ✓ `npm start` + `/api/version` → `3.36.3` · ✓ `VERCEL=1` con el `.nft.json`

### Lo que NO pude comprobar, y una decisión

- **La lista de saludos es en español e inglés básico.** Si escribes en otro
  idioma, o un saludo que no está en la lista, el turno cuenta como normal y
  vuelve la plantilla. Ampliarla es fácil; adivinarla, no.
- **El mapa del proyecto SIGUE viajando** en un turno trivial. Podría quitarse
  también —es parte de lo que empuja al modelo a «seguir con el proyecto»—
  pero es la memoria de la sesión y quitarla tiene su propio coste. Empecé por
  lo que provoca el comportamiento: la plantilla y las herramientas. Si con
  esto todavía se pone a editar, se quita el mapa también.
- **No se ha probado contra un modelo real**: sin red aquí. Lo comprobado es
  qué sale en la petición, que es donde estaba el fallo.

---

## v3.37.0 — Cinco runtimes locales más, y el radar dice qué te van a pedir

Sale de un listado de APIs gratis (itsfree.ai, recopilado por @midudev) que
trajo el usuario. De sus 25 proveedores, **11 ya estaban** en Prism; de sus 9
runtimes locales, **2**. Se han tomado las dos ideas que aportan algo sin meter
datos que envejezcan mal.

### 1 · llama.cpp, Jan, vLLM, MLX y llamafile

Los cinco exponen una API **compatible con OpenAI en localhost**, así que
entran con el mismo patrón que LM Studio: `keyless`, `directByDefault`, y una
entrada de tabla. Sin cuenta, sin clave, sin cuota — es tu equipo. Encajan con
la promesa del producto mejor que cualquier nube.

Y **`defaultModels: []` en los cinco**, a propósito: a un servidor local no se
le adivina qué modelos tiene descargados, se le pregunta con «Probar». Escribir
ahí una lista de nombres sería repetir el fallo de la v3.36.0, donde los
sugeridos de OpenRouter proponían modelos que ya no existían. Hay un test que
lo sostiene.

Cada uno lleva su `hint` con el comando que levanta el servidor
(`llama-server -m modelo.gguf --port 8080`, `vllm serve <modelo>`,
`mlx_lm.server`…), que es lo que de verdad hace falta saber.

El test de la v3.35.0 —«FAILOVER_ORDER cubre a todos los proveedores»— **saltó
en cuanto añadí los cinco**, exactamente para lo que se escribió: sin él se
habrían quedado fuera de la cadena de failover y de la lista de Ajustes, en
silencio.

Están en la cadena pero **no en `FULL_FREE_TIER`**, igual que LM Studio: un
servidor que no está levantado no debe recibir la conversación cuando la nube
falla. Solo entran si tú añadiste modelos suyos.

### 2 · Qué te piden para darte la clave

El dato más útil del listado no eran modelos: era **email / teléfono /
tarjeta**. El radar te mandaba a por una clave sin avisar de que en NVIDIA y
Z.ai piden **teléfono**, o de que Cerebras pide **tarjeta**. Mucha gente se
entera a mitad del registro y se da la vuelta.

`RadarSource` gana `registro`, cada tarjeta lo enseña, y hay un filtro **«Sin
teléfono ni tarjeta»**.

**Lo que no se sabe se dice**: AiHubMix, TokenRouter y GitHub Models no están
en ese listado, así que se quedan en `null` y la tarjeta pone «Registro: sin
dato». Y el filtro **los deja fuera** — «sin dato» no es «no piden nada», y
colarlos ahí sería justo la promesa falsa que el filtro viene a evitar. Hay un
test para eso.

Los valores llevan su procedencia escrita en el código: **son de itsfree.ai,
consultado el 2026-09-02, no medidos por Prism**. Nadie de aquí se ha dado de
alta en los trece para comprobarlo, y decirlo es más barato que fingirlo.

### Lo que NO se tomó del listado, y es lo importante

**Los nombres de modelo.** «Gemini 3.7 Flash», «GLM 5.2», «Kimi K3»,
«Gemma 4 31B»… Hace dos versiones arreglamos justo eso: los sugeridos salían de
una lista escrita a mano, cuatro no existían y salían en rojo. Copiar esta
lista sería reconstruir el bug con datos que además no puedo verificar —
`openrouter.ai` está bloqueado por la política de red de este entorno.

**Los proveedores nuevos de nube.** La regla del repositorio («hay 17 y
sobran») sigue valiendo: cada uno es mantenimiento, y la mitad del listado son
créditos de prueba que se agotan. Los locales son otra cosa: no caducan, no
tienen cuota y no hay clave que rotar.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ **1160** unitarios (1149 antes) · ✓ **152** E2E
  (150 antes), suite completa en verde **dos veces seguidas**
- ✓ `npm start` + `/api/version` → `3.37.0` · ✓ `VERCEL=1` con el `.nft.json`
- Los dos E2E, comprobados en rojo por separado: sin la etiqueta cae el del
  radar, sin los proveedores cae el de los runtimes.

### Lo que NO pude comprobar

- **No he levantado ninguno de los cinco runtimes.** Los puertos son los que
  cada proyecto trae de fábrica según el listado; si alguno cambió, se edita la
  URL base y ya. Que la app hable con un servidor OpenAI-compatible en
  localhost sí está probado desde hace versiones (Ollama, LM Studio).
- **Los `registro` no están verificados por mí**, con el detalle de arriba.
- **GPT4All y KoboldCpp se quedan fuera**: el listado no da su endpoint
  compatible y no me lo voy a inventar. Si me pasas el puerto, entran en cinco
  minutos.

---

## v3.38.0 — El veredicto de «Probar modelos» sale del diálogo

Reportado con captura: los cuatro modelos de Groq tachados en rojo —«4 no
responden»— y, en palabras del usuario, «aunque el modelo no funciona lo agrega
al apartado en el chat de escoger modelos».

### La causa, en una línea

```ts
const [probados, setProbados] = useState<Record<string, ProbeResult>>({});
```

El resultado de la prueba vivía en un `useState` **dentro del diálogo de
Ajustes**. Al cerrarlo se perdía. El selector del chat nunca se enteraba de
nada, y volvía a ofrecer los mismos modelos que acababan de fallar. Elegías uno
y volvía el error.

### El arreglo

`lib/prism/modelos-rotos.ts`: una memoria persistida de los modelos que el
proveedor **no reconoce**, con dos reglas que importan tanto como la función:

1. **Solo entra la culpa confirmada del modelo** — «no existe» o «tu clave no
   llega a él». Nunca un límite de peticiones, ni una caída del proveedor, ni
   un servidor local apagado. Ya existía `culpaConfirmadaDelModelo` para esa
   decisión y es la que manda: acusar a un modelo bueno es peor que dejar pasar
   uno malo.
2. **Una prueba que sale bien limpia la marca**, y recargar la lista de un
   proveedor borra todas las suyas. Los proveedores retiran y reponen modelos;
   una lista negra que solo crece acabaría escondiendo modelos que ya
   funcionan.

Con eso, un modelo marcado:

- **no se ofrece en el selector del chat** — con una escapatoria: el que tienes
  puesto AHORA se queda aunque esté marcado, o la cabecera señalaría a un
  modelo que no aparece en ninguna lista;
- **no entra en la cadena de Auto**, que lo elegía y fallaba en el primer
  intento gastando un salto para nada;
- **no recibe el failover**: saltar a un modelo que ya sabemos que no responde
  es cambiar un error por otro.

En Ajustes sigue estando, tachado y con lo que contestó, para quitarlo o
volver a probarlo.

### Sobre «ninguno funciona»

Los cuatro de la captura son los `defaultModels` que Prism trae escritos para
Groq. Es la misma enfermedad que se arregló en la v3.36.0 con los sugeridos de
OpenRouter: **listas de ids escritas a mano envejecen solas**. La cura de
verdad ya está puesta —«Cargar modelos» trae el catálogo real y ahora borra las
marcas viejas— y esto evita que los caducados sigan apareciendo como si nada.

**No he tocado los ids de `defaultModels`.** Sin red en este entorno no puedo
saber cuáles siguen vivos, y escribirlos de memoria sería exactamente el fallo
que estamos persiguiendo. Lo que sí hace la app ahora es no ofrecerte lo que ha
comprobado que no responde.

### Pruebas

- Nueve unitarios: el filtrado, la escapatoria del modelo en uso, el texto del
  motivo, y —lo más importante— **qué NO se marca**: 429, servidor local
  apagado, 503 del proveedor, y el 404 de la política de datos de OpenRouter
  (el modelo existe; funciona en cuanto la aceptas).
- **Un E2E del camino entero**: dos modelos (uno bueno, uno que el mock no
  reconoce), se prueban en Ajustes, **se cierra el diálogo** —que es donde se
  perdía— y se comprueba que el selector del chat ya no ofrece el fantasma y sí
  el bueno.
- **Comprobado en rojo**: sin el filtro, el fantasma sigue en el selector.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ **1169** unitarios (1160 antes) · ✓ **153** E2E
  (152 antes), suite completa en verde **dos veces seguidas**
- ✓ `npm start` + `/api/version` → `3.38.0` · ✓ `VERCEL=1` con el `.nft.json`

### Lo que NO pude comprobar

- **No se ha probado contra Groq de verdad**: sin red. El E2E usa el mock, que
  devuelve el mismo `model_not_found` con 404 que devuelven los proveedores.
- **Las marcas se hacen al probar, no solas.** Si nunca pulsas «Probar
  modelos», nada se marca y el selector sigue ofreciéndolo todo. Marcar por un
  fallo del chat es tentador pero peligroso: un 404 puntual no distingue entre
  «no existe» y «se cayó ahora mismo», y esconder un modelo bueno es peor.
  Si lo quieres automático, se hace, pero prefiero decirlo antes.

---

## v3.39.0 — Sube código y ZIP al chat: se leen enteros aquí, y se dice lo que no cupo

Pedido: «debería dejar subir archivos en el chat para poder analizar corregir
reparar, y zip también, que sea capaz de leer todo dentro del zip».

### Lo que pasaba

El compositor aceptaba imágenes, PDF, `.txt`/`.md` y hojas de cálculo. Un
`.js`, un `.py` o un `.zip` **no encajaban en ningún filtro y se ignoraban en
silencio**: soltabas el archivo, no pasaba nada, y nadie te decía por qué. Eso
era casi peor que no aceptarlos.

### Código suelto

`isTextPath` (el mismo que usa el Sandbox) pasa a decidir qué es texto, y se le
añaden los lenguajes que la gente trae para que se los revisen: `py`, `rb`,
`php`, `java`, `kt`, `go`, `rs`, `c`, `cpp`, `cs`, `swift`, `sh`, `sql`, `vue`,
`svelte`, `scss`, `diff`, `patch`… Se puede leer y corregir un `.py` aunque el
Sandbox no sepa ejecutarlo.

Y lo que sigue sin poder leerse **se dice** en vez de tragárselo.

### ZIP

`lib/prism/zip-a-texto.ts`. El ZIP se abre **en el navegador**, con el mismo
lector que usa el Sandbox: nada sale del dispositivo.

«Que lea todo lo de dentro» choca con la realidad del producto: los modelos
gratis de aquí tienen 8k de contexto y un proyecto cualquiera pasa del millón
de caracteres. Mandarlo entero no es generoso — es que la petición falla. Así
que se prioriza, y **lo que no cabe se nombra**:

1. **El índice completo va siempre**: todos los archivos con su tamaño, aunque
   el contenido no quepa. El modelo tiene que conocer la forma del proyecto
   aunque no haya leído cada archivo; si no, opina sobre algo que no ha visto.
2. **El contenido, por prioridad**: README y manifiestos primero, luego
   `index`/`main`, luego lo menos hondo. Techo de 60.000 caracteres en total y
   12.000 por archivo, para que un minificado no se coma el presupuesto.
3. **«Lo que NO viaja en este mensaje»**: los recortados con cuántos
   caracteres faltan, los que no cupieron **por su nombre** (para que puedas
   pedirlos), los binarios, y lo omitido por ser `node_modules`, lockfiles o
   `.min.js`.

Esa tercera sección es la que hace que esto sea honesto. Un resumen que oculta
lo que no cupo es peor que uno corto.

### Pruebas

- Nueve unitarios: qué es ruido y qué no, que el índice sale entero aunque el
  contenido no quepa, que se respeta el techo, que un archivo enorme se recorta
  **diciendo cuánto falta**, el orden de prioridad, y un ZIP solo de imágenes
  que lo admite en vez de fingir que leyó algo.
- **Dos E2E que leen lo que VIAJA**: se construye un ZIP con el escritor de la
  propia app, se suelta en el chat, se manda «repara esto» y se comprueba que
  el contenido de los tres archivos de texto está en la petición, que el índice
  incluye el `.png`, que el `node_modules` **no** viaja, y que el aviso de lo
  omitido sí. El segundo hace lo mismo con un `.js` suelto.
- **Comprobados en rojo**: con el filtro anterior, los dos caen.

### De paso

Renombrar el botón de adjuntar («Adjuntar imágenes o PDF» ya era falso) rompió
`composer.spec.ts`, que lo buscaba por ese nombre. Es la trampa §1.4 de
`INSTRUCCIONES-V6.md`, esta vez al revés: no había colisión, el nombre viejo
había dejado de ser cierto. Test actualizado al nombre nuevo.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ **1178** unitarios (1169 antes) · ✓ **155** E2E
  (153 antes), suite completa en verde **dos veces seguidas**
- ✓ `npm start` + `/api/version` → `3.39.0` · ✓ `VERCEL=1` con el `.nft.json`

### Lo que NO pude comprobar, y dos límites que conviene saber

- **No se ha probado con un ZIP grande de verdad** (un repo entero). El
  reparto y los recortes están probados con unitarios; el comportamiento con un
  ZIP de 50 MB en un móvil no lo he medido. El lector es el mismo que ya usa el
  Sandbox desde hace versiones.
- **Un ZIP grande NO cabe entero, y eso no es un fallo**: es el techo de
  contexto. Lo que la app garantiza es que sabrás qué se quedó fuera y podrás
  pedirlo por su nombre.
- **Máximo 3 documentos por mensaje**, y un ZIP cuenta como uno. Es el cupo que
  ya había para PDF y hojas; no lo he tocado.

## v3.40.0 — El agente mide su propio cambio, y el QA por fin le llegaba

Del catálogo de ocho herramientas que llegó en el mockup, entran **tres**. Las
otras cinco se descartaron o se convirtieron en otra cosa, y el porqué está más
abajo: dos de ellas se apoyaban en cosas que aquí no existen.

### El fallo que apareció verificando el mockup

`sandbox-runner.ts` leía la medida de QA en `e.data.items`. El medidor
(`visual-qa.ts`) manda `{ type, token, result }`: la medida va dentro de
`result`. Así que `Array.isArray(undefined)` era `false`, `qaResults` se quedaba
en `null` y **`run_project` con `qa: true` no le ha contado nunca un solo
hallazgo al agente**. El QA se medía, se mandaba por `postMessage`, y se tiraba
en esa línea.

De paso, una medida que **no respondió** se contaba como «cero hallazgos», que
es un aprobado inventado. Ahora se excluye del recuento, igual que ya hacía el
Sandbox visible.

### `run_regression` — mide el antes y el después

`compareRuns` y `comparables` estaban escritos y probados desde la v3.31, y solo
los usaba `sandbox-studio.tsx`. Ahora el agente puede llamarlos: ejecuta el
proyecto y lo compara con **su ejecución anterior de esta conversación**.

- La **primera vez no hay con qué comparar**, y se dice: se guarda la referencia
  y se le explica que vuelva a llamarla después de editar. No se inventa una
  comparación con la nada.
- `run_project` también deja referencia, así que el flujo natural —ejecuto,
  edito, mido— funciona sin preparar nada.
- Dos ejecuciones de **páginas distintas no se comparan**, y se dice cuál era
  cuál.
- Si el QA no respondió en alguno de los dos lados, se lee **«sin comparación»**,
  no «sin cambios».

### `snapshot_diff` — qué archivos se movieron

Módulo puro nuevo, `diff-proyectos.ts`, encima del `diff.ts` que ya había.
Con un id compara ese punto de restauración con el proyecto **tal como está
ahora** (el caso normal); con dos, los compara entre sí.

Esto **absorbe la `diff_with_main` del mockup**, que no se puede hacer: pedía
`against: "main" | sha | "head~1"` y declaraba un permiso «Git ✓». Aquí no hay
git. `git_snapshot` es un nombre entre comillas: son copias planas en
`localStorage`.

Y de paso, **el catálogo mentía sobre los ids**. Decía «(s1, s2…)» y los ids
reales son `s` + la fecha en base 36 (`smtknd746`). El modelo llamaba con «s1» y
se llevaba un error. Corregido en `git_snapshot` y en la nueva; hay un unitario
que recorre el catálogo entero para que no vuelva a colarse.

### `ask_memory` — preguntar al mapa en vez de arrastrarlo

`buscarEnMapa` busca en archivos, funcionalidades, tecnologías y **notas de
memoria**. Las notas van con ventaja a propósito: son lo que decidió el usuario,
y eso pesa más que algo que Prism dedujo leyendo el HTML.

El argumento del mockup («recuperar decisiones») era el flojo: el mapa **ya
viaja entero en cada prompt** vía `renderMapForPrompt`. El fuerte es poder
dejar de mandarlo siempre y que el modelo lo pida cuando le haga falta.

Distingue dos cosas que no son la misma: **«todavía no hay mapa»** y **«no hay
nada sobre eso»**. Y no hay porcentaje de relevancia: o una palabra de la
pregunta está en el texto, o no está.

### `read_url` gana `selector` y `max_chars` (no una tool nueva)

La `import_url` del mockup **ya existe**: es `read_url`. Meter una gemela habría
hecho que el modelo eligiera mal la mitad de las veces. Lo que sí faltaba eran
sus dos parámetros.

`extraerSeleccion` entiende **solo selectores simples**: `main`, `#precios`,
`.PricingTable`, `section#precios`, `div.card`. Sin combinadores, atributos ni
comas. Es una decisión, no una limitación que se esconde: un motor CSS a medio
hacer que acierta el 80 % es peor que uno que dice qué sabe hacer. Si el
selector no se soporta, o no casa, **se devuelve un error** — nunca la página
entera fingiendo que se hizo caso. Va por texto y no por DOM para dar el mismo
resultado en el navegador y en un test.

`max_chars` sube el tope de 8 000, con techo de 20 000: una sola página no se
come la conversación.

### El peso del HTML era el peso del HTML *más Prism*

Saltó leyendo la salida del E2E: una página de 410 caracteres pesaba 2 196
bytes. `built.html` ya trae el puente de consola, y encima se medía después de
inyectar el medidor de QA y el piloto. O sea, el «peso html» que se enseñaba
incluía ~1,8 KB de instrumentación que el usuario no tiene y no puede bajar.

`buildRunHtml` ahora apunta `htmlBytes` con el proyecto ya empaquetado (CSS, JS
e imágenes dentro) y **antes** de inyectar nada. Lo usan el agente y el Sandbox
visible.

### Lo que NO entra, y por qué

- **`deploy_preview`**: `localhost.run` es un túnel **SSH**. En un navegador no
  hay SSH ni servidor local que tunelar — el Sandbox es un `<iframe>`. Para que
  hubiera URL pública habría que subir los archivos a un host ajeno: servidor y
  casi seguro cuenta, o sea lo contrario de la promesa del producto. La tarjeta
  además enseñaba datos inventados («uso 3 / 50 requests»).
- **`transcribe_media`**: decía reutilizar `speech.ts`, que es `startDictation`
  sobre la Web Speech API — escucha el **micrófono en vivo**.
  `SpeechRecognition` no acepta un archivo de audio en ningún navegador. El
  fallback propuesto, Whisper local, son 40-75 MB de modelo en WASM.
- **`propose_plan`**: buena idea, pero una tool es algo que el modelo
  *ejecuta* y un plan es algo que *escribe*. Sale con prompt + parser + UI, y el
  bloqueo «espera tu OK» lo da la interfaz, no la herramienta. Pendiente.
- **`diff_with_main`**: fusionada en `snapshot_diff` (ver arriba).

### Lo que el mockup daba por hecho y no existe

El pie decía: «Las tools nuevas heredan `skill-permissions.ts`… el usuario las
ve listadas y puede apagarlas por chat». **Eso no existe.**
`analyzeSkillPermissions` analiza con expresiones regulares el texto en prosa de
una skill **antes de instalarla**. No hay declaración de permisos por
herramienta, ni comprobación en ejecución, ni interruptor. Las tarjetas
«Red ✓ por URL / Claves — no envía» eran etiquetas dibujadas.

No se ha implementado nada de eso aquí, y **no se enseña por ninguna parte**.
Lo que sí es real y sigue puesto es `net-guard.ts` en `/api/proxy`, que bloquea
localhost, IPs privadas y los metadatos de la nube, revalidando cada redirección.

### Pruebas

- Unitarios nuevos: `diff-proyectos` (9), `memoria-mapa` (11), `selector-html`
  (14), `tools-v8` (21, las tres herramientas por el runner real), más 7 casos
  de selector en `tool-runner-read-url` y 2 de peso en `sandbox`.
- E2E `tools-medir.spec.ts` con un modelo simulado nuevo, `mock-mide`, que
  recorre la sesión entera: escribe una página rota, guarda un punto, la mide,
  la arregla, la vuelve a medir, compara archivos y consulta el mapa.
- **Comprobados en rojo**: con el fallo del payload restaurado a mano, el E2E lee
  «QA móvil: sin comparación» donde ahora lee «sin cambios». Con las tres
  herramientas desactivadas del catálogo, lee «Herramienta desconocida».

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ **1245** unitarios (1178 antes) · ✓ **156** E2E
  (155 antes), suite completa en verde **dos veces seguidas**
- ✓ `npm start` + `/api/version` → `3.40.0` · ✓ `VERCEL=1` sin `standalone` y
  con el `.nft.json` donde Vercel lo busca

### Lo que NO pude comprobar

- **El `selector` de `read_url` no tiene E2E**, y es a propósito: en este entorno
  no hay red hacia fuera y `net-guard` rechaza —correctamente— una página local,
  así que no hay ninguna página que la herramienta pueda leer de verdad. Es la
  misma razón por la que `read_url` tampoco lo tenía. Está probado con 14
  unitarios del extractor (`selector-html`) y 7 que pasan por `runTool` de
  verdad con el `fetch` simulado.
- **`run_regression` no se ha probado contra un proyecto grande**. Las dos
  ejecuciones del E2E son de una página de 400 caracteres. Con un proyecto de
  cientos de KB, cada medida son dos cargas completas del iframe: no he medido
  cuánto tarda ni si el techo de 2,5 s de recogida de logs se queda corto.
- **`ask_memory` busca por palabras, no por significado.** «¿qué colores
  usamos?» no encuentra una nota que diga «la paleta es cálida» si no comparten
  ninguna palabra. Es una búsqueda literal y honesta, no un buscador semántico.

## v3.41.0 — Permisos por herramienta que se hacen cumplir

El catálogo llevaba versiones diciendo, en su propia cabecera, «si añades una
herramienta aquí, dale permiso en `tool-permissions.ts`». **Ese archivo no
existía.** Lo que sí existía era `skill-permissions.ts`, que es otra cosa:
analiza el texto en prosa de una skill antes de instalarla.

Tres piezas, y sin las tres esto sería una pantalla decorativa:

### 1. Declaración — `tool-permissions.ts`

Cuatro efectos: **leer el proyecto**, **escribir en el proyecto**, **ejecutar
código**, **salir a internet**. Cada una de las 15 herramientas declara los
suyos. Dos tests lo cierran en los dos sentidos: una herramienta sin declarar
sería una herramienta que nadie puede apagar, y una entrada de más sería una
promesa sobre algo que no existe.

Decisiones que conviene dejar escritas:

- **`git_snapshot` cuenta como escritura**, aunque «create» y «list» solo lean:
  «restore» descarta archivos. Manda el efecto más fuerte que la herramienta
  puede llegar a tener.
- **Una herramienta sin declarar NO se ejecuta.** Es lo contrario de lo cómodo
  y es lo correcto: si alguien añade una y olvida declararla, lo que no puede
  pasar es que corra sin permiso porque nadie sabía cuál pedirle.
- **Todo concedido por defecto.** El agente sin permisos no sirve, y un
  producto que arranca roto «por seguridad» acaba con el usuario encendiéndolo
  todo sin leer. Lo que importa es que se vean, se apaguen y que apagarlos
  surta efecto.
- **Un efecto que falta en los ajustes guardados se concede**, no se deniega.
  Al revés, una actualización dejaría al agente mudo sin que el usuario haya
  tocado nada.

### 2. Comprobación — en dos capas

- **`tool-runner.ts`** rechaza antes del `switch` y antes de tocar nada. Esta
  es la que manda: que el catálogo venga filtrado no basta, porque el modelo
  puede pedir una herramienta que no se le ofreció (se la inventa, o la
  arrastra de un turno anterior).
- **`use-agent-tools.ts`** recorta el catálogo que se le describe al modelo.
  No es seguridad, es no gastar contexto en herramientas que se van a
  rechazar y no provocar reintentos.

El mensaje de rechazo está escrito para el modelo: le dice qué permiso falta y
**que no insista**. Sin eso se queda reintentando hasta agotar las vueltas.

De paso: **el probe también mandaba el catálogo entero**. Solo comprueba si el
modelo entiende `tools`, así que describirle al proveedor herramientas que el
usuario apagó era mandar fuera una capacidad que decidió no usar, y pagar sus
tokens. Ahora lleva el catálogo filtrado.

### 3. Interruptor — Ajustes → Chat

Aparece con el modo agente encendido. Cada efecto con su explicación de lo que
pasa de verdad, y **qué herramientas cubre, por su nombre**. La lista sale de
la tabla, no escrita a mano: si se añade una herramienta, aparece sola; escrita
a mano, el panel mentiría en cuanto el catálogo creciera.

Con algo apagado, un aviso dice exactamente cuántas herramientas y cuáles
pierde el agente — calculado del catálogo real.

### Pruebas

- 19 unitarios de la tabla y las reglas; 6 en `tools-v8` que comprueban el
  cumplimiento **por sus efectos, no por el mensaje**: con «red» apagada el
  `fetch` no ocurre, con «escribir» apagado el archivo no cambia, con
  «ejecutar» apagado `runProject` no se llama. 3 del filtrado del catálogo.
- E2E `permisos-agente.spec.ts`: abre Ajustes, apaga «Salir a internet»,
  comprueba el aviso, que `read_url` desaparece de **todas** las peticiones que
  llevan catálogo (probe incluido) y que la llamada acaba rechazada.
- **Comprobados en rojo**: desactivando la comprobación del runner a mano,
  caen 4 unitarios —entre ellos el que verifica que **no se sale a internet**—
  y el E2E.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ **1273** unitarios (1245 antes) · ✓ **159** E2E
  (156 antes), suite completa en verde **dos veces seguidas**
- ✓ `npm start` + `/api/version` → `3.41.0` · ✓ `VERCEL=1` sin `standalone` y
  con el `.nft.json`

### Lo que esto NO es

- **No es un sandbox de seguridad.** Es control del usuario sobre su propio
  agente, no defensa contra código hostil. Lo que protege el perímetro sigue
  siendo `net-guard.ts` en `/api/proxy` y el `sandbox` del iframe.
- **No hay permisos por herramienta suelta**, solo por efecto. Apagar «red»
  apaga las tres de internet a la vez. Cuatro interruptores que se entienden
  valen más que quince que nadie lee.
- **No hay confirmación por llamada.** El agente no pide permiso cada vez: o
  puede o no puede. Un diálogo por herramienta en un bucle de ocho vueltas se
  convierte en un botón que se pulsa sin leer.
- **No cubre lo que no pasa por el runner.** El camino XML del agente (los
  modelos que no soportan `tools`) escribe archivos por otra vía y estos
  permisos no lo tocan. Es el siguiente hueco real.

## v3.41.1 — Tres fallos que vio el usuario en un solo mensaje

Los tres se reportaron juntos: «puse hola al agente y me mandó un código de una
página que yo le había mandado anteriormente», «el sandbox le subí un zip con
css, js y el HTML y solo carga el html con texto no carga los diseños» y
«Escudo PII: 2 datos enmascarados, correo… y ese error también me dió solo puse
hola». Son tres causas distintas.

### 1. El ZIP con carpeta y rutas absolutas se abría pelado

**El más grave.** Un ZIP con esta forma —que es la normal— no cargaba ni
estilos ni scripts:

```
mi-web/index.html   →  <link href="/css/estilos.css">
mi-web/css/estilos.css
mi-web/js/app.js
```

El HTML se escribió pensando en la raíz de un dominio (`/css/…`), y el ZIP trae
el sitio dentro de su carpeta. `resolvePath` resolvía `/css/estilos.css` a
`css/estilos.css`, que no existe. La página se abría con el texto y sin nada
más.

Probé once formas de organizar un ZIP antes de tocar nada; **diez funcionaban y
esta fallaba**, y es justo la que sale de comprimir una carpeta.

Arreglo: `raizComun()` deduce la carpeta del proyecto (ignorando `__MACOSX/` y
los `._algo` que mete macOS, que si no ningún ZIP hecho en un Mac tendría raíz)
y `hacerResolver()` prueba primero la ruta literal y, solo si ahí no hay nada,
dentro de esa carpeta. Se usa en los cinco sitios que resolvían por su cuenta:
imágenes, `<link>`, `<script>`, `@import` y `url()` del CSS.

**Dos rutas y en ese orden, nada más.** Buscar por nombre de archivo por todo
el proyecto acertaría más veces y se equivocaría en silencio cuando hay dos
`estilos.css`. Hay un test de eso: con dos, gana el que dice la ruta. Y lo que
de verdad falta se sigue reportando como ausente.

### 2. «Hola» devolvía la página del turno anterior

En la v3.36.3 se quitó la plantilla del agente en los turnos triviales. **No
bastaba.** El mapa del proyecto seguía viajando en todos los turnos, y termina
con:

> «Al pedir cambios: entrega SOLO el/los archivos que modifiques (completos) y
> conserva el resto tal cual.»

Eso es una orden de escribir archivos. Con un «Hola» delante, el modelo la
obedecía. La ficha del proyecto igual.

Ahora, en un turno trivial, tampoco viajan la ficha ni el mapa. El E2E lo
comprueba por las dos caras: con «Hola» no viaja «MAPA DEL PROYECTO ACTUAL» ni
«entrega SOLO»; con «cambia el color del hero a violeta», sí.

### 3. El escudo PII rompía el código que subías

`guard()` ya protegía los bloques de código con vallas. Pero el texto de los
**adjuntos** se pegaba al mensaje SIN vallas, así que el escudo enmascaraba los
correos dentro del HTML que subías: el modelo veía `co***@ejemplo.com` en el
código y te devolvía el archivo con el correo roto. **El escudo estropeaba tu
trabajo creyendo que te protegía.**

Y enmascaraba también las respuestas del modelo, que no protege nada —ya salió
y volvió— y le rompe su propio código en la vuelta siguiente.

Ahora hay `escudoHistorial()`, puro y probado, que se aplica **antes** de pegar
los adjuntos y solo a lo que el usuario escribió. Ese orden es el arreglo.

Además, el aviso decía «en lo que se envió al modelo. Tu mensaje visible no
cambia» aunque el correo viniera de diez mensajes atrás. Con un «hola» eso no
hay quien lo entienda. Ahora distingue:

- «correo **en tu mensaje**. Tu burbuja no cambia; solo lo que se envía.»
- «correo **en mensajes anteriores de esta conversación**, que viajan como
  contexto. Tu mensaje de ahora no tenía ninguno.»

### Pruebas

- 6 unitarios del resolutor del Sandbox (incluidos los dos casos límite: la
  ruta literal manda, y lo ausente se sigue reportando), 9 del escudo.
- 2 E2E nuevos en `saludo-sin-agente.spec.ts`, con una sesión que ya tiene mapa.
- **Comprobados en rojo, uno a uno**: sin el respaldo del resolutor caen 2
  unitarios del Sandbox; enmascarando también las respuestas del modelo cae 1
  del escudo; dejando pasar el mapa en turnos triviales cae el E2E.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ **1288** unitarios (1273 antes) · ✓ **161** E2E
  (159 antes), suite completa en verde **dos veces seguidas**
- ✓ `npm start` + `/api/version` → `3.41.1` · ✓ `VERCEL=1` sin `standalone` y
  con el `.nft.json`

### Lo que NO se ha arreglado

- **No he probado con el ZIP concreto del usuario**, solo con once formas
  típicas reconstruidas a mano. Si el suyo tiene otra estructura, el fallo
  puede seguir ahí y hace falta el ZIP para saberlo.
- **El aviso de archivos que faltan sigue siendo un toast** que se va en unos
  segundos. Con este arreglo saltará mucho menos, pero cuando salte se puede
  perder igual: debería vivir en la pestaña Revisión, y no lo he movido.
- **`esTurnoTrivial` sigue siendo de ocho palabras y una lista de cortesías.**
  «Hola» y «gracias» los caza; «y bueno, qué tal va todo por ahí» no. No es un
  clasificador, es un filtro conservador a propósito.

## v3.42.0 — Si el HTML pide un archivo que no está, se dice y se arregla

El usuario mandó el ZIP. Con el archivo delante, la causa es esta:

```
web ambueguesa/index.html   →  <link href="styles.css">  <script src="script.js">
web ambueguesa/css.css
web ambueguesa/javascript.js
```

**Los nombres no coinciden.** Ese `index.html` se ve igual de pelado abierto en
Chrome. El resolutor de la v3.41.1 hace su trabajo bien —resuelve a
`web ambueguesa/styles.css`—; lo que pasa es que ahí no hay nada.

Y aun así hubo fallo de Prism: **habérselo callado**. `buildRunHtml` ya
apuntaba los ausentes, pero se enseñaban en un aviso que se va a los tres
segundos y que ni siquiera decía lo evidente: que en el proyecto SÍ hay un
`.css`, con otro nombre. El usuario se quedó mirando una página sin estilos sin
manera de saber por qué. Es exactamente lo que quedó apuntado como pendiente en
la v3.41.1: «debería vivir en la pestaña Revisión, y no lo he movido».

### El diagnóstico (`faltantes.ts`)

Para cada archivo que falta se busca, en este orden:

1. **El mismo nombre en otra carpeta** → es la ruta, no el nombre.
2. **El único archivo de esa extensión** → es el nombre. Este es el caso del
   ZIP: pides `styles.css` y el único `.css` se llama `css.css`.
3. **Varios de ese tipo** → se enseña la lista y elige el usuario. Adivinar
   entre tres es acertar una de cada tres veces y haberlo estropeado las otras
   dos.
4. **Ninguno** → se dice y ya.

**Nada se resuelve solo.** Hacer que `styles.css` cargue `css.css` por nuestra
cuenta haría que la vista previa mintiera sobre lo que pasa en un servidor de
verdad.

### La banda, que no se va

Pegada a la vista previa, no un aviso pasajero. Dice qué falta, qué hay en su
lugar, y una frase que hacía falta: **«En un navegador normal pasaría lo
mismo»** — para no cargarle a Prism un fallo que no es suyo.

### El arreglo de un clic

Cuando hay UN candidato claro, un botón «Apuntar a css.css». Cambia la
referencia **en el HTML**; no renombra tu archivo. Dos razones: tu archivo se
llama como tú quisiste, y una edición sobre un archivo existente sale en la
pestaña «Cambios» y se puede deshacer.

Solo se sustituyen las referencias que resuelven EXACTAMENTE al archivo
ausente: una cadena parecida dentro de un `<script>` no se toca, y hay un test
de eso.

### De paso: «Recargar» recargaba el HTML viejo

`onClick={() => setRunKey((k) => k + 1)}` remontaba el iframe con el MISMO
`srcDoc`. Después de editar un archivo, «Recargar» no enseñaba el cambio y no
había forma de saber por qué. Ahora llama a `run()` y reconstruye con los
archivos de ahora, que es lo que dice su nombre. Sin esto, el arreglo de un
clic no se habría visto nunca.

### Pruebas

- 19 unitarios de `faltantes.ts` (los cuatro casos del diagnóstico, los límites
  del arreglo, y que una cadena dentro de un script no se toca).
- **El ZIP del usuario es la fixture del E2E**, tal cual lo subió
  (`tests/fixtures/web-hamburgueseria.zip`). Tres pruebas: que se dice qué
  falta y qué hay en su lugar; que la banda **sigue ahí pasados 12 segundos**
  (el fallo de verdad era que la información se perdía); y que con dos clics y
  «Recargar» la página carga — comprobando `getComputedStyle(body).fontFamily`
  dentro del marco, que es Poppins porque lo fija el `css.css` del proyecto.
- **Comprobado en rojo**: sin la banda, los tres E2E caen.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ **1307** unitarios (1288 antes) · ✓ **164** E2E
  (161 antes), suite completa en verde **dos veces seguidas**
- ✓ `npm start` + `/api/version` → `3.42.0` · ✓ `VERCEL=1` sin `standalone` y
  con el `.nft.json`

### Lo que sigue sin estar bien

- **Las imágenes de ese ZIP apuntan a `https://via.placeholder.com`.** Son
  externas, así que si ese servicio no responde salen rotas y Prism no puede
  hacer nada. La banda NO dice nada de eso: solo habla de archivos del
  proyecto. Decir «ese servicio está caído» sería afirmar algo del mundo que
  desde aquí no se puede comprobar.
- **El arreglo no toca las referencias dentro del CSS** (`url(...)`,
  `@import`). Si lo que falta lo pide una hoja de estilos y no el HTML, el
  diagnóstico sale igual pero el botón no arregla nada — habría que editarlo a
  mano.
- **Un candidato de otro tipo no se propone.** Si pides `estilos.css` y solo
  tienes `estilo.scss`, no se sugiere: la extensión tiene que coincidir.

## v3.43.0 — El perímetro cerrado y una red que caza lo que los ejemplos no ven

Cuatro análisis externos sobre la mesa. Lo primero fue contrastarlos con el
código, y lo primero que salió es que **traían datos que ya no son ciertos**:
decían 1 076 / 890 / 1 178 unitarios (hay 1 331), 119-131 E2E (hay 167), 12
herramientas (son 15), que knip no corre en CI (corre, `ci.yml` línea 41), que
falta un trace panel (existe, `agent-trace.tsx`) y que falta un sistema de
permisos por herramienta (existe desde la v3.41.0).

Lo que sí acertaban, y era verificable, entra. El destilado con lo descartado y
por qué está en `docs/PLAN-V8.md`.

### 1. El proxy no tenía límite de abuso

Cero coincidencias de `429` en la ruta. `net-guard.ts` impide que te usen para
llegar a la red interna; **no impide que te usen de relé**. Y el timeout de 90 s
no vale para eso: corta la petición que no contesta, no la ráfaga de las que sí.
La demo está pública en Vercel, así que esto es riesgo real, no teórico.

`proxy-budget.ts`, puro y con el reloj inyectado: 120 peticiones por minuto y
por identidad, cuerpo máximo de 8 MB. La comprobación va **antes** de validar el
destino y antes de leer el cuerpo — quien se pasó no debe costar ni una
resolución DNS.

Tres decisiones escritas en el código:

- **120/minuto**, no 30: una conversación activa manda 10-20 contando el probe,
  el streaming y las vueltas del agente. Un límite que corta el uso normal se
  acaba quitando, y entonces no protege nada.
- **El mensaje del 429 dice «límite del despliegue»**. Sin eso el usuario culpa
  a su proveedor de IA y se pone a cambiar de modelo por un problema que no es
  suyo.
- **Se barre el mapa cada 200 peticiones.** Un contador que nunca limpia es una
  fuga de memoria disfrazada.

Y se dice lo que NO es: sin cuentas no hay identidad, y una IP se cambia. Es el
guardarraíl que impide que un despliegue público acabe de relé abierto por
accidente. Para más que eso ya está `PRISM_ACCESS_CODE`.

### 2. Tests de propiedad: la red que faltaba

Los tres fallos que aparecieron esta semana —el QA que nunca llegaba al agente,
el ZIP con carpeta que no resolvía, el escudo PII que rompía los adjuntos—
**pasaron por delante de tests de ejemplo en verde**. Ninguno preguntaba la
regla; todos preguntaban un caso.

24 propiedades con `fast-check` en `tests/unit/propiedades/`. Las que importan:

- «Lo que se ofrece al modelo nunca incluye un efecto apagado.»
- «Un CSS referenciado como quiera siempre se inlinea si existe» — carpeta o no,
  `./` o `/` o relativo.
- «El escudo nunca toca lo que no escribió el usuario.»
- «Nunca pasan más de `max` peticiones por ventana, sea cual sea el reparto.»
- «Un candidato propuesto siempre existe en el proyecto.»

**Comprobado revirtiendo los fallos de verdad**: con el resolutor del ZIP
desactivado cae la propiedad del CSS; con el escudo tocando todos los roles cae
la del PII; sin el presupuesto cae la del proxy.

#### Dos cosas que salieron de hacerlo bien

**La propiedad del PII pasaba en verde con el fallo puesto.** `fc.string()`
genera ruido que casi nunca contiene un correo válido, así que la propiedad se
cumplía sin ver nunca el caso que le importaba. Se cambió por un generador que
mete PII de verdad, y ahora hay un test guardián que comprueba que **el
generador genera lo que dice generar** — si deja de hacerlo, las propiedades de
ese bloque se volverían verdes por vacío.

**Y encontró un fallo: `«0 4111 1111 1111 1111»` no detectaba la tarjeta.** El
patrón coge 16 cifras desde el límite de palabra; con un dígito suelto pegado
delante quedan 17 y Luhn dice que no, con razón. Se intentó arreglar probando
subsecuencias finales y **el remedio salió peor**: empezaba a enmascarar
`«el pedido 1234 5678 9012 3456 7»` y se comía un espacio. Se revirtió. El
límite es estrecho (hace falta un dígito Y un espacio; con `«ref9 »` o `«1: »`
funciona), y queda **documentado en un test**, no escondido. Antes de estropear
texto del usuario, se prefiere el límite conocido.

### 3. CodeQL

`security-extended` sobre el TypeScript, en su propio workflow y sin bloquear la
entrega: un aviso de CodeQL es una pista para mirar, no un veredicto. Lo que
bloquea sigue en `ci.yml`.

### 4. La raíz, limpia

Los cuatro `PLAN-V*.md`, `PLAN-EVOLUCION.md`, las dos `INSTRUCCIONES-*.md` y
`MANIFIESTO.txt` se van a `docs/`. En la raíz quedan `README.md` y
`worklog.md`. Solo había referencias en comentarios; ningún import.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ **1 331** unitarios (1 307 antes) · ✓ **167**
  E2E (164 antes), suite completa en verde **dos veces seguidas**
- ✓ `npm start` + `/api/version` → `3.43.0`
- ✓ **El 429 comprobado contra el servidor de producción**: 125 peticiones
  seguidas → 120 pasan, 5 cortadas. El techo declarado, medido.
- ✓ `VERCEL=1` sin `standalone` y con el `.nft.json`

### Lo que NO entra de esos análisis, y por qué

- **Multi-Agent Orchestrator, Task DNA, Prism Lab, Prism OS.** Es otra
  aplicación. Y el argumento en contra lo da el propio análisis que lo propone:
  los modelos gratis fallan en cadenas largas. Un orquestador de cinco agentes
  empeora el problema **para los modelos por los que esta app existe**.
- **Sincronización con backend.** Se la llama «la única limitación que no se
  resuelve con otra iteración». Pero «sin cuentas, sin servidor» no es una
  limitación: es el producto. Y `transfer.ts` ya pasa las claves cifradas entre
  dispositivos sin servidor.
- **Búsqueda semántica con embeddings locales.** Decenas de MB de modelo.
  `ask_memory` busca por palabras y lo dice.

### Lo que sigue pendiente

- **`chat-app.tsx` son 2 920 líneas y sigue creciendo** (2 906 cuando se
  escribió el análisis). Es lo siguiente, y no se ha tocado hoy.
- **La memoria negativa** («no toques `Header.tsx`») es la mejor idea de los
  cuatro documentos y encaja con lo que ya hay. Sin empezar.
- **El límite por IP es por instancia** en serverless: cada una lleva su
  contador, así que el techo real se multiplica por el número de instancias.
  Corta el uso como tubería, que es para lo que está, pero no es un límite
  global y no se ha medido cuántas instancias levanta Vercel bajo carga.

## v3.44.0 — Memoria negativa, y el primer corte de `chat-app.tsx`

Las dos cosas que quedaron dichas y sin hacer en la v3.43.0.

### 1. «No tocar»: una regla que se hace cumplir, no una nota

Es la mejor idea de los cuatro análisis (`PLAN-EVOLUCION.md` §3) y la más
barata de las suyas, porque encaja con lo que ya existe.

El mapa del proyecto guardaba notas y el modelo las leía. Pero **una nota es
una sugerencia**: el agente la entiende y aun así reescribe el archivo que le
pediste que no tocara. Cuando pasa, has perdido trabajo.

Una regla de aquí es otra cosa. Mismo patrón de dos capas que
`tool-permissions.ts`, que es el que funciona:

1. **Las reglas viajan en el prompt** para que el modelo ni lo intente.
2. **`tool-runner.ts` rechaza la escritura** antes de tocar el archivo, aunque
   lo intente igual.

Sin la 2 sería otra nota. Sin la 1, el agente chocaría contra un muro invisible
y gastaría vueltas averiguando por qué.

Los patrones son un glob pequeño a propósito: un nombre suelto (`Header.tsx`)
protege ese archivo **esté en la carpeta que esté** —que es lo que la gente
quiere decir—, un asterisco no cruza carpetas, el doble sí. Sin distinguir
mayúsculas: una regla que falla según el sistema operativo del usuario no es una
regla.

Tres decisiones escritas en el código:

- **Restaurar un snapshot que cambiaría un archivo protegido se cancela
  ENTERO.** Restaurar descarta lo hecho después, así que puede llevarse por
  delante un archivo protegido sin nombrarlo nunca. Y si se cancela, no puede
  dejar el proyecto a medias. Pero solo si lo cambiaría de verdad: bloquear un
  restore que deja el archivo igual sería bloquear por bloquear.
- **El mensaje del bloqueo dice «no lo intentes por otra vía».** Sin eso, el
  agente prueba con `edit_file` lo que no pudo con `write_file` y se gasta las
  vueltas en eso.
- **Al escribir el patrón se enseña a qué afectaría AHORA.** Una regla que no
  casa con nada da una falsa sensación de protección, que es peor que no
  tenerla, y verlo antes de guardar cuesta menos que descubrirlo cuando el
  agente ya reescribió el archivo.

Y lo que NO es: no es control de acceso. El usuario puede editar el archivo a
mano en el Sandbox cuando quiera, y debe poder. Es una barandilla contra el
agente, que es quien se lleva por delante lo que no miraba.

### 2. Primer corte de `chat-app.tsx`

2 945 → 2 930 líneas. Poco en número y mucho en lo que importa: **la tubería de
adjuntos ya no vive dentro del componente**.

`reparto-adjuntos.ts` decide qué es cada archivo y cuántos caben, sin tocar
disco ni pantalla. Esa lógica estaba mezclada con el I/O y con los avisos, y
por eso **no tenía un solo test**: los fallos de esta semana —un `.py` que se
caía en silencio, un ZIP que no se aceptaba— pasaron sin que nada se pusiera
rojo. Ahora tiene 15.

Y al sacarlo apareció un fallo del reparto: se descontaba `zips.length`, o sea
**los candidatos**, no los que de verdad entraban. Mandar cinco ZIP dejaba a las
hojas sin sitio aunque hubiera hueco. Ahora se descuenta lo asignado, y hay un
test que lo dice con esas palabras.

### Pruebas

- 21 unitarios de `reglas-no.ts` (los patrones, los límites, y que un patrón
  vacío no se convierta en «todo»), 8 del cumplimiento en el runner, 15 del
  reparto de adjuntos.
- E2E `memoria-negativa.spec.ts` con un modelo simulado nuevo,
  `mock-toca-header`, que intenta escribir el archivo protegido pase lo que
  pase: se comprueba que el intento acaba rechazado, que **sin la regla el
  mismo agente escribe sin problema** (si bloqueara siempre no probaría nada),
  que la regla viaja en el prompt, y que se puede crear desde el mapa.
- **Comprobado en rojo**: quitando el bloqueo del runner caen 3 unitarios y el
  E2E del bloqueo.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ **1 374** unitarios (1 331 antes) · ✓ **171**
  E2E (167 antes), suite completa en verde **dos veces seguidas**
- ✓ `npm start` + `/api/version` → `3.44.0` · ✓ `VERCEL=1` sin `standalone` y
  con el `.nft.json`

### Lo que sigue pendiente

- **`chat-app.tsx` sigue en 2 930 líneas.** El corte de hoy es el primero y el
  más fácil. El grande es `runGeneration`: **674 líneas** de la 1010 a la 1684,
  y está acoplado a decenas de closures. No se toca de una sentada ni sin más
  tests alrededor.
- **Las reglas no cubren el camino XML del agente.** Los modelos que no
  soportan `tools` escriben archivos por otra vía y el bloqueo no pasa por ahí.
  Es el mismo hueco que ya tenían los permisos y sigue abierto.
- **El reparto de cupos sigue contando candidatos y no aceptados en un caso**:
  si un ZIP entra en el cupo pero falla al abrirse, ese sitio se ha gastado
  igual. Es defendible (el cupo es de intentos) pero no está dicho en pantalla.

## v3.45.0 — Auto Context: se ve qué contexto viajó con tu mensaje

De `PLAN-EVOLUCION.md` §12, la prioridad nº 1 de ese documento. Y una
rectificación: ese plan se resumió en la v3.43.0 por sus cuatro propuestas más
caras (orquestador multiagente, Task DNA, Prism Lab, Prism OS) y se dejaron
fuera veinte secciones sin mirarlas una a una. Fue injusto con el documento. La
memoria negativa de la v3.44.0 ya venía de él (§3); esto es la §12, y quedan
por lo menos dos más que valen y son realizables: **Evidence Mode** (§10) y la
**memoria episódica** (§2).

### El problema

Cada turno se manda mucho más que lo que escribes: el mapa del proyecto, tus
notas, las reglas «no tocar», las skills activas, las reglas aprendidas de
fallos anteriores, los adjuntos y N mensajes de historial.

**Nada de eso se veía.** Escribías una línea, recibías una respuesta rara, y no
tenías forma de saber que el modelo estaba leyendo doce archivos y tres
decisiones viejas. Es exactamente el fallo que se arregló en la v3.41.1 —«hola»
devolvía la página del turno anterior porque el mapa viajaba y nadie lo sabía—
y la causa se tardó tres versiones en encontrar precisamente porque el contexto
era invisible.

### Lo que se hace

Bajo cada respuesta, un chip: **`ctx 2 archivos · 2 notas · 1 regla · 8
mensajes`**. Al pulsarlo, el desglose con los **nombres**: qué archivos, qué
skills, cuántas notas.

Dos decisiones que definen la pieza:

- **Se cuenta lo que ENTRÓ en el prompt, no lo que hay guardado.** El mapa
  puede tener cuarenta archivos y viajar doce; decir «40» sería mentir con la
  verdad. Por eso el resumen se calcula en `prompt-actual.ts`, en el mismo
  sitio donde se construyen las piezas y con los mismos topes —que se han
  exportado para eso—, y no por su cuenta. Es la lección que ya estaba escrita
  en `presupuesto.ts`: un contador que se lo imagina se desincroniza a la
  primera pieza nueva.
- **Si no hay nada del proyecto, no sale.** Los caracteres del prompt base y
  los mensajes del historial viajan SIEMPRE: si contaran, el chip aparecería en
  el 100 % de las respuestas y la gente lo ignoraría en dos días — y entonces
  tampoco lo miraría cuando sí hay algo que mirar. Hay un test que lo dice con
  esas palabras.

Y se guarda en el mensaje, como ya se guardaban `ctxSaved` y `piiMasked`: se
puede volver a mirar una respuesta de ayer y ver con qué se generó.

### Lo que NO es (todavía)

La §12 pide más: **elegir** el contexto relevante según lo que pides (intent →
archivos relevantes → memoria relevante). Eso es lo caro y es donde se inventa.
Aquí se ha hecho la mitad honesta —**enseñar lo que se usa**— porque hacerla
primero es lo que permite juzgar la otra: sin ver qué viaja hoy, no hay forma
de saber si una selección automática mejora algo o solo lo enreda.

### Pruebas

- 11 unitarios, la mayoría sobre cuándo NO enseñar el chip.
- E2E `contexto-usado.spec.ts`: con proyecto sale y nombra los archivos al
  desplegarlo; **sin nada del proyecto no sale**.
- **Comprobado en rojo**: quitando el chip cae el E2E.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ **1 385** unitarios (1 374 antes) · ✓ **173**
  E2E (171 antes), suite completa en verde **dos veces seguidas**
- ✓ `npm start` + `/api/version` → `3.45.0` · ✓ `VERCEL=1` sin `standalone` y
  con el `.nft.json`

### Lo que sigue

- **Evidence Mode** (§10) es el siguiente, y es el que mejor encaja con este
  proyecto: «esto lo digo por `src/lib/provider.ts` línea 84» y, cuando no hay
  fuente, decirlo en vez de afirmarlo. Es literalmente el ADN de la app.
- **Memoria episódica** (§2): las notas de hoy son texto suelto; decisiones,
  errores y preferencias con fecha y origen se pueden consultar de verdad.
- El chip cuenta los adjuntos del envío, no de la conversación entera. Si
  adjuntaste un PDF hace diez turnos y sigue viajando en el historial, el chip
  de hoy no lo cuenta. No está mal, pero tampoco está dicho.

## v3.46.0 — Un director reparte, varios ejecutan, el director cierra

`PLAN-EVOLUCION.md` §5, el orquestador multiagente. **Se había descartado con
un argumento incompleto**, y el usuario lo señaló: se dijo que los modelos
gratis fallan en cadenas largas, y eso solo es cierto si TODA la cadena es
gratis. Con el director de pago y los ejecutores gratis, el que razona y
verifica es el bueno y los baratos hacen trabajo acotado. Es más barato que
usar el caro para todo y mejor que usar solo gratis.

### Cómo funciona

`/orquesta`, escribes el encargo, y:

1. **El director** —tu modelo actual, el que hayas elegido— parte el encargo en
   trozos independientes.
2. **Los ejecutores** —gratis, de otros proveedores— hacen cada uno el suyo, en
   paralelo.
3. **El director** revisa lo que volvió, corrige lo que esté mal y entrega.

### Las tres cosas que lo hacen usable con dinero de por medio

Un orquestador sin estas tres no debería existir, y por eso van dentro y no
después:

- **Techo duro: `2 + n` llamadas y se acabó.** El reparto, los ejecutores y el
  veredicto. No hay bucle, no hay reintentos en cascada, no hay «una ronda
  más». Pedir 99 ejecutores sigue costando 6 llamadas: hay un test que lo
  comprueba, porque es lo que permite prometer un número.
- **El número se dice ANTES de arrancar.** «5 llamadas en total: 2 al director
  y 3 a los ejecutores. No hay más rondas.» Saberlo después no sirve de nada.
- **Compartimentación.** Cada ejecutor recibe SU trozo y nada más: ni la
  conversación, ni el encargo original completo, ni los trozos de los demás. Es
  a la vez más barato y menos superficie — tu historial no acaba repartido
  entre cuatro proveedores porque sí. El E2E lo comprueba mirando lo que viaja
  en cada petición.

### Lo que NO se hace: inventar el precio

No hay ningún «≈ 0,02 $» en pantalla. Los precios varían por proveedor, por
modelo y con el tiempo, y no se pueden saber desde el dispositivo. Se cuentan
**llamadas y caracteres**, que son datos duros, y se separa lo del director de
lo de los ejecutores porque es la distinción que importa cuando uno se paga y
los otros no. Hay un test que comprueba que el aviso no menciona dinero.

### Y lo que se protege sin decirlo

- **Un encargo mínimo no se reparte.** «Gracias» costaría dos llamadas del
  modelo que pagas para no ganar nada. Umbral conservador: 40 caracteres y 8
  palabras.
- **Un reparto ilegible no para el trabajo.** Si el director devuelve algo que
  no se puede leer, se responde de la forma normal en vez de quedarse sin
  respuesta habiendo gastado la llamada. Lo peor de los dos mundos sería lo
  otro.
- **Se dice cuántos entregaron**, no cuántos se llamaron: `equipo 2/3 · 5
  llamadas`. Un ejecutor que falló no cuenta como trabajo hecho.
- **Al director se le pide que diga lo que no pudo verificar**, empezando por
  «Sin verificar:». Un veredicto que firma lo que no comprobó vale menos que
  ninguno. Es la puerta de entrada al Evidence Mode de la §10.
- **`/orquesta` vale para UN envío y se apaga solo.** Dejarlo encendido haría
  que el siguiente «gracias» costara seis llamadas.

### Pruebas

- 29 unitarios de `orquesta.ts`, la mayoría sobre el techo y sobre qué NO se
  promete.
- E2E `orquesta.spec.ts` con dos modelos simulados (`mock-director`,
  `mock-obrero`): que el reparto se lee, que **cada ejecutor recibe solo su
  trozo** —comprobado sobre el cuerpo real de cada petición—, que el aviso sale
  antes, y que un encargo corto **no dispara ni una llamada de reparto**.

### Puerta

- ✓ lint · ✓ knip · ✓ build · ✓ **1 414** unitarios (1 385 antes) · ✓ **177**
  E2E (173 antes), suite completa en verde **dos veces seguidas**
- ✓ `npm start` + `/api/version` → `3.46.0` · ✓ `VERCEL=1` sin `standalone` y
  con el `.nft.json`

### Lo que falta para que esto sea de verdad seguro con dinero

Y esto es lo importante, porque la pieza está pero el perímetro no:

- **No hay tope de gasto por sesión ni por día.** El techo es por encargo. Diez
  encargos seguidos son sesenta llamadas y nadie te para. Es lo siguiente.
- **Los ejecutores se eligen solos.** No puedes decir «estos tres y no otros»,
  ni excluir un proveedor concreto del reparto. Con datos sensibles, eso hace
  falta.
- **El director no puede rechazar el reparto a medias.** Si ve que dos trozos
  volvieron mal, cierra con lo que hay; no puede pedir que se rehaga uno. Es a
  propósito —ahí empieza el bucle que multiplica el coste— pero es una
  limitación real y no una virtud.
- **Nada de esto pasa por los permisos del agente.** Los ejecutores no usan
  herramientas, así que hoy no escriben nada; el día que lo hagan, hay que
  meterlos por `tool-permissions.ts` y por las reglas «no tocar».

## v3.47.0 — El perímetro del dinero: techo de llamadas y veto de proveedores

De la lista de «lo que falta para que esto sea de verdad seguro con dinero» que
cerraba la v3.46.0, esta entrega las dos primeras. Son las dos que hacían falta
para poder poner una clave **de pago** en Prism sin cruzar los dedos.

### 1. Techo de llamadas de pago al día (`gasto.ts`)

El orquestador multiplica por encargo: seis llamadas donde antes había una. Diez
encargos seguidos son sesenta llamadas y hasta hoy nadie paraba eso.

- **Solo cuenta lo de pago.** Un techo que también corta lo gratis molesta sin
  proteger nada, y un límite que estorba se acaba quitando —y entonces tampoco
  protege el día que hace falta.
- **Por día natural y en hora local.** El susto de la factura es del día; si el
  contador se reiniciara en UTC, el límite saltaría a media tarde sin
  explicación.
- **Encendido de fábrica, en 200.** Apagado no protege a quien no sabe que
  existe, que es justo quien se lleva el susto. Una conversación normal son 1-3
  llamadas; un encargo con equipo, 6.
- **Se cuenta lo intentado, no lo cobrado.** Desde el dispositivo no hay forma
  de saber si el proveedor cobró. Una petición que sale puede costar: se cuenta,
  y se dice que se cuenta así.
- **Una llamada rechazada NO gasta cupo.** Si la gastara, el contador se
  dispararía solo al reintentar.
- **Nada de dinero en pantalla.** Los precios varían por proveedor, por modelo y
  con el tiempo. Un «≈ 2,40 $» inventado es peor que un número honesto de
  llamadas. La prueba E2E comprueba que el aviso **no contiene un `$`**.
- **El mensaje dice que el límite es TUYO** y dónde se cambia. Sin eso, el
  usuario culpa a su proveedor y se pone a cambiar de clave.

### 2. Vetar un proveedor sin borrar su clave (`vetados.ts`)

Tener una clave conectada y querer que ese proveedor concreto no vea tu código
son cosas compatibles. Antes no lo eran: conectado el proveedor, el failover, el
panel de consenso y los ejecutores del orquestador podían acabar mandándole la
conversación sin que tú lo decidieras.

- Un botón por proveedor en Ajustes → Proveedores. Queda conectado —sigue
  contando para el radar de modelos gratis— y **no recibe ni una petición**.
- Se aplica en los tres caminos automáticos (`attemptFailover`, `pickPanel` en
  sus dos llamadas, ejecutores) **y** en el envío a mano.
- Se dice lo que un veto NO es: no es cifrado ni anonimato, y vale hacia
  delante. Lo que ya le mandaste, mandado está.

### Dónde se comprueban las dos

En `streamChat`, antes de construir la petición. Ahí y no en la interfaz: por
ese embudo pasan **todas** las llamadas —chat, failover, panel, ejecutores,
probe de herramientas—, y comprobarlo arriba dejaría fuera justo los caminos
automáticos, que son los que eligen por ti y donde nadie se fija. Es el mismo
patrón de dos capas que ya usaban los permisos y las reglas «no tocar»: decírselo
al modelo **y** rechazarlo en el punto de ejecución.

El contador vive en memoria del módulo y **no se persiste**: un contador en
localStorage se borra desde DevTools en dos clics, y entonces no es un techo.
El precio es que recargar la pestaña lo reinicia; queda dicho aquí en vez de
fingir que es a prueba de todo.

### Pruebas

- 25 unitarios nuevos (`gasto.test.ts`, `vetados.test.ts`) y 4 propiedades
  nuevas en `perimetro.prop.ts`: que **nunca** pasan más de `tope` llamadas de
  pago en un día, que lo gratis nunca se frena, que un proveedor vetado no
  sobrevive al filtro y que alternar el veto dos veces deja la lista igual.
- E2E `gasto-y-veto.spec.ts`: se mira **lo que llega al proveedor**, contando
  las peticiones reales, no lo que dice la pantalla.

Tres cosas que la propia prueba enseñó, y que valen más que el verde:

1. El primer intento sembraba `topeLlamadasPago: 1`. Verde… pero mentiroso:
   `normalizarTope` sube cualquier valor por debajo de 10, así que estaba
   probando el saneado, no el techo. Ahora agota el mínimo real.
2. Enviar mientras la anterior se genera deja el texto puesto y el clic sin
   efecto. La prueba fallaba por la carrera, no por el techo.
3. `send()` descarta dos envíos separados por menos de 350 ms (anti doble clic)
   y el mock responde en 0,1 s: dos envíos seguidos caían dentro de esa ventana.

Y verificado en rojo: quitando las dos comprobaciones de `streamChat`, tres de
los cuatro casos fallan.

### Puerta

- ✓ lint · ✓ knip · ✓ tsc · ✓ build · ✓ **1 445** unitarios (1 414 antes) ·
  ✓ **181** E2E (177 antes), suite completa en verde **dos veces seguidas**
- ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin `standalone` y con el
  `.nft.json`

### Lo que sigue faltando

- **El director no puede pedir que se rehaga un trozo.** A propósito: ahí empieza
  el bucle que multiplica el coste. Sigue siendo una limitación real, no una
  virtud.
- **Los ejecutores no pasan por `tool-permissions.ts`.** Hoy no usan
  herramientas, así que no escriben nada; el día que lo hagan, hay que meterlos
  por ahí y por las reglas «no tocar».
- **El techo se reinicia al recargar la pestaña.** Ver arriba el porqué.

## v3.48.0 — Dos daños visuales, y el panel dice en qué se te va (modelo × encargo)

Todo esto sale de capturas reales en un móvil, no de una idea de mejora.

### 1. El pie del mensaje se partía letra a letra

La fila de debajo de cada respuesta era `flex h-6` sin envolver. Con el nombre
del proveedor y el chip de contexto a la vez en una pantalla de 360 px, el
navegador partía el texto en vertical —una letra por línea— y lo pintaba
**encima** de los botones de la respuesta. Ahora la fila envuelve, el alto es
mínimo y no fijo, y cada trozo trunca en una línea. El chip de contexto sigue
enseñando el detalle completo al tocarlo: se recorta lo que se ve, no lo que se
sabe.

### 2. El Panel del sistema pintaba el pie sobre la tabla

Dos scrolls anidados: la pestaña se desplazaba y el cuerpo de Uso también. Sin
`min-h-0`, el área desplazable de dentro no tenía límite, así que «Total
histórico: 37 peticiones» acababa cruzado sobre las filas. Manda uno solo, y es
el de dentro. De paso, la tabla de seis columnas —que se cortaba por la derecha
y dejaba el p95 a medias— ahora desliza dentro de su propia caja sin que la
página se mueva de lado.

### 3. «Gasto»: qué modelo de pago se lleva cada tipo de encargo

El panel de Uso mezclaba gratis y de pago en una tabla ordenada por número de
peticiones, que es justo el orden que no sirve cuando hay una factura. La
pestaña nueva —y la que abre por defecto— responde a otra cosa:

- **Esta sesión, contra tu techo**: llamadas de pago y gratis desde que abriste
  Prism. Se dice que es «esta sesión» y no «hoy» porque el contador del techo
  vive en memoria a propósito (en localStorage se borra desde las DevTools) y
  recargar lo reinicia. El histórico, que sí persiste, va aparte.
- **En qué se te va**: cada tipo de encargo con su barra, y **dentro de cada
  encargo, qué modelo lo hizo** con sus llamadas y sus tokens. Por separado,
  «gastas en páginas web» y «gastas con este modelo» no deciden nada; cruzados
  sí: «las páginas web me las está haciendo el de pago, eso lo muevo al gratis».
- **Modelo a modelo**: el total de cada modelo de pago y su desglose.

Reglas que se mantienen:

- **Ni un importe.** No hay `$` ni `€` en toda la pestaña, y hay una prueba E2E
  que lee el diálogo entero y lo comprueba. Los precios cambian por proveedor,
  por modelo y por tramo de contexto; desde el navegador no se conocen.
- **Los tokens llevan «≈» siempre.** Son caracteres ÷ 4, la misma regla del
  medidor de contexto. El contador exacto lo tiene tu proveedor.
- **Sin porcentaje sin denominador.** `parteDe(n, 0)` devuelve `null` y la barra
  no se pinta, en vez de un 0 % que se lee como medido.
- **Lo de antes no se reparte a ojo.** El tipo de encargo se guarda desde esta
  versión; lo registrado antes se cuenta aparte como «sin clasificar».

### 4. «Cuota» ya no tiene icono propio

Estaba dentro del Panel y fuera en la barra lateral: dos puertas a la misma
pantalla obligan a recordar cuál lleva a qué. Se queda la del Panel y se borra
el diálogo suelto, que quedaba inalcanzable. **Arena y Uso siguen duplicados
igual** —están dentro del Panel y fuera— y se quitan en cuanto lo digas; no lo
he hecho por mi cuenta porque solo se pidió Cuota.

### Pruebas

- 22 unitarios de `gasto-modelos.ts` y 4 propiedades nuevas: que ningún modelo
  con capa gratuita se cuela en el gasto de pago, que el reparto por encargo
  nunca suma más llamadas de las que hubo, y que sin total no sale porcentaje.
- E2E `panel-gasto.spec.ts`, 6 casos, incluidos los dos daños visuales medidos
  con `boundingBox` a 360 px: que el área desplazable **termina** antes del pie,
  y que el chip de contexto ocupa una línea y no trescientos píxeles.
- Verificado en rojo: sin los arreglos, los dos casos visuales fallan; sin
  guardar el tipo de encargo, el del desglose falla; sin los modelos dentro de
  cada encargo, el del cruce falla.

### Puerta

- ✓ lint · ✓ knip · ✓ tsc · ✓ build · ✓ **1 471** unitarios (1 445 antes) ·
  ✓ **187** E2E (181 antes), suite completa dos veces
- ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin `standalone` y con el
  `.nft.json`

### Lo que sigue sin saberse

El gasto real en dinero. No es un hueco que se pueda tapar desde aquí: haría
falta la tarifa de cada modelo, mantenida al día, y una tarifa vieja en pantalla
es peor que ninguna. Lo que sí se puede hacer algún día es leer el uso que
reportan las APIs que lo reportan (OpenRouter lo hace) y enseñar **eso**, dicho
como lo que es: el dato del proveedor, no una cuenta nuestra.

## v3.49.0 — Caché del prompt, la cuenta del proveedor y el catálogo de Anthropic

Sale de una pregunta: «¿ya es seguro usar una clave de pago aquí, y vale la
pena?». Investigando para contestarla aparecieron tres cosas que no se sabían.

### 1. Prism no cacheaba nada, y esa era LA palanca

Un cliente de chat reenvía la conversación entera en cada turno. Con claves
gratis eso solo gasta cuota; con una de pago se paga entera cada vez. Y el
prompt de Prism no es corto: mapa del proyecto, notas, reglas «no tocar»,
skills y N mensajes viajan siempre.

Anthropic cobra una fracción por la parte del prompt que ya vio hace poco, si
se le dice dónde cortar. **No se le decía en ningún sitio** —busqué
`cache_control` en todo el cliente y no aparecía ni una vez—. Ahora:

- el **prompt de sistema** viaja como bloque con el corte al final: es la parte
  más grande y la que menos cambia;
- el **historial** lleva dos cortes: el último mensaje (para que el turno
  siguiente lo encuentre entero en caché) y uno anterior, como red de seguridad
  por si la caché del último ya expiró;
- **nunca más de tres**, con el del sistema. La API admite cuatro y el que
  sobra se deja libre a propósito: gastarlos todos aquí impediría marcar nada
  más adelante sin romper esto.

Es el mismo texto de siempre a otro precio, no menos texto.

### 2. La compresión y la caché se peleaban

El modo «estándar» reescribe los mensajes viejos del asistente. La caché exige
que el prefijo sea idéntico byte a byte. Comprimir para ahorrar un puñado de
caracteres y perder por el camino el descuento del prefijo entero es un mal
negocio, así que **con Anthropic la compresión se apaga sola** — y se dice en
Ajustes, porque una opción que la app desactiva por su cuenta sin avisar se lee
como que está rota.

### 3. Ahora se enseña la cuenta del PROVEEDOR

Todo lo que enseñaba el panel lo contábamos nosotros: caracteres, llamadas,
tokens aproximados. Prism **no leía el `usage` de ninguna respuesta**. Ahora sí,
en los tres protocolos (Anthropic siempre lo manda, OpenAI a veces, Gemini en
`usageMetadata`), y la pestaña Gasto tiene una tarjeta nueva con tokens reales
y **qué porcentaje del prompt entró por caché**. Donde el proveedor no lo dice,
dice «sin dato» — no ceros.

Dos detalles que costaban un fallo silencioso:

- **Fundir no es sumar.** En streaming, Anthropic manda la entrada al empezar y
  la salida al acabar: son trozos de UNA respuesta y gana el mayor. Pero cada
  vuelta del bucle del agente es una llamada distinta: ahí hay que SUMAR.
  Confundirlas haría que un agente de seis vueltas reportara el gasto de una.
- **El uso se reinicia por candidato.** Si el primer modelo de la cadena falla
  y responde el segundo, la cuenta del caído no puede acabar sumada al que
  respondió.

### 4. El catálogo de Anthropic estaba muerto

Ofrecía `claude-sonnet-4-5-20250929`, `claude-opus-4-1-20250805`,
`claude-3-7-sonnet` y `claude-3-5-haiku`: generaciones pasadas, algunas ya
retiradas, y con el sufijo de fecha que los ids actuales no llevan. Quien
conectara una clave hoy elegiría de una lista de modelos que ya no existen.
Ahora son `claude-opus-5`, `claude-sonnet-5`, `claude-haiku-4-5` y
`claude-opus-4-8`. Hay una prueba que impide que vuelvan los dos patrones que
lo delataban (sufijo de fecha, generación vieja) — no puede saber qué modelos
existen hoy, pero sí que no vuelvan los que ya se retiraron.

### Pruebas

- 33 unitarios de `cache-prompt.ts` + 4 propiedades: que los cortes **siempre**
  caben en lo que admite la API, que son índices reales sin repetir, que sumar
  el gasto de varias llamadas nunca pierde lo que un proveedor sí reportó, y
  que el acierto de caché nunca sale de 0-100 ni se inventa sin denominador.
- E2E `cache-anthropic.spec.ts`: se lee **el cuerpo real de la petición**, no la
  pantalla. Para poder hacerlo, el mock aprendió el protocolo de Anthropic
  (`/v1/messages` con su `usage`) — hasta ahora solo hablaba OpenAI y ese camino
  no tenía ninguna prueba de extremo a extremo.
- Verificado en rojo: sin los cortes fallan tres de los cuatro casos.

**Y una prueba que se cayó sola en la revisión:** el caso de la compresión
pasaba en verde con el arreglo puesto **y quitado**. El mensaje que enviaba
tenía menos de 120 caracteres y `compressHistory` ni entra por debajo de ese
umbral, así que no comprobaba nada. Alargado el mensaje, falla sin el arreglo.
Es la tercera vez que aparece el mismo patrón (la propiedad del escudo PII, el
techo sembrado en 1): **un test verde no prueba nada hasta que se le ve fallar.**

### Puerta

- ✓ lint · ✓ knip · ✓ tsc · ✓ build · ✓ **1 508** unitarios (1 471 antes) ·
  ✓ **191** E2E (187 antes), suite completa dos veces
- ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin `standalone` y con el
  `.nft.json`

### Lo que sigue sin saberse, y no se puede tapar desde aquí

- **Cuánto cuesta en dinero.** Haría falta la tarifa de cada modelo mantenida al
  día; una tarifa vieja en pantalla es peor que ninguna.
- **Si la caché acertó, antes de mandar.** Solo se sabe después, por lo que
  responde el proveedor. Marcar un corte no garantiza que se cachee: por debajo
  de un mínimo de tokens el proveedor lo ignora en silencio, y la caché caduca
  en minutos. Por eso lo que se enseña es lo que él dice que hizo, no lo que
  nosotros pedimos.
- **La clave sigue en `localStorage`.** El techo, el veto y el escudo protegen
  del gasto y de la fuga hacia los modelos; ninguno protege de un XSS, de una
  skill pegada de un desconocido o de una extensión del navegador. Lo sensato
  es una clave de un workspace aparte, con su propio límite de gasto.

## v3.50.0 — Sí se puede saber lo que cuesta: importes con fuente y fecha

Durante versiones enteras esta app se negó a enseñar un importe, y la razón
escrita era «los precios no se pueden saber desde el navegador». **Era falsa.**
No se pueden *adivinar*, que es otra cosa muy distinta, y confundir las dos me
llevó a defender un hueco en vez de ir a buscar el dato. El usuario dijo que
existían repositorios que hacen exactamente esto. Los hay, y tenía razón.

### Lo que se buscó, y lo que se comprobó

`model_prices_and_context_window.json` de **LiteLLM (BerriAI)** — el mismo
catálogo con el que ellos calculan costes: **3.561 modelos**, actualizado a
diario, con precio de entrada, de salida, de lectura de caché y de escritura de
caché por token. Licencia **MIT**, la misma que Prism (verificado en su LICENSE:
todo salvo `enterprise/`).

Lo que se midió antes de escribir una línea de código:

- **De los 17 modelos que Prism cuenta como de pago, los 17 tienen precio.**
  Ni uno se queda fuera. Los que no aparecen en el catálogo son todos de
  proveedores que Prism ya trata como gratis (Groq, Cerebras, Ollama, NVIDIA,
  Kimi, Mistral), donde el precio no hace falta.
- Los precios de la familia Claude **coinciden con una segunda fuente
  independiente**, la documentación de la propia API de Anthropic. Para el
  resto de proveedores hay una sola fuente, y eso queda dicho aquí.
- El subconjunto que a Prism le sirve son **448 modelos, 36 KB**. El catálogo
  entero son 2 MB: no tiene sentido meterlos en un navegador para explicar el
  gasto de cuatro modelos.

*(models.dev, la otra fuente que quería cruzar, está bloqueada por la política
de salida de este entorno. No pude comprobarla; queda pendiente y dicho.)*

### La regla, que no se salta nunca

    importe = (tokens que dijo el proveedor) × (precio fechado del catálogo)

Las dos mitades o ninguna:

- **Nunca se multiplica nuestra estimación de caracteres ÷ 4.** Ese número vale
  para hacerse una idea del tamaño de un prompt; multiplicado por un precio se
  convierte en una factura inventada con pinta de exacta.
- **Nunca se rellena un modelo que no está en el catálogo** con el precio de uno
  «parecido» ni con la media del proveedor. Y una coincidencia solo cuenta si el
  proveedor es el mismo: el mismo modelo por dos pasarelas puede costar distinto.
- **Cuando falta una mitad se dice CUÁL.** No «sin dato» a secas, sino «tu
  proveedor no dijo cuántos tokens gastó» o «este modelo no está en el catálogo
  de precios».
- **La fecha y la fuente viajan pegadas al número**, siempre, y a los 45 días la
  app avisa de que la instantánea es vieja en vez de seguir enseñándola con cara
  de actual.
- **Sin precio de caché declarado no se supone descuento**: se cobra como entrada
  normal. Conservador a propósito — nunca enseñar un gasto menor del que pudo ser.

### Ningún precio está escrito a mano

`npm run precios` (`scripts/precios.mjs`) baja el catálogo y genera
`precios-datos.ts` con la fecha y la fuente en la cabecera. Un precio tecleado
envejece en silencio; generado, la pregunta ante un número raro no es «quién lo
puso» sino «de qué día es la instantánea». Y `/api/precios` lo refresca en
caliente —mismo patrón que el radar: petición pública sin clave, caché de 24 h,
guardián delante— para no depender de una versión nueva de Prism. Si falla,
devuelve la instantánea empaquetada y **dice que es esa**; si el catálogo vuelve
sospechosamente corto, se descarta.

### Lo que ahora se ve

Importe total, desglosado en entrada, salida y caché; **lo que la caché del
prompt te ahorró en dinero** (en la prueba real: 0,012 $ ahorrados de 0,019 $
que habría costado); el coste de cada modelo de pago; y el coste de **cada tipo
de encargo**, que era lo que se pidió hace dos versiones y hasta ahora solo se
podía responder en caracteres. Para eso los tokens del proveedor se guardan
también **por encargo** — repartir el total por caracteres habría sido inventar
con aire de exactitud.

### Pruebas

- 27 unitarios de `precios.ts`, entre ellos tres invariantes del propio catálogo:
  que **todos** los modelos de pago de Prism tienen precio, que ningún precio es
  cero o negativo, y que la lectura de caché nunca cuesta más que la entrada
  nueva (si lo fuera, el «ahorro» de la pantalla sería negativo y estaría mal
  leído el catálogo).
- E2E `precios.spec.ts`: el importe se **calcula aparte** en la prueba, a partir
  del catálogo, y se compara con el de la pantalla. Sacar el número de la propia
  pantalla no habría comprobado nada.
- Verificado en rojo los cuatro casos: sin tokens del proveedor caen tres; sin
  la línea de fuente cae el cuarto.

**Dos pruebas viejas se cayeron solas, y está bien que lo hicieran.** Ambas
afirmaban «en el panel no aparece ningún `$`», que era la regla correcta hasta
hoy. Actualizadas a la regla nueva —que es más fuerte, no más débil—: con
catálogo y tokens **tiene** que haber importe, y **nunca** puede haberlo sin su
fuente al lado. La que usa un modelo inventado (`mock-paid-pro`) sigue exigiendo
que no aparezca ni un importe.

### Puerta

- ✓ lint · ✓ knip · ✓ tsc · ✓ build · ✓ **1 535** unitarios (1 508 antes) ·
  ✓ **195** E2E (191 antes), suite completa dos veces
- ✓ `npm start` + `/api/version` · ✓ `/api/precios` probado contra el servidor de
  producción: 448 modelos, `vivo: true` · ✓ `VERCEL=1` sin `standalone` y con el
  `.nft.json`

### Lo que sigue sin saberse

- **Esto no es tu factura.** Es una estimación con fuente. Los descuentos por
  volumen, los tramos de contexto largo, los impuestos y las tarifas negociadas
  no están y no se pueden conocer desde aquí.
- **Una sola fuente para casi todos los proveedores.** Para Claude hay dos y
  coinciden; para el resto, si el catálogo se equivoca, Prism se equivoca igual.
  Por eso la fuente se nombra: para que se pueda ir a comprobar.
- **Los modelos que añadas a mano** pueden no estar en el catálogo. Entonces sale
  «sin dato» y el total avisa de que no los incluye — un total que se calla lo
  que le falta miente por defecto.

## v4.0.0 — Los 4 pilares: parches SEARCH/REPLACE, checkpoints de un clic, memoria .prism/, diseño dirigido, Pages y recomendación con porqué

Implementación completa de `PRISM_AI_PLAN_ESCALADO.md` (4 pilares, 8 fases) y `PRISM_AI_PLAN_TECNICO.md` (Auto Context, Negative Memory con modal, Task DNA, Evidence Mode), sin rewrite: todo evoluciona sobre la base existente.

### Pilar 1 — Fiabilidad al editar

- `patch.ts` (nuevo): parser y aplicador de bloques `<<<<<<< SEARCH / ======= / >>>>>>> REPLACE`. Tolera flechas de más, cabeceras con texto, rutas del archivo en la primera línea y UN reintento flexible por sangría. Bloque no único falla a propósito; los que aplican, aplican, y el modelo recibe qué falló y cómo arreglarlo sin reescribir.
- Tool `apply_patch` (tools-catalog + tool-runner): varios parches sobre un archivo en una sola llamada, aplicados LOCALMENTE (el modelo devuelve parches, no reescrituras). Permisos declarados (`escribe_proyecto`); test de catálogo cerrado actualizado.
- Prompt del agente XML: regla nueva de edición por parches con bloque `diff` para cambios parciales.
- `reglas-no` con autorización temporal: `ToolContext.reglasAutorizadas` + helper `vetoDe` (write_file, edit_file, apply_patch y git_snapshot restore lo respetan).

### Pilar 1.3 — Checkpoints y rollback de un clic

- `snapshots.ts`: campo `sesion` (compatibilidad con antiguos globales), `origen`, `checkpointAuto()` (crea+guarda antes de cada tarea del agente) y `archivosDeSnapshot()`.
- `chat-app`: checkpoint automático ANTES de cada tarea del agente (depth 0, sin revisiones), mapeado mensaje→snapshot para el botón «Deshacer» en cada respuesta del agente. Deshacer guarda primero el estado actual (reversible).
- `snapshots-panel.tsx` (nuevo): panel con lista por sesión, diff real antes/después (DiffView) y restauración de un clic. Botón en la cabecera.

### Pilar 3 — Memoria estructurada y despliegue

- `memoria-proyecto.ts` (nuevo): DecisionMemoria, ErrorMemoria, TareaMemoria (Task DNA), DisenoUsado y ReglaMemoria; persistencia `prism-memoria-v1` por sesión; export/import a los cinco JSON de `.prism/` (aArchivosPrism/deArchivosPrism, tolerante a JSON corrupto y rutas con carpeta raíz).
- Task DNA: al terminar cada generación se guarda objetivo, modelo, estado, reintentos y archivos detectados; las notas del `<project-map>` del modelo entran como decisiones.
- `.prism/` viaja con el repo: github-dialog añade los JSON a la subida; `memoria-panel.tsx` (nuevo) permite copiarlos para Repo Studio.
- Despliegue: `deploy.ts` genera el workflow de GitHub Pages (Pages actions v4), `repo-cloud.habilitarPages()` (idempotente) y botón «Publicar en Pages» en Repo Studio — prompt → URL viva.
- Commits con significado: `mensajeCommit()` genera «Añade galería, actualiza index.html» desde los cambios reales; `entradaChangelog()` listo para CHANGELOG.md.

### Pilar 2 — Diseño no genérico

- `design-directions.ts` (nuevo): 5 direcciones curadas (editorial, minimal, tech, brutalista, cálido) con paleta OKLCH, pareja tipográfica, radios, sombras, composición prohibida y detalles. Elicitación en dos capas: palabra clave del prompt → esa; si no, rotación determinista evitando las ya usadas (variación forzada vía memoria).
- `promptDireccion()` (bloque obligatorio del system para encargos de UI nueva) + CHECKLIST_ANTI_SLOP de 5 dimensiones que el modelo se autoexige antes de entregar.
- Integrado en `prompt-actual.ts` (pieza `diseno`, con presupuesto) y contado en `contexto-usado` (`diseno`).

### Pilar 4 — Recomendación con porqué

- `recomendacion.ts` (nuevo): matriz por tipo de tarea (web/code/chat…), +10 a gratis por defecto, ajuste por experiencia medida (`experiencia.ts`) y castigo con historial real de reintentos del proyecto (Task DNA ≥ 4 → −18 y razón lo explica). Escalada a pago solo con alternativa gratis visible.
- Tarjeta sobre el compositor: «Tarea: web → modelo · razón» con botón Usar.

### Auto Context + Evidence Mode

- `auto-contexto.ts` (nuevo): keywords del prompt (rutas primero) → archivos por nombre/contenido, decisiones, errores, reglas y notas. Bloque para el prompt (pieza `contexto`) y chips pre-envío «Contexto que se usará». Fix durante tests: copia profunda de arrays (el spread compartía referencias y contaminaba turnos).
- `evidencia.ts` (nuevo): parser de citas `archivo:línea` y `línea N de archivo` (ignora URLs/horas, dedup, tope 12); instrucción en el prompt del agente; message.tsx renderiza chips con la línea citada en el tooltip si el archivo está en el Sandbox.

### Marketing (fase 8)

- `marketing.ts` (nuevo): email (tablas + fallbacks), carrusel 1080×1080 (3 tarjetas) y póster editorial; todos viajan con los tokens de la dirección del proyecto si existe (misma casa) y con la checklist.
- Slash `/email`, `/carrusel`, `/poster` con plantilla resuelta AL insertar (resolverPlantillaMarketing + dirección existente).

### Puerta

- ✓ lint (0 errores, 0 warnings) · ✓ tsc · ✓ build (Next 16, 12 rutas) ·
  ✓ **1 628** unitarios (1 535 antes; 93 nuevos en 8 suites: patch, memoria-proyecto, auto-contexto, evidencia, design-directions, deploy, recomendacion, marketing) ·
  ✓ catálogo de tools y slash actualizados en sus tests cerrados
- knip: falla en este entorno (oxc-parser/ArrayBuffer en Node 24), preexistente, sin relación con los cambios.
- Versión 4.0.0 (package.json + app-version.ts + lock).

## v4.1.0 — Segundo corte de `chat-app.tsx`: la tubería de generación es un hook

El PLAN-V8 lo tenía dicho: «partir `chat-app.tsx`» era el punto 1 de lo que
entra después, y el primer corte (v3.44.0) avisó de que lo grande era
`runGeneration`, «acoplado a decenas de closures, no se toca de una sentada».
Entre v3.44 y v4.0 el archivo había seguido creciendo: **3.569 líneas** al
empezar esta versión. Al terminar: **1.976**. El archivo solo perdió líneas,
como pedía la regla.

### Tres cortes, un commit cada uno

1. **`use-chat-attachments.ts`** (3.569 → 3.445). El borrador de adjuntos y
   todo su I/O (abrir ZIP con el lector del Sandbox, parsear hojas, extraer el
   PDF, comprimir imágenes) sale del componente. La lógica pura del reparto ya
   vivía en `reparto-adjuntos.ts` desde el primer corte; esto es la tubería que
   la rodea. `send()` limpia ahora con `clearDraft()`.
2. **`use-system-prompt.ts`** (3.445 → 3.419). `piezasDelPrompt` y
   `composeSettings`, con `VENTANA_AHORRO`. Un solo camino para el envío y el
   medidor de Ajustes — que era la razón de ser de esa pieza.
3. **`use-generation.ts`** (3.419 → 1.976). `runGeneration` entero, con su
   cadena de candidatos, el failover con rescate de trabajo a medias, la
   continuación de código cortado, el checkpoint automático, la memoria de
   tareas y de fallos, la lectura automática — y con él `runConsensus`,
   `runOrquesta`, `attemptFailover`, `relanzar`, `sendImage`, `setModelKey`,
   `resolveModel` y el estado de streaming. El hook recibe por `CtxGeneracion`
   lo que toca la pantalla (avisos con botón, Sandbox, refs cuyo dueño es el
   marco) y del store sirve lo demás leyendo FRESCO en cada corrida, igual que
   hacía el componente.

### Lo que el corte arregla de paso

- **El checkpoint podía ser de una foto vieja.** `runGeneration` leía
  `sandboxInitial` de la clausura del `useCallback`, y esa clausura solo se
  renovaba cuando cambiaba el modelo (`resolveModel` era su única dependencia
  viva). Cargar archivos nuevos en el Sandbox entre dos envíos no renovaba la
  clausura: el checkpoint del agente podía guardar los archivos ANTERIORES.
  Ahora `sandboxInitial` entra por props del hook y el callback se renueva con
  él. Es un arreglo de un borde, no un cambio de comportamiento: los E2E de
  checkpoints siguen en verde sin tocarlos.
- Un import huérfano de `isSheetFile` que llevaba ahí varias versiones.

### Un rojo que la puerta destapó de la v4.0

El E2E `tools-agente.spec.ts` comprueba con lista cerrada que el catálogo
TRADUCIDO llega entero al modelo. La v4.0 añadió `apply_patch` al catálogo y
no actualizó esa lista: el test llevaba roto desde entonces (la puerta de la
v4.0 no corrió la suite E2E completa — esta sí). Corregida la lista a 16; el
rojo se vio antes del arreglo, así que el test prueba lo que dice.

### Pruebas

- Ninguna nueva. Es un refactor: nada nuevo que el usuario vea ni pulse, así
  que no toca E2E nuevo (regla §4 del contrato). La red es la suite entera,
  que corre dos veces en verde contra el resultado del corte.

### Puerta

- ✓ lint 0/0 · ✓ tsc limpio, y limpio además con `--noUnusedLocals` en
  `chat-app.tsx` (los avisos que quedan en otros archivos son previos)
- ✓ build (12 rutas) · ✓ **1.628** unitarios (mismos que v4.0: nada que añadir
  ni que borrar) · ✓ **195** E2E, suite completa en verde (98 + 97 tras el
  fix del catálogo)
- ✓ `npm start` + `/api/version` → `4.1.0` · ✓ `VERCEL=1` sin `standalone` y
  con el `.nft.json`
- ✗ knip: mismo fallo de entorno que v4.0.0 (`oxc-parser` / ArrayBuffer en
  Node 24), preexistente y sin relación con los cambios.

### Lo que sigue pendiente

- **`chat-app.tsx` sigue en 1.976 líneas.** La ley de los grandes componentes:
  pierde líneas y se rellena de marco. El siguiente corte natural es el render
  (`chatArea` + los diálogos), ya sin lógica de generación dentro.
- **`use-generation.ts` es grande a propósito** (1.569 líneas). Partirlo hoy
  sería mover el acoplamiento, no quitarlo: los tres caminos comparten
  burbuja, abort y `runGenRef`. Cuando el marco de `chat-app` esté estable se
  revisa si `runConsensus` y `runOrquesta` merecen archivo propio.
- Las reglas «no tocar» siguen sin cubrir el camino XML del agente (pendiente
  heredado de v3.44, sigue abierto).
## v3.51.0 — Modo Repaso: la conversación que vuelve el día que toca

La petición esta vez venía de fuera: «propón tú algo, un súperpoder, sorpréndeme».
Descarté lo que el propio plan ya tenía en cola (memoria negativa, i18n) y lo que
el repo había descartado con argumento (embeddings locales, orquestadores). Lo que
quedó fue un hueco de verdad: Prism guarda tus conversaciones, tus decisiones y tu
memoria de proyectos, pero **nada de eso vuelve a visitarte**. Escribes con el
modelo hoy y lo que hablaste se hunde. El repaso espaciado es exactamente eso:
lo que hablas se convierte en tarjetas, y las tarjetas vuelven el día que toca.

### Cómo funciona, y las dos decisiones con por qué

- Pides el examen (`/repaso` → «Preparar petición», o con tus propias palabras):
  el modelo responde con un bloque ` ```prism-repaso ` y el mensaje ofrece
  «Guardar repaso». Tres puertas al repaso: la barra lateral (con insignia de
  vencidas, como el Radar), el slash, y el propio mensaje.
- SM-2 (SuperMemo-2), el de Anki. Sobre el original, dos cambios escritos:
  **techo de facilidad 2.9** (sin él, una tarjeta fácil dispara los intervalos y
  dejan de discriminar) y **«otra vez» vence HOY** (no mañana): la tarjeta
  reaparece al final de la misma sesión, que es como se aprende lo que cuesta.
- Las tarjetas viven en SU clave de localStorage (`prism-repaso-v1`), al margen
  del store principal: si algo sale mal en este saco, no arrastra conversaciones
  ni claves (regla 3.6). Los duplicados no tocan el progreso de la tarjeta vieja.

### El E2E cazó un fallo real antes de llegar a main

El spec se escribió ANTES de cablear la interfaz y se comprobó que se ponía rojo
(sin el cambio, los dos tests fallaban). Al conectar el diálogo, «Día completado»
era inalcanzable: la condición miraba `totalSesion === 0`, pero el contador de la
sesión (hechas + cola) **solo crece** con las «otra vez» — nunca vuelve a cero.
El panel se quedaba en blanco y el test lo destapó con su captura. La condición
correcta es mirar la cola. También trae guardián propio la lista de slash: el
test cerrado exigió actualizarla en el mismo commit que añade `/repaso`, y
funcionó — el comando entró consciente, no por inercia.

### Puerta

- ✓ lint · ✓ build (v3.51.0) · ✓ **1 558** unitarios (1 535 antes, 23 de repaso) ·
  ✓ **197** E2E (191 antes, 2 de repaso), suite completa en tres bloques
- ✓ `npm start` + `/api/version` → `{"version":"3.51.0"}`, home y CSS 200 ·
  ✓ `VERCEL=1` sin `standalone` y con el `.nft.json`
- ✗ **knip no pudo correr aquí**: `oxc-parser` revienta con `ArrayBuffer` en Node
  24 del entorno de trabajo, antes de mirar un solo archivo — fallo de entorno,
  no de código; en CI corre con su Node y ahí queda pendiente verlo verde.

### Lo que sigue sin saberse

- **El intervalo justo no existe.** SM-2 es una heurística de 1987 pensada para
  papel: funciona porque decenas de millones de usuarios de Anki la han frotado
  contra la realidad, pero el «óptimo» de cada tarjeta depende de cada cabeza.
- **El modelo puede proponer tarjetas flojas.** El prompt pide preguntas atómicas
  y respuestas cortas; el lector recorta, descarta vacías y deduplica, pero no
  puede medir si una pregunta es *buena*. Ese juicio sigue siendo tuyo.
- **Sin pruebas con modelos reales.** El bloque lo genera el modelo que toque y
  el lector es tolerante (json, vallado sin lenguaje), pero no he podido
  comprobar cómo lo escriben los 17 proveedores del catálogo. Si alguno se sale
  del formato, el botón no aparece — no se rompe nada.

## v3.52.0 — Caza de ofertas IA: las ofertas que existen, avisadas a tiempo

Petición directa: «un apartado de cacería de ofertas de IA donde salgan las
ofertas vigentes de cada una — días gratis, % de descuento — y que me notifique».
El hueco era real: Prism ya trae el Radar de modelos gratis (API), pero nadie
recuerda al usuario que GitHub Copilot tiene plan gratuito, que el Student Pack
regala Copilot Pro, o que la promo que apuntó el martes caduca el jueves.

### La decisión dura: de dónde salen las ofertas

Sin servidor no hay raspado en vivo, y las promos relámpago con «% de descuento»
caducan más rápido de lo que una app local puede enterarse. Se tomó la vía
honesta (contrato §5, «sin números inventados»): un **catálogo base de programas
de larga vida** que viaja con la app (14 entradas: niveles gratuitos de AI Studio,
Copilot Free, Le Chat, OpenRouter :free, Groq, Cerebras, Cohere, Perplexity,
DeepSeek; créditos de Hugging Face y Together; estudiantes de Gemini y GitHub
Education), cada entrada con **fecha de verificación a la vista** y con la
descripción diciendo «la cuota exacta la publica el proveedor» donde nadie la
garantiza. Las promos con fecha de caducidad no van en el catálogo: van por la
**fuente JSON propia** del usuario (URL configurable que se valida, recorta,
deduplica y pisa el catálogo por id — puedes corregir una entrada de la base
desde tu feed). El tipo «descuento» existe en el sistema aunque la base no lo
use: lo traen las fuentes.

### Avisos sin servidor y sin molestar

Una comprobación **una vez por día local** al arrancar: dif contra `conocidasIds`
→ lo nuevo entra en la insignia ámbar de la barra lateral y en un toast; lo que
falta dentro del margen de aviso (ajustable, 1-14 días, inclusivo por ambos
extremos) avisa **una sola vez** — `avisadasIds` recuerda a quién ya avisó, para
que «termina pronto» no se repita cada día hasta la caducidad. Si el navegador
dio permiso, el aviso sale también fuera de la pestaña. El permiso se lee por la
**Permissions API** y no por el estático `Notification.permission`: el estático
miente en headless y en algunas webviews (lo cazó el E2E, no la teoría).

### Cómo se probó (contrato §4)

- 23 unitarios y 3 E2E escritos ANTES de cablear, y comprobados en rojo:
  los unitarios fallaban por módulo ausente; los E2E, porque la puerta
  «Ofertas» no existía. El guardián de slash entró en el mismo commit que
  añade `/ofertas` (conscious update, como manda).
- El E2E cazó dos cosas reales: el timing del toast (4s de sonner frente a la
  compilación del dev server — el test mira el registro persistente y la
  insignia, no un toast efímero) y el permiso estático que mentía.
- La fuente propia se prueba con `page.route`: JSON con 3 ofertas válidas y
  1 rota (sin URL http) — entran 3, la rota no tumba la carga.

### Puerta

- ✓ lint · ✓ build (v3.52.0) · ✓ **1 581** unitarios (1 558 antes, 23 de ofertas) ·
  ✓ **199/200** E2E en la suite larga (el de QR falló por carga y aislado pasa
  3/3; 3 nuevos de ofertas) · ✓ `npm start` + `/api/version` → 3.52.0, home y
  CSS 200 · ✓ `VERCEL=1` con el `.nft.json`
- ✗ **knip sigue sin poder correr aquí**: mismo fallo ambiental de Node 24
  (`oxc-parser`/`ArrayBuffer`), documentado en v3.51.0; pendiente de CI.

### Lo que sigue sin saberse

- **El catálogo envejece.** Está verificado a 06/09/2026 y cada tarjeta lo
  dice; un nivel gratuito puede cerrar sin que esta app se entere. La fuente
  propia existe justo para eso.
- **El aviso diario solo dispara al abrir la app.** Sin servicio de fondo no
  hay push real: si no abres Prism el día que sale una promo, te enterarás al
  entrar. Es el límite del «todo local» y se asume.
- **CORS de las fuentes propias.** Un feed sin cabeceras CORS no carga desde
  el navegador; el error se avisa y se conservan las ofertas de la última
  carga. No hay releve de servidor que lo esconda.

## v4.2.0 — Recuperadas dos funciones que se habían quedado fuera de la rama

Las entregas llegaron en cuatro ZIP: v3.51.0, v3.52.0, v4.0.0 y v4.1.0. Antes
de subir nada, se compararon los cuatro entre sí y contra el repo, y salió algo
que ninguno de los cuatro decía.

### No eran cuatro versiones seguidas: eran dos ramas

Por las fechas de los propios archivos, **v4.0.0 (02:37) y v4.1.0 (03:44) son
de la madrugada; v3.51.0 (16:32) y v3.52.0 (18:23), de la tarde del mismo día**.
Y ninguno de los dos 4.x menciona el Modo Repaso ni la Caza de ofertas: su
worklog salta de la v3.50.0 a la v4.0.0, y en `slash.ts`, `sidebar.tsx` y
`chat-app.tsx` no hay ni una referencia a las dos funciones.

O sea: las dos parejas salieron **de la misma base (v3.50.0), en paralelo**. Y
la numeración engaña — lo que parece «lo último» (4.1.0) es lo más antiguo de
las dos ramas.

Subir la rama 4.x tal cual, que es lo que pedía el número más alto, habría
borrado en silencio dos funciones completas con sus 10 archivos y sus pruebas.
Un `git push` que quita cosas sin decirlo es la peor forma de perder trabajo.

### Lo que se hizo

Las dos ramas eran **puramente aditivas** sobre v3.50.0 (0 archivos borrados en
ambas), así que se pudo hacer lo correcto: subir 4.0.0 y 4.1.0 tal cual —fueron
primeras en el reloj— y **fusionar Repaso y Ofertas encima**.

- 10 archivos propios de las dos funciones, copiados sin tocar.
- 5 archivos compartidos fusionados a mano: `slash.ts` (los dos comandos junto a
  los `/email`, `/carrusel` y `/poster` que trajo la 4.0), `slash-menu.tsx`
  (iconos y tintes), `message.tsx` (el botón «Guardar repaso» y el contador de
  tarjetas), `sidebar.tsx` (íntegro: la rama 4.x no lo tocó) y `chat-app.tsx`
  —el difícil, porque la 4.1 lo partió en hooks y movió de sitio casi todo:
  estado de los dos diálogos, los dos `case` del menú de comandos, guardar
  tarjetas, las dos insignias, la comprobación diaria de ofertas y el montaje de
  los diálogos.
- Recuperadas también las dos entradas de worklog que la rama 4.x había perdido,
  y las dos filas del README.

### Puerta

- ✓ lint · ✓ knip · ✓ tsc · ✓ build · ✓ **1 674** unitarios (1 628 en la 4.1.0;
  46 recuperados de las dos funciones) · ✓ **200** E2E, suite completa dos veces
- ✓ los 5 E2E propios de Repaso y Ofertas en verde **sobre la base fusionada**,
  que es lo que demuestra que la fusión los enciende de verdad y no solo que los
  archivos están copiados
- ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin `standalone` y con el
  `.nft.json`

### Lo que queda dicho

- **El número de versión de una entrega no prueba en qué orden se hizo.** Aquí
  lo que lo dijo fueron las fechas de los archivos y la ausencia de referencias
  cruzadas. Con dos sesiones trabajando en paralelo sobre la misma base, esto
  volverá a pasar: la forma de verlo es comparar contenidos, no números.
- **Las dos funciones no tienen pruebas de la 4.x encima.** Se han fusionado y
  pasan las suyas, pero nadie ha escrito todavía una prueba que cruce Repaso con
  los checkpoints o las ofertas con la memoria `.prism/`. No hay motivo para
  creer que choquen; simplemente no está comprobado.

## v4.3.0 — Datos que envejecen solos: modelos retirados y sellos de frescura falsos

El aviso vino de fuera y con dos ejemplos concretos: «GLM tiene oferta de 3
meses por 20 USD y ahí no sale; ya salió Gemini 3.8 y ahí sigue con los viejos,
como si estuvieran escritos, en vez de buscar de los sitios oficiales». Es el
mismo fallo que ya me señaló con los precios, y esta vez estaba en dos sitios
más.

### Lo que se encontró al ir a mirar

Escribí un auditor (`npm run modelos`) que compara las listas de la app con el
catálogo público de LiteLLM, que publica `deprecation_date` por modelo. El
resultado, medido y no supuesto:

- **`grok-4`, `grok-3` y `grok-3-mini`** — retirados en mayo y febrero de 2026.
- **`llama-3.3-70b-versatile` y `llama-3.1-8b-instant`** (Groq) — 2026-08-16.
- **`kimi-k2-0905-preview` y `kimi-k2-turbo-preview`** — 2026-05-25.
- **`pixtral-12b-2409`** (Mistral) — **2025-12-31**. Nueve meses muerto y ahí
  seguía, ofreciéndose el primero de la lista a quien conectara una clave.
- Y `gemini-3.8-flash`, publicado y sin ofrecer. Tenía razón también en eso.

Ocho modelos muertos. Nadie se enteraba hasta que una petición volvía con un
404 que parecía culpa de la clave.

### Lo que se hizo, para que no vuelva a pasar solo

- **`npm run modelos`**: informe (qué está retirado, qué no tiene ficha, con
  fechas) y genera `modelos-datos.ts` con 161 retiradas. **No reescribe las
  listas por su cuenta**: están curadas a mano —el orden importa, los sufijos
  `-free` de cada pasarela no salen en ningún catálogo— y una generación ciega
  las estropearía. El script dice qué cambiar; el cambio lo revisa una persona.
- **El selector marca los muertos**: chip rojo «retirado» o ámbar «se retira»
  con la fecha y la del catálogo en el tooltip. No bloquea: un modelo retirado
  puede seguir respondiendo semanas, y un catálogo ajeno puede equivocarse.
- **Las listas, arregladas** con lo que dijo el auditor. Y `kimi-k3-preview` se
  quedó: **«sin ficha» no es «retirado»**. Que un catálogo de terceros no lo
  tenga no prueba que esté muerto, y solo se quita lo que una fuente afirma.
  Lo destapó un test que ya existía y falló cuando lo quité de más.
- **Un unitario recorre PROVIDERS entero** y falla si vuelve a colarse uno
  retirado. Ese test encontró `qwen/qwen3-32b` (retirado el 2026-07-17) que
  **mi propio script no había visto**: el script comparaba el id crudo y el
  módulo lo pela igual que la app. Dos formas de pelar un id son dos verdades
  distintas; ahora comparten la misma.

### El sello de frescura que se ponía solo

Buscando lo de GLM salió algo peor que una lista vieja. Las 14 ofertas del
catálogo heredaban una constante, `OFERTAS_VERIFICADO`, puesta a la fecha de la
entrega. Es decir: **al publicar una versión, las catorce pasaban a decir
«verificado hoy» sin que nadie hubiera comprobado ninguna.** Y una oferta que
tú añadías por tu fuente propia, sin fecha, se sellaba con la nuestra: firmar
por otro.

Una fecha de verificación que se pone sola no es una verificación. Es un sello
de frescura falso, y de los peores, porque invita justo a fiarse. Ahora:

- `verificado` puede ser `null` y eso significa **«nadie lo ha comprobado»**;
- la tarjeta dice «comprobado hace N días» o **«sin verificar»** en ámbar;
- lo que llega de tu fuente sin fecha se queda sin sello, no con el nuestro;
- la prueba que **exigía** el sello uniforme se ha reescrito: exigía el error.

### GLM · Z.ai: lo que se pudo y lo que no

- **Lo verificable** entra como oferta normal: Z.ai sirve su familia Flash sin
  coste por token, que es la misma API que usa Prism con ese proveedor.
- **La promoción de tres meses por ~20 $ NO se ha podido comprobar.** La página
  de Z.ai y el archivo de la web están bloqueados por la política de red de
  este entorno, y las cifras que dan los blogs de terceros no son la fuente.
  Así que entra marcada **«sin verificar»**, diciendo en la propia tarjeta que
  no se ha podido comprobar y que el precio vigente lo publica Z.ai. Lo que no
  se hace es escribir «20 $ / 3 meses» como si fuera un dato.

### Puerta

- ✓ lint · ✓ knip · ✓ tsc · ✓ build · ✓ **1 687** unitarios (1 674 antes) ·
  ✓ **201** E2E, suite completa dos veces
- ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin `standalone` y con el
  `.nft.json`
- Verificado en rojo: sin el chip, el modelo retirado pasa sin marca.

**Y una prueba que escribí mal y quité.** Puse una E2E de «ninguna lista de
fábrica ofrece un modelo muerto» que sembraba los modelos a mano: así medía la
siembra, no la lista. Al intentar arreglarla haría falta arrancar sin modelo
elegido, y entonces el selector ni se pinta. La quité: esa invariante ya la
comprueba el unitario recorriendo PROVIDERS de verdad, que es el que encontró
el `qwen3-32b`. Una prueba que hay que retorcer para que corra vale menos que
la de al lado que sí falla cuando toca.

**Y otra que se rompió por lo mismo que arregla esta versión:** la E2E de
ofertas llevaba los ids del catálogo **copiados a mano**, daba por hecho «una
sola novedad», y al añadir las dos de Z.ai había tres. Ahora los deriva de
`OFERTAS_BASE`.

### Lo que sigue sin resolverse

- **Las ofertas no tienen API.** No existe un catálogo público de promociones
  como el de precios: lo que hay es un archivo curado a mano, ahora con la edad
  de cada comprobación a la vista. Mientras no exista una fuente, esto seguirá
  dependiendo de que alguien mire — la diferencia es que ahora se ve cuándo fue
  la última vez.
- **El catálogo de modelos es de terceros.** Es bueno y va al día, pero no es
  la web de cada proveedor. Donde no llega —los `:free` de OpenRouter, los
  nombres propios de Cerebras— el informe dice «sin ficha», que significa «no
  se sabe», no «está mal».

## v4.4.0 — Un modelo retirado dejaba la conversación muerta

Llega una captura: Auto elige `google/gemini-2.0-flash-exp:free` en OpenRouter,
el proveedor contesta **«404 No endpoints found»**… y ahí se queda. Error rojo,
fin. Con otros cuatro proveedores conectados y sin intentar ninguno.

### Por qué se paraba

`decidirTrasError` tenía dos categorías: **pasajero** (0, 408, 5xx → reintenta)
y todo lo demás (ríndete). Un 404 caía en el segundo saco, junto a una petición
mal formada. Y son lo contrario:

- **petición inválida** → probar otro modelo esconde TU error, y parar es lo
  correcto;
- **modelo que ya no existe** → la petición estaba perfecta; lo que falta es el
  modelo. Probar otro no esconde nada: es lo único sensato.

Faltaba la categoría. `esModeloMuerto(status, mensaje)` la añade, mirando el
código **y** el texto —«no endpoints found», «does not exist», «model_not_found»,
«no longer available»…—, porque ni el 404 solo ni la frase sola bastan: hay
proveedores que dicen «no existe» con un 400.

### Lo que ahora pasa

- **Con cadena**: salta al siguiente modelo. También con modelo elegido a mano;
  antes eso paraba «para no esconder el problema», pero pararse tampoco lo
  enseña — solo te deja un error rojo. Se sigue, y se dice cuál murió.
- **Sin cadena**: sale a buscar a otro proveedor conectado. Este era el caso de
  la captura, y el que se rendía incluso con Auto puesto.
- **Se marca el modelo como roto**, así que Auto deja de elegirlo. Hasta ahora
  eso solo lo hacía «Probar modelos» desde Ajustes: en una conversación normal,
  un modelo retirado volvía a salir elegido turno tras turno.
- **El aviso dice la verdad**: «Ese modelo ya no existe en OpenRouter», no
  «OpenRouter falló», que manda a mirar la clave, que está bien.

### Y el modelo concreto de la captura

`google/gemini-2.0-flash-exp:free` sale de la lista de OpenRouter. Aquí sí hay
prueba de primera mano —un 404 del proveedor en una conversación real—, que es
distinto de los otros `:free` de esa lista: el auditor de la v4.3.0 los da como
«sin ficha», y eso significa «no se sabe», no «está muerto». Esos se quedan.

### Pruebas

- 7 unitarios nuevos en `decisiones.test.ts`, incluido el que fija la conducta
  vieja: **sin la marca, ese mismo 404 devuelve «parar»**. Es la prueba de que
  la causa era esa y no otra.
- 2 E2E con el 404 de verdad del mock: que acaba **habiendo respuesta** (no un
  error rojo) y que el modelo muerto queda marcado en el almacén.
- Verificado en rojo: devolviendo la conducta anterior, las dos fallan.

### Puerta

- ✓ lint · ✓ knip · ✓ tsc · ✓ build · ✓ **1 694** unitarios (1 687 antes) ·
  ✓ **203** E2E, suite completa dos veces
- ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin `standalone` y con el
  `.nft.json`

### Lo que sigue sin cubrirse

Un modelo que existe pero devuelve basura —200 con texto vacío o un aviso del
proveedor disfrazado de respuesta— tiene su propio camino (`decidirTrasVacio`,
`decidirTrasCuotaEnTexto`) y no se ha tocado aquí. Y el failover sigue sin
poder saltar a un proveedor que no tengas conectado: si el único que tienes se
queda sin modelos vivos, no hay a dónde ir.

## v4.5.0 — La polaridad estaba del revés: se enumeraba lo que merecía seguir

Tres capturas seguidas, tres errores distintos, los tres terminando la
conversación con cuatro proveedores conectados al lado:

    OpenRouter 404: No endpoints found for google/gemini-2.0-flash-exp:free
    Groq 413: Request too large … ITPM: Limit 7000, Requested 21138
    OpenRouter 400: Provider returned error

Ayer arreglé el primero. Fue un error de diagnóstico: traté un síntoma. La
causa era la misma para los tres y estaba una capa más abajo.

### El fallo de fondo

`decidirTrasError` **enumeraba los fallos que merecen reintento** —pasajeros
(0, 408, 5xx), cuota, y desde ayer el modelo retirado— y paraba en todo lo
demás. Con esa forma, *cada error que el mundo invente entra por defecto en el
saco de «ríndete»*. Por eso, arreglado el 404, al día siguiente aparecieron un
413 y un 400 haciendo exactamente lo mismo. Y aparecerían más.

Ahora se enumera lo contrario, que es la lista corta y estable: **lo único que
para es una petición que hicimos mal nosotros** —JSON inválido, un parámetro
que ese proveedor no admite—, porque ahí probar otro modelo esconde el error de
verdad. Todo lo demás tiene otro modelo esperando.

Dos trampas que había que separar con cuidado:

- **El 400 de un router no es culpa de la petición.** OpenRouter contesta 400
  «Provider returned error» cuando el que falló fue el proveedor de detrás.
  Meter todos los 400 en «petición inválida» habría dejado el mismo callejón
  con otro nombre; por eso se mira el texto, no solo el código.
- **Un mensaje demasiado grande tampoco lo es**, aunque llegue con un 400: la
  petición está perfectamente formada, solo que no cabe.

### «No te cabe» es su propia categoría

El 413 de Groq no es un fallo del modelo ni de la clave: `qwen3.8-27b` está
perfecto y la conversación pesaba 21.138 tokens contra un tope de 7.000 por
minuto de esa cuenta. Elegir ese modelo otra vez para la misma conversación es
repetir el error a sabiendas, y eso es lo que pasaba.

`limites-medidos.ts` lo recuerda, separando lo que se sabe de lo que se supone:

- si el proveedor **dijo el número** («Limit 7000»), se guarda el suyo;
- si solo dijo «demasiado grande», se guarda **lo que se le pidió**, y a partir
  de ahí solo se descarta para mensajes igual de grandes o más — prohibir por
  debajo sería inventarse un límite que nadie dijo;
- y **caduca a las seis horas**, porque muchos de estos topes son por minuto:
  sin caducidad, un pico de tráfico de un martes apartaría ese modelo para
  siempre.

El failover ya no salta a un modelo que acaba de decir que no le cabe, y el
aviso dice «la conversación no le cabe a X» en vez de «X falló», que manda a
mirar la clave.

### Pruebas

- 13 unitarios nuevos: los tres errores de las capturas, con su texto literal,
  comprobando que los tres **siguen** (con cadena y sin ella); que el 400 del
  router no cuenta como petición inválida; y que el número del error se extrae
  sin inventarlo cuando no está.
- 7 unitarios de `limites-medidos.ts`, incluido que dos negativas seguidas no
  pueden ampliar un límite.
- 2 E2E con el 413 **literal de Groq** servido por el mock: que acaba habiendo
  respuesta, y que el 7000 que se guarda es el que dijo el proveedor.
- Verificado en rojo: con la polaridad vieja, las dos E2E fallan.

**Cuatro pruebas viejas se han reescrito, y hay que decirlo claro**: fijaban la
polaridad anterior («un modelo manual solo avanza en fallos pasajeros», «un 400
o un 404 NO»). No se han tocado para que pasen: la regla cambió a propósito y
ahora dicen la nueva, con el caso que sí para —petición inválida— explícito en
cada una. Una de ellas era mía, de ayer.

### Puerta

- ✓ lint · ✓ knip · ✓ tsc · ✓ build · ✓ **1 708** unitarios (1 694 antes) ·
  ✓ **205** E2E, suite completa dos veces
- ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin `standalone` y con el
  `.nft.json`

### Lo que sigue sin resolverse

- **Si la conversación no le cabe a NINGUNO de tus modelos**, no hay a dónde
  ir. Lo que tocaría entonces es recortar el contexto y reintentar —el modo
  ahorro y la ventana de contexto ya existen, pero nadie los aplica solo—.
  Queda pendiente y dicho.
- **El tope se estima con caracteres ÷ 4** para decidir a quién saltar. Es la
  misma regla del medidor de contexto y es aproximada; sirve para descartar lo
  que seguro no cabe, no para prometer que lo demás sí.

## v4.6.0 — Si no cabe, se recorta y se reintenta con el mismo modelo

Lo que quedó pendiente ayer y era lo siguiente que haría: cuando la
conversación no le cabe a ningún modelo, no hay a dónde saltar. Y saltar
tampoco era la mejor respuesta cuando el que no puede es justo el que quieres:
el problema no es el modelo, es que le estás mandando veintiún mil tokens de
historial para preguntarle «qué hacemos».

Ahora hace lo que haría cualquiera a mano: **quitar lo viejo y volver a
probar**, con el mismo modelo.

### Las reglas, y por qué cada una

- **La pregunta viva no se toca nunca.** Es lo único que acabas de escribir;
  recortarla sería contestar a otra cosa.
- **Se quitan turnos ENTEROS, de los más viejos.** Cortar un mensaje por la
  mitad deja al modelo leyendo una frase sin final y respondiendo a un
  fantasma.
- **Se dice qué se quitó.** Un recorte en silencio es la peor versión de esto:
  el modelo pierde el hilo, la respuesta sale rara y no hay forma de saber por
  qué. El aviso dice cuántos mensajes se fueron y que tu pregunta va entera.
- **Solo si el proveedor dijo su tope.** Sin número no hay a qué recortar, y
  ahí sí toca cambiar de modelo — que es el camino de la v4.5.0 y sigue.
- **Una sola vez por turno.** Reintentar en bucle contra un tope que no se
  conoce bien es gastar peticiones.
- **Con margen del 15 %.** La cuenta es caracteres ÷ 4, aproximada; apurar al
  límite exacto con una medida aproximada garantiza un segundo rechazo.
- **Si ni así cabe, se dice.** Cuando lo único que queda es la pregunta viva y
  sigue sin entrar, no hay recorte posible y hay que cambiar de modelo. Eso se
  cuenta distinto del apaño que funcionó: uno explica un arreglo, el otro un
  callejón.

### Pruebas

- 10 unitarios de `recorte-contexto.ts`: que quita los viejos y no la pregunta
  viva (ni siendo enorme), que respeta el margen, que solo quita turnos
  enteros, y que avisa distinto en cada caso.
- 2 E2E con el 413 **literal** de Groq servido por el mock, que ahora rechaza
  solo lo que de verdad no cabe: la misma petición, con menos historial, entra.
  Se comprueba que responde **el mismo modelo** (eso es el recorte, no un
  salto) y que el aviso sale.
- Verificado en rojo: sin el recorte, las dos fallan.

**Dos pruebas de ayer se han reescrito.** Comprobaban «413 → salta a otro
modelo» con un mensaje corto, y ya no aplica: ahora la app recorta primero. Se
han apuntado al caso que sigue siendo suyo —un 413 **sin números**, donde no
hay a qué recortar— y de paso comprueban algo mejor: que sin número del
proveedor **no se inventa un tope**, se guarda `null` y lo que se le pidió.

### Puerta

- ✓ lint · ✓ knip · ✓ tsc · ✓ build · ✓ **1 718** unitarios (1 708 antes) ·
  ✓ **207** E2E, suite completa dos veces
- ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin `standalone` y con el
  `.nft.json`

### Lo que sigue sin hacerse

- **Lo que se quita, se pierde.** No se resume: se corta. Un resumen del tramo
  viejo conservaría el hilo, pero cuesta otra llamada y hay que decidir con qué
  modelo se hace. Es la evolución natural de esto y no está.
- **El recorte no mira el prompt de sistema**, que viaja aparte y también ocupa
  (mapa del proyecto, notas, reglas, skills). Si el que no cabe es él, esto no
  ayuda: hay que apagar piezas en Ajustes.

---

## v4.7.0 — Cinco cosas que Prism ya sabía y no decía

Cuatro recomendaciones mías y un fallo que contó el usuario. Todas comparten
raíz: **la app ya tenía el dato medido y no lo enseñaba en ninguna parte**, o
lo tenía detrás de un interruptor apagado. No es código nuevo por gusto; es
sacar a la superficie lo que ya se estaba pagando por medir.

### 1. Los botones de la vista previa no hacían nada

Lo que contó el usuario: «en los preview los botones se tocan pero no ejecutan
función, si necesito entrar a ajustes para ver cómo quedó el diseño lo toco y
no entra».

El iframe de la vista previa corre con `sandbox="allow-scripts"` y **sin**
`allow-same-origin`, y eso no se toca: con `allow-same-origin` la página
generada sería del mismo origen que Prism y podría leer tus claves de API del
`localStorage`. Es la línea que sostiene «las claves solo en tu dispositivo».

El precio de esa línea es que el navegador prohíbe ahí dentro `localStorage`,
`sessionStorage` y las cookies, y **lanza `SecurityError` solo al tocarlas**.
Una página generada las toca en el primer clic —guardar la pestaña activa,
recordar un contador—, así que el manejador reventaba a mitad y el botón se
quedaba muerto. Sin error visible: el fallo ocurría dentro del iframe.

Ahora el puente de consola instala un almacenamiento **en memoria** antes de
que corra el código de la página, y avisa una vez de que lo que se guarde ahí
no persiste. Los botones funcionan; el aislamiento no se ha movido un
milímetro.

### 2. Lo que se recorta ya no se tira: se resume

La v4.6.0 recortaba el historial cuando no cabía, y su propio worklog decía qué
faltaba: «lo que se quita, se pierde». Faltaba porque cuesta otra llamada.

Ahora el tramo que se aparta viaja como **resumen**, hecho por el mismo modelo
que va a contestar (que ahora sí traga, porque solo se le manda ese tramo) y
marcado como resumen para que nadie lo confunda con algo que dijiste tú. Con
sus límites: no se resume lo que no llega a 1 200 caracteres —no compensa—, no
se resume un resumen, y si la llamada falla el recorte a secas ya funcionaba.

### 3. «¿Por qué me contestó esto?»

Prism medía casi todo y lo tenía **todo repartido**: un chip para el contexto,
un panel para el gasto, el failover en un aviso que desaparece a los seis
segundos y varias cosas en ningún sitio. Cuando una respuesta salía rara no
había forma de reconstruir qué había pasado.

Cada respuesta lleva ahora su expediente, en un botón «por qué» del pie:

- qué modelos fallaron **antes**, con su código y qué se decidió con cada uno;
- qué contexto viajó y cuántos caracteres tenía el prompt de sistema;
- cuántos mensajes se apartaron por tamaño y si se resumieron;
- los tokens que dijo **el proveedor** (no nuestra estimación);
- el coste, con la fecha de los precios usados.

Con la regla de siempre: lo que no se sabe **no sale**, y el importe solo
aparece si están sus dos mitades —tokens del proveedor × precio fechado—. Si
falta una, se dice cuál falta en vez del número.

Un detalle que costó encontrar: la lista de intentos fallidos vivía en una
variable del bucle, y un failover de proveedor **no es una vuelta más del
bucle** —borra la burbuja y vuelve a llamar a la generación con otra cadena—.
El expediente de la respuesta buena decía «respondió el primero» justo cuando
habían fallado tres. Ahora vive fuera del bucle y se vacía al empezar un turno
de verdad.

### 4. Lo que ya sabíamos del modelo, dicho ANTES de elegirlo

Lo que contó el usuario: «hay modelos que me los da como que están buenos y al
final no funcionan». Y era literalmente cierto: el techo de entrada de cada
modelo se medía la primera vez que rechazaba por tamaño, se guardaba, se usaba
para no volver a elegirlo… y no se enseñaba en ningún sitio. El selector los
pintaba a todos iguales.

`perfil-modelo.ts` junta las tres memorias que ya existían —modelos que el
proveedor no reconoce, techos medidos, historial de aciertos y tiempos— en una
ficha por modelo. Sale en dos sitios: una marca en el selector («techo»,
«falla») con el detalle al pasar por encima, y un bloque «Modelos con pegas
medidas» en el Panel → Uso, lo peor primero.

Con dos frenos contra afirmar de más: con menos de cinco llamadas **no se dice
un porcentaje** (dos intentos y un fallo darían «50 % fiable», que no significa
nada), y una medición de techo caduca a las seis horas —muchos de esos topes
son **por minuto**, y marcar para siempre por un pico de un martes sería
apartar un modelo que hoy iría bien—.

### 5. El código se ejecuta antes de enseñártelo, siempre

Esto ya estaba hecho… dentro del modo agente. Y el modo agente **viene
apagado**. O sea que el caso más común —abres la app, escribes «hazme una
página», te llega el HTML— salía sin ejecutarse ni una vez, y el fallo lo
descubrías tú al abrirlo. La comprobación estaba escrita, probada y puesta
detrás de un interruptor que casi nadie toca.

Ahora se ejecuta siempre que la respuesta traiga algo abrible, con modo agente
o sin él: se carga la página, se pulsan sus botones, y si algo revienta se le
devuelven los errores al modelo (dos rondas como mucho). Ejecutar es local y
gratis; solo cuesta una llamada si de verdad hay que corregir.

### La regla de la casa, escrita y comprobada

`docs/DATOS-QUE-ENVEJECEN.md`: **todo dato que envejece necesita fecha, fuente
y un `npm run` que lo regenere.** Sale de cuatro fallos de estos días con la
misma raíz —modelos retirados en el catálogo, tarifas a mano, un sello de
«verificado» compartido por catorce ofertas, ids copiados dentro de una
prueba—. Ninguno fue un error de programación: los cuatro son un dato que
cambia solo guardado en un sitio que no cambia solo.

Y como un documento que dice eso y nadie comprueba es exactamente el tipo de
dato que la regla prohíbe, lleva su prueba: que los módulos generados exportan
fecha ISO y fuente `https://`, que existe el `npm run` que los regenera, y que
las ofertas llevan sello **propio** y admiten `null` para «nadie lo ha
comprobado».

### Pruebas

- 35 unitarios nuevos: `ficha-respuesta` (9), `perfil-modelo` (12),
  `resumen-recorte` (10), `datos-que-envejecen` (4).
- 7 E2E nuevos: el expediente con un failover real de por medio; que el importe
  nunca sale sin la fecha de sus precios; la marca del techo en el selector y
  que **caduca**; el bloque del Panel → Uso; que el código se ejecuta y se
  corrige **con el modo agente apagado**; los botones de la vista previa.
- Verificados en rojo los cinco que prueban algo nuevo: sin el cambio, fallan.

### Puerta

- ✓ lint · ✓ knip · ✓ tsc · ✓ build · ✓ **1 753** unitarios (1 718 antes) ·
  ✓ **214** E2E, suite completa dos veces
- ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin `standalone` y con el
  `.nft.json`

### Lo que sigue sin hacerse

- **El expediente no se puede copiar ni exportar.** Se lee y ya. Para pegarlo
  en un issue habría que transcribirlo a mano.
- **El perfil por modelo no cambia a quién elige Auto.** Auto ya evita lo roto
  y lo que no cabe, pero «este modelo va mejor en webs que en código» se
  enseña y no se usa para decidir. Es lo siguiente natural.
- **El almacenamiento simulado de la vista previa no persiste.** Se dice en un
  aviso, pero una página generada que guarda datos «funciona» hasta que
  recargas. Persistirlo de verdad exige un puente al padre, y eso es superficie
  nueva entre el iframe y la app: no se ha hecho a la ligera.

---

## v4.8.0 — Un kit de efectos propio, atado a la dirección visual

La pregunta era: «¿podemos añadir una librería de efectos para hacer diseños
más pro en las páginas?». Sí, y se nota. Pero **no por CDN**, y no como
catálogo suelto.

### Por qué no un CDN

La página generada acaba en tres sitios donde una dependencia de terceros es un
problema distinto:

1. **La vista previa**, un iframe con `srcdoc` y sin `allow-same-origin`. Un
   `<script src="https://cdn…">` carga, sí — hasta el día que no. Y entonces la
   página se ve rota **sin decir por qué**: Prism no sabe distinguir «tu código
   falla» de «no cargó la librería», así que el agente intentaría «arreglar»
   código que está perfecto.
2. **El ZIP que te descargas**, que tiene que abrirse con doble clic y ya.
3. **Tu GitHub Pages**, donde esa dependencia pasa a ser tuya para siempre.

El kit son dos archivos de ~5,7 KB y ~6 KB que **viajan dentro del proyecto**.
Sin red, sin versiones que se rompen, sin licencias que explicar. Lo que ves en
la vista previa es exactamente lo que se publica.

### Por qué atados a la dirección visual

Un catálogo de efectos suelto produce el mismo AI-slop, solo que con brillo:
todas las páginas con el mismo desvanecido al hacer scroll. Cada una de las
cinco direcciones declara ahora **los suyos y los que tiene prohibidos**, y la
lista negra importa tanto como la otra — sin ella el modelo mete el fade suave
en todas partes, porque es lo que ha visto un millón de veces. Un neobrutalismo
con desvanecidos deja de ser neobrutalismo; un editorial con inclinación 3D es
una web de plantilla.

- **editorial** — reveal, stagger, split, underline, parallax, noise. Prohibido:
  tilt, spotlight, sheen, float, mesh, marquee.
- **minimal** — reveal, stagger, count, underline, float. Prohibido: marquee,
  noise, tilt, spotlight, sheen, pop.
- **tech** — reveal, count, spotlight, sheen, grid, tilt. Prohibido: float,
  blob, noise, split, marquee.
- **brutalista** — pop (corte seco, sin desvanecido), marquee, tilt, sheen,
  split. Prohibido: reveal, float, blob, spotlight, mesh, noise.
- **calido** — reveal, stagger, float, blob, noise, parallax. Prohibido:
  marquee, grid, spotlight, sheen, pop, tilt.

Un unitario comprueba que **ninguna dirección repite la receta de otra**: si un
día todas usan lo mismo, el kit se ha convertido en otra plantilla.

### La regla de oro: todo se ve sin JavaScript

Los efectos **quitan** un estado, no lo ponen. El CSS solo esconde bajo la clase
`.fx-on`, que pone el script **después** de comprobar que puede animar. Sin JS,
sin `IntersectionObserver` o con `prefers-reduced-motion`, no se esconde nada y
la página se ve entera. Hay un unitario que recorre el CSS regla a regla —cada
selector por separado, no el bloque entero— y falla si aparece un `opacity: 0`
fuera de esa guarda.

Y una red de seguridad: si el observer no llega a disparar (un iframe que no se
desplaza, una pestaña en segundo plano), a los 1,2 s se revela todo. Un efecto
que se pierde es una molestia; contenido invisible es un fallo.

### Lo que casi rompe esto, y no se vio venir

El QA visual y el barrido de botones **ignoran a propósito lo que tiene
`opacity: 0`** —no se mide lo que no se ve—, y una sección que aún no ha
entrado por scroll está exactamente así. Sin tocar nada, una página con efectos
se habría revisado solo en el primer pantallazo y el informe habría dicho «sin
problemas» de lo que nunca miró: el peor resultado posible, porque parece una
comprobación y no lo es.

Así que antes de medir se **asienta** la página: todos los `[data-fx]` marcados
como ya entrados y las transiciones apagadas (`html.fx-medir`) para que el
estilo calculado sea el final **en ese mismo instante** — con la transición
corriendo, medir justo después seguiría leyendo opacidad 0.

Y se deshace al terminar. Esto salió de la propia prueba: la primera versión
asentaba y no restauraba, así que el medidor le revelaba los efectos al usuario
y en la vista previa no se veía ni una animación. **Medir no puede cambiar lo
medido.**

### El modelo no escribe el kit

Solo lo enlaza (`<link href="prism-fx.css">`, `<script src="prism-fx.js">`) y
Prism añade los dos archivos al proyecto por su cuenta, en el mismo embudo por
el que pasan la vista previa, el ZIP y la revisión automática — y también al
Sandbox cuando lo escribe el agente. Escribirlo costaría unos 2.500 tokens de
salida **por respuesta**, saldría distinto cada vez y con erratas.

Nunca pisa un archivo que ya venga: si el modelo escribió el suyo, o tú lo
editaste en el Sandbox, manda el tuyo.

### Pruebas

- 22 unitarios de `efectos.ts`: que lo empaquetado es idéntico a `assets/`, que
  no hay ni un `url(https:` ni un `fetch(`, que el JS no toca almacenamiento
  (en la vista previa lanzaría `SecurityError`), que nada se esconde sin
  `.fx-on`, que cada dirección tiene receta propia y sin contradicciones, y que
  el bloque del prompt no engorda por encima de 1.200 caracteres.
- 3 E2E: que Prism añade los dos archivos (medido en el menú de descarga, que
  cuenta los archivos **reales** — el nombre del archivo sale en el chat de
  todas formas y comprobar eso no probaba nada), que sin JS el titular se ve, y
  que lo que entra por scroll acaba visible aunque nadie haga scroll.
- Verificados en rojo los tres. El de la red de seguridad **no lo estaba** al
  principio: pasaba igual con la red quitada, porque quien revelaba era el
  asentador del QA. Se vio al restaurar la página después de medir, que es lo
  que había que hacer de todas formas.

### Puerta

- ✓ lint · ✓ knip · ✓ tsc · ✓ build · ✓ **1 775** unitarios (1 753 antes) ·
  ✓ **217** E2E, suite completa dos veces
- ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin `standalone` y con el
  `.nft.json`

### Lo que sigue sin hacerse

- **Nadie comprueba que el modelo respeta la lista negra.** El prompt dice qué
  está prohibido en cada dirección, y eso es todo: si un modelo mete `float` en
  un neobrutalismo, la página se publica igual. Se podría revisar el HTML
  entregado contra la lista y devolvérselo, como ya se hace con los errores de
  consola.
- **El kit no se ve en ninguna parte antes de usarlo.** No hay una página de
  muestra donde mirar los diecisiete efectos y decidir. Hoy se descubren
  leyendo el `DESIGN.md` del proyecto.
- **Los efectos no entran en el medidor del prompt.** El bloque suma unos 400
  caracteres en cada generación de UI y se paga en cada llamada; está acotado y
  probado, pero no aparece desglosado en el HUD de contexto.

---

## v4.9.0 — El push a GitHub estaba roto, y lo genérico ahora se mide

Dos encargos: «el apartado de hacer push a GitHub no funciona» y «que se
puedan crear webs profesionales y no genéricas».

## 1. El push a GitHub

Tres fallos, y el peor no era que fallara: era que **decía que había ido
bien**.

### La rama estaba escrita a mano

`ghGetHead` preguntaba por `refs/heads/main` y la subida movía `refs/heads/
main`. Siempre. En un repo cuya rama por defecto es `master` —o cualquiera que
la haya cambiado— pasaba esto:

1. la rama `main` no existe → se toma por «repo vacío»;
2. se crea un commit **sin padre**, huérfano, que no cuelga de nada;
3. se intenta crear `refs/heads/main`;
4. si `main` ya existía, GitHub devuelve 422… **y ese 422 se ignoraba**;
5. la app decía «¡Completado!» y en GitHub no había cambiado nada.

Ahora se pregunta por el repo y se usa **su** `default_branch`. Y el 422 ya no
se traga: si la rama apareció mientras subíamos, se mueve; si no se puede, se
dice.

### Un error de red podía borrarte el repo

`ghGetHead` devolvía `treeSha: ""` cuando no lograba leer el commit. Con el
árbol vacío, el commit sale **sin `base_tree`** — y eso no es «subir unos
archivos», es dejar el repo con exactamente los archivos del lote y borrar
todos los demás. Silencioso. Ahora eso para la subida con un mensaje que dice
por qué se para.

### «Completado» quería decir «no saltó ninguna excepción»

Al terminar se comprueba que la rama apunta **de verdad** al commit que
acabamos de crear. Si no, es un error, no un éxito.

Además: los mensajes de GitHub ahora traen el detalle de `errors[]` (sin él un
422 es indescifrable) y una pista de qué hacer según el código —401 reconecta,
403 falta el alcance «repo», 404 el token no ve ese repo, 5xx es cosa de
GitHub—. Y el motivo del fallo se queda **escrito en el diálogo**, no en un
aviso flotante que se va a los seis segundos con el único dato que servía.

### Por qué sobrevivió tanto

Porque toda la subida era código sin una sola prueba: hacía falta una cuenta de
GitHub de verdad para ejecutarla. Ahora hay un GitHub de mentira que se
comporta como el bueno en lo que importa (una rama por defecto que puede no
llamarse main, el `base_tree` que conserva lo que había, y que solo cuenta como
publicado lo que la rama apunta). Los tres fallos se han verificado en rojo
contra él.

## 2. Webs que no parezcan hechas por una IA

El proyecto ya tenía direcciones de diseño con paleta, tipografía y
composición, y una checklist anti-slop de cinco puntos. El problema: **esa
checklist se la autoevaluaba el modelo**. Le pedíamos que se pusiera nota y la
nota era siempre buena. El mismo fallo sistémico de siempre — un dato que nadie
comprueba.

### Ahora se mide en la página pintada

`generico.ts` mide, sobre el DOM ya renderizado, las señas de identidad de una
página de generador. Solo entra lo que se puede medir **y** admite una
corrección concreta: «le falta personalidad» no es un hallazgo; «catorce
elementos comparten exactamente el mismo redondeo» sí.

- **relleno** — Lorem ipsum, «Característica 1», «Tu texto aquí», citado tal cual.
- **imagen-relleno** — placehold.co, unsplash aleatorio y compañía.
- **sin-escala** — menos de cuatro tamaños de letra, o el titular a menos del doble del cuerpo.
- **sin-pareja** / **fuente-por-defecto** — titular y cuerpo con la misma fuente, o la del navegador.
- **tarjetas-iguales** — filas de 3+ hermanos clonados en alto, ancho y forma.
- **radio-uniforme** — ocho o más elementos con el mismo redondeo exacto.
- **emoji-titulares** — dos o más titulares que empiezan por emoji.
- **todo-centrado** y **hero-centrado** — con su salvedad dicha: si la dirección lo pide, que lo defienda y lo deje.

Los hallazgos vuelven al modelo por el **mismo camino que los errores de
consola**, que es el bucle que ya funcionaba, con el qué y el cómo arreglarlo.
Y el mensaje le deja defender una decisión en vez de obedecer a ciegas.

Dos frenos para que el medidor no se vuelva ruido: por debajo de 25 elementos
no se juzga nada (una página corta no es genérica, es corta), y una página sin
señas no gasta ni una vuelta de corrección.

### Y de paso: el QA visual nunca llegaba al modelo

La revisión automática llamaba a `runProjectInMemory(files, { botones: true })`
— **sin `qa: true`**. El medidor visual se inyectaba en la página, medía y
mandaba su resultado… y aquí no se pedía. Todo lo que medía (scroll horizontal,
texto por debajo de 12 px, contraste) se tiraba. Ahora se pide.

### Las reglas de contenido, en el prompt

Una página genérica se reconoce antes por lo que dice que por cómo se ve, y eso
no lo arregla ninguna paleta. Seis reglas nuevas en el bloque de dirección
—cero relleno, titular que afirma, escala medible, pareja tipográfica real,
nada de imágenes prestadas, composición con un protagonista— y encabezadas por
lo que las hace distintas: **esto se mide después en la página, no es un
consejo.**

### Pruebas

- 10 unitarios del push contra el GitHub de mentira: repo nuevo, repo con
  `master`, que no se borra lo que había, que para si no puede leer el árbol
  base, que no canta victoria si la rama no acabó apuntando a nuestro commit,
  varios lotes encadenados y el 422 que no es «ya existe».
- 20 unitarios del medidor de genérico: cada seña por separado, que una página
  bien hecha no genera ninguna, que una corta no se juzga, y que cada hallazgo
  trae QUÉ HACER.
- 2 E2E con la página de manual de un generador: que Prism la mide, se la
  devuelve citando el Lorem ipsum y las tarjetas clonadas, y que termina
  pulida. Y que una página que ya está bien **no se toca**.
- Verificados en rojo los seis que prueban algo nuevo.

### Puerta

- ✓ lint · ✓ knip · ✓ tsc · ✓ build · ✓ **1 806** unitarios (1 776 antes) ·
  ✓ **219** E2E, suite completa dos veces
- ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin `standalone` y con el
  `.nft.json`

### Lo que sigue sin hacerse

- **No he podido reproducir el fallo del push contra GitHub de verdad.** Los
  tres fallos son demostrables y están arreglados y probados contra un GitHub
  simulado, pero si lo que te falla es la CONEXIÓN (el botón «Conectar») y no
  la subida, esto no lo arregla: hay que ver el mensaje que sale.
- **El medidor no sabe de composición.** Mide tipografía, relleno, clonado y
  redondeo. No sabe si la retícula tiene ritmo ni si el espacio está pensado —
  eso sigue dependiendo del modelo.
- **`pushFilesToRepo` sigue haciendo un commit por archivo.** Funciona (usa la
  Contents API, que respeta la rama por defecto), pero veinte archivos son
  veinte commits. Debería pasar por la misma Git Data API que la subida de
  carpetas.

---

## v4.10.0 — Scrollytelling, motor 3D propio, sexta dirección y editar tocando la vista previa

La pregunta del usuario fue directa: *«sugerencias… webs como Open Design o
Claude Design, sitios 3D con animaciones»*. La respuesta, en la conversación
anterior, fue una lista de lo que valía la pena y lo que no. Esta versión es
esa lista, hecha — más una función que pidió aparte: tocar un texto de la
vista previa y editarlo ahí mismo.

### El kit de efectos crece: scrollytelling

Dos efectos nuevos en `prism-fx`, sin cambiar el criterio de siempre (local,
sin CDN, todo se ve sin JavaScript):

- **`pin`** — una sección alta se ancla mientras se hace scroll y dice su
  avance (`--fx-p`, de 0 a 1) en una variable CSS. Con `[data-fx-step]` en los
  hijos, los va revelando en orden: es el mecanismo detrás de un reportaje
  largo o una demo contada paso a paso.
- **`horizontal`** — lo mismo pero deslizando en horizontal. El
  `overflow:hidden` del carril es lo que evita que esto cuente como scroll
  horizontal de la página: sin él, el propio QA visual lo marcaría como fallo.

Sin animación (o sin JavaScript), las dos se apagan de verdad: la altura de
300vh se anula (`height: auto`) para que nadie desplace cientos de píxeles de
página vacía por un efecto que nunca se activó.

### Cursor propio, texto que se revela con caracteres al azar, transición nativa

- **`cursor`** — reemplaza el del sistema solo cuando el motor está activo
  (la regla que lo oculta vive detrás de `.fx-on`, igual que todo lo demás);
  con `data-fx-cursor="Ver"` se agranda con esa etiqueta al pasar por encima.
- **`scramble`** — un titular se revela con letras al azar antes de asentarse
  en el texto real. No necesita esconder nada con CSS: el texto ya es visible,
  es su contenido el que cambia.
- **`window.prismFx.transition()`** — envuelve `document.startViewTransition`
  con respaldo si el navegador no lo soporta. Va siempre disponible, incluso
  con menos movimiento permitido (ahí Chrome ya desactiva la animación solo).

### Un motor 3D propio — no Three.js recortado

`prism-3d.js`: WebGL2 crudo, sin librería, ~12 KB. Cámara en perspectiva
(matriz 4×4 verificada a mano: near→-1, far→1 en NDC, comprobado con números
reales antes de escribir una línea de shader), un campo de partículas que
reacciona al cursor, un globo de líneas que gira, y un shader de fondo con un
blob de gradiente fluido. El color de la escena sale del CSS `color` del
propio `<canvas>` — el mismo convenio que ya usaban `fx-mesh` y `fx-noise`.

Tres frenos, en este orden:

1. **Sin motion, no dibuja.** Igual que el resto del kit.
2. **Sin WebGL2, se queda vacío.** Se ve lo que haya detrás — un gradiente
   CSS de respaldo, que es justo lo que dice el catálogo que hay que poner.
3. **En un equipo de gama baja, tampoco.** `navigator.deviceMemory < 4` o
   `hardwareConcurrency < 4` bastan para no dibujar. Una escena que hace ir un
   móvil a 12 fps no es «más pro»: es peor que no tenerla.

`window.__prism3dActivo` es la única señal que expone el motor, y solo se
pone a `true` DESPUÉS de comprobar el contexto y que el shader compiló —
nunca antes, o mentiría. Es lo que usan las pruebas para saber si decidió
dibujar sin tener que leer píxeles.

**Lo que no se pudo verificar en E2E, y por qué (dicho aquí en vez de
callado):** la detección de gama baja SÍ está probada — en el unitario, que
es determinista. En Playwright no: para simularla hay que sobrescribir
`navigator.hardwareConcurrency` justo cuando el iframe de la vista previa
recarga su `srcdoc` — y ese recargado ocurre dos veces mientras el modelo
escribe (una vacío, luego con el HTML final). Playwright pierde la
sobrescritura en la segunda recarga una vez de cada dos: es una carrera del
arnés de pruebas con `srcdoc`, confirmada leyendo `hardwareConcurrency` en el
punto exacto donde se decide (si la sobrescritura llega, el motor SÍ se
calla — se vio pasar en varias ejecuciones). Forzarlo a base de reintentos
habría escondido la causa en vez de decirla.

### La sexta dirección: Estudio experimental

Las cinco direcciones de antes no cambian. Se añade una sexta, la única con
permiso de usar el motor 3D, el cursor propio y el scroll narrativo juntos:
fondo casi negro, acento violeta-cian, tipografía `Unbounded` + `Manrope`,
composición de una sola pieza dominante por pantalla en vez del grid de tres
columnas. `tech` puede usar el campo de partículas —encaja con un dashboard—,
pero el globo de líneas 3D y el shader de fondo se quedan para experimental:
son los que de verdad cambian el tono de una página.

Detectada por palabra clave (agencia, premiada, awwwards, inmersivo,
experimental…) igual que las otras cinco; sin dirección clara, entra en la
misma rotación para no repetirse entre proyectos.

### Otro fallo que se destapó de paso: el QA nunca llegaba al modelo también aquí

Al escribir la prueba del scroll horizontal se confirmó lo mismo que en
v4.9.0 con `runProjectInMemory`: el CSS solo esconde `opacity:0` bajo `.fx-on`
(un unitario recorre el CSS regla a regla comprobándolo), y una regla nueva
que se saltara esa guarda se habría colado igual sin la prueba — pasó de
verdad con `.fx-cursor-label`, que en el primer intento llevaba `opacity: 0`
sin el gateo. El unitario lo cazó antes de llegar a ningún E2E.

### Editar tocando la vista previa

Lo que pidió el usuario aparte: un botón «Editar» en la barra de la vista
previa. Al activarlo, el texto que se pasa por encima se marca; al tocarlo,
se vuelve editable; Enter confirma, Escape descarta.

El cambio **no** se guarda en el DOM del iframe —se pierde en cuanto se
repinta—, se localiza en el CÓDIGO de la respuesta y se persiste ahí: por eso
sigue estando cuando se descarga el ZIP o se sube a GitHub.

Dos reglas de seguridad, no solo de comportamiento:

- **Solo hojas del árbol.** El piloto únicamente deja editables los elementos
  SIN hijos —un `<h1>`, un botón con una palabra—. Nunca un contenedor con más
  elementos dentro: tocar su `textContent` habría borrado lo que hay adentro.
- **Nunca se rellena a ciegas.** Localizar el texto en el código es buscar una
  cadena. Si aparece más de una vez —un botón «Ver más» repetido tres
  veces—, se rechaza con el motivo («aparece 3 veces: edítalo desde el
  Sandbox para elegir cuál») en vez de sustituir la primera por suerte. Si no
  aparece —el HTML fuente puede llevar entidades que el navegador ya
  decodificó—, se prueba también la forma escapada antes de rendirse.

El motivo del rechazo se queda escrito en pantalla (`toast.error`), nunca se
traga en silencio.

### Pruebas

- 22 unitarios de `efectos.ts` ampliados (nuevos ids, tercer archivo,
  dirección experimental) + 13 de `editar-preview.ts`.
- 9 E2E con mocks nuevos (`mock-3d`, `mock-scroll`): que Prism añade
  `prism-3d.js` solo cuando se enlaza, que la escena arranca con movimiento
  permitido y se calla sin él, que el avance del `pin` sigue al scroll de
  verdad y revela los pasos en orden, que el carril horizontal se desplaza sin
  generar scroll real de página.
- 2 E2E de la edición en preview: tocar el titular lo cambia y el cambio
  queda en el código (comprobado en la pestaña «Ver código», no solo en el
  DOM); un texto duplicado se rechaza con el motivo.
- Verificados en rojo: los tres de scrollytelling, el de que la escena 3D no
  arranca sin motion, y los dos de edición.

### Puerta

- ✓ lint · ✓ knip · ✓ tsc · ✓ build · ✓ **1 825** unitarios (1 806 antes) ·
  ✓ **228** E2E, suite completa dos veces
- ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin `standalone` y con el
  `.nft.json`

### Lo que sigue sin hacerse

- **Nadie comprueba que el modelo use el motor 3D solo en «experimental».**
  Igual que con la lista negra de efectos 2D: el prompt lo prohíbe en las
  otras cinco direcciones, pero si un modelo lo mete igual, la página se
  publica tal cual.
- **La edición no admite deshacer.** Un cambio aplicado se puede corregir
  volviendo a tocar el texto, pero no hay un botón «deshacer la última
  edición» — el checkpoint automático del agente no cubre esto porque no pasó
  por una generación.
- **Solo se edita texto de la página HTML principal**, nunca de un CSS o JS
  hermano ni de un atributo (un `alt`, un `title`). Es una limitación
  deliberada de la primera versión, no un descuido: ampliar el alcance sin
  ampliar el riesgo de una sustitución equivocada necesita más que una tarde.

## v4.10.1 — Dogfooding: un `pageerror` de verdad que ningún test veía

Se pidió probar la app usando la app, no la batería de tests, y decir qué
falta. Con 1 826 unitarios y 227 E2E en verde no salió nada — pero generando
una página DE VERDAD (proveedor propio, sin mocks aislados) sí: la vista
previa soltaba un `pageerror` real, `Failed to read the 'localStorage'
property from 'Window': The document is sandboxed and lacks the
'allow-same-origin' flag`, con el `mock-3d` como disparador.

### La causa

`injectConsoleBridge` — el puente que sustituye `localStorage` por uno de
mentira dentro del iframe sandboxed, para que la página generada no se
muera al tocarlo — se metía justo ANTES de `</head>`. El patrón más común en
una web generada (comprobado en la práctica, no en teoría): un script en
`<head>`, ANTES de cualquier otra cosa, que lee el tema guardado antes del
primer pintado para no dar el flash del tema equivocado. Ese script vive
antes en el documento que el puente, así que corría primero, tocaba el
`localStorage` real del iframe y reventaba — exactamente el fallo que el
propio puente existe para evitar, solo que llegaba tarde.

Y pasaba en LAS DOS vistas previas a la vez: la visible (donde se ve) y la
oculta que `sandbox-runner.ts` monta para «ejecutar el código antes de
enseñarlo» (v4.7.0) — las dos construyen su HTML con la misma función.

Arreglo: el puente se mete al ABRIR `<head>`, no antes de cerrarlo. Ningún
script del proyecto puede ir por delante.

### El hueco que esto destapa en la propia batería de pruebas

Ni un solo test, de los 1 826 + 227 que había, escuchaba
`page.on('pageerror')` durante una generación real: los unitarios de
`sandbox-runner.ts` corren en Node (sin `document`, no hay forma de montar
el iframe de verdad) y los E2E comprobaban resultados concretos del DOM sin
una aserción general de «cero errores sin capturar». Es un punto ciego real
del arnés de pruebas, no solo de este fallo — cubierto ahora con
`tests/e2e/tema-en-head.spec.ts`, que sí escucha `pageerror` de principio a
fin de una generación con el mock `mock-tema-en-head` (un `<head>` con
detección de tema, igual que el caso real).

### Lo segundo que salió tocando la vista previa a mano

Editar tocando el texto (v4.10.0) solo deja editables las hojas del árbol —
documentado ya en su propio worklog. Un `<h1>El café,<em>despacio.</em></h1>`
deja tocar «despacio.» (hoja) pero no «El café,» (texto suelto junto a otro
hijo), sin ninguna señal visual de por qué uno sí y el otro no. Es la
consecuencia directa y esperada de esa regla, no un fallo nuevo: se deja
anotado aquí como ejemplo concreto en vez de construir edición parcial de
texto mixto sin que nadie lo haya pedido — es una pieza bastante más grande
(hay que aislar el nodo de texto con un `Range`, dibujar su resaltado propio
al pasar el ratón, envolver y desenvolver un `<span>` temporal) y con más
riesgo de estropear algo que ya funciona bien para el caso normal.

### Pruebas

- 4 unitarios nuevos en `sandbox.test.ts` para el orden de inserción del
  puente (con `<head>`, con solo `<html>`, con solo `<body>`, idempotencia)
  + 1 sobre `buildRunHtml` que comprueba la posición real del puente frente
  a un script del proyecto.
- 1 E2E (`tema-en-head.spec.ts`) con un mock nuevo (`mock-tema-en-head`) que
  reproduce el patrón exacto que salió en el dogfooding.
- Verificados en rojo los cinco: revirtiendo el orden de inserción, el
  unitario de `buildRunHtml` fallaba (84 antes que 20) y el E2E reproducía
  el `pageerror` real DOS veces (la vista visible y la oculta).

### Puerta

- ✓ lint · ✓ knip · ✓ tsc · ✓ build · ✓ **1 831** unitarios (1 826 antes) ·
  ✓ **228** E2E (227 antes), suite completa
- ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin `standalone` y con el
  `.nft.json`

### Lo que sigue sin hacerse

- **La edición de texto mixto** (texto suelto junto a otros elementos)
  sigue sin poder tocarse, por diseño — ver arriba.
- **El punto ciego de `pageerror` sigue abierto para el resto de la app.**
  Este test cubre el caso encontrado; no hay una aserción genérica de «cero
  `pageerror`» que corra en todos los E2E que generan una página de verdad.

## v4.10.2 — El texto suelto también se puede tocar

Se pidió construir lo que la v4.10.1 dejó como límite documentado: hacer
editable un nodo de texto que vive SUELTO junto a otros elementos dentro del
mismo contenedor —`<h1>El café,<em>despacio.</em></h1>` dejaba tocar
«despacio.» (hoja) pero nunca «El café,», sin ninguna pista de por qué.

### Cómo se hizo sin tocar la regla de «solo hojas»

La regla sigue en pie: nunca se vuelve editable un CONTENEDOR completo —eso
seguiría borrando lo que hay dentro. Lo que cambia es que ahora el piloto
también localiza el nodo de texto EXACTO bajo el cursor:

- **`caretRangeFromPoint`/`caretPositionFromPoint`** (con su alternativa
  estándar) dicen qué nodo hay en un punto concreto de la pantalla — hacía
  falta, porque un nodo de texto no recibe sus propios eventos de ratón: el
  `target` de un clic sobre «El café,» es el `<h1>` entero, igual que si se
  hubiera tocado «despacio.».
- **Antes de tocar nada**, pasar el ratón por encima ya deja una marca — una
  caja superpuesta (`position:fixed`, calculada con `Range.getClientRects()`)
  en vez de envolver el nodo en cada `mousemove`, que habría movido el
  layout constantemente.
- **Al tocarlo**, el nodo de texto se envuelve en un `<span>` de usar y
  tirar: se edita exactamente igual que una hoja de verdad (mismo
  `contentEditable`, mismo Enter/Escape). El `<h1>` y el `<em>` de al lado
  nunca se tocan.
- **Al terminar** —se guarde o se cancele— el `<span>` se deshace: el nodo
  de texto vuelve a quedar suelto tal cual estaba. Si quedara colgado, el
  próximo QA vería una etiqueta que el modelo nunca escribió, y la próxima
  edición no encontraría el texto en el código fuente al buscarlo.

La localización del cambio en el CÓDIGO fuente (`aplicarEdicionTexto`) no
cambió ni un carácter: el mensaje que sale del iframe es el mismo
`{original, nuevo}` de siempre, venga de una hoja real o de un nodo de texto
recién envuelto.

### Pruebas

- 2 unitarios nuevos en `editar-preview.test.ts`: que el piloto detecta el
  nodo de texto por separado (sin volver editable el contenedor) y que el
  `<span>` desechable siempre se deshace.
- 2 E2E nuevos (`editar-texto-mixto.spec.ts`, mock `mock-texto-mixto`): tocar
  el texto suelto lo marca al pasar por encima, lo edita sin tocar al `<em>`
  vecino y el cambio queda en el código; la hoja de al lado se sigue editando
  igual que siempre, en la MISMA página.
- Verificados en rojo revirtiendo `editar-preview.ts`: sin el cambio, el
  primer E2E fallaba ya en la marca de hover (nunca aparecía), antes incluso
  de intentar el clic.

### Puerta

- ✓ lint · ✓ knip · ✓ tsc · ✓ build · ✓ **1 833** unitarios (1 831 antes) ·
  ✓ **230** E2E (228 antes), suite completa
- ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin `standalone` y con el
  `.nft.json`

## v4.10.3 — Tres cosas que salieron de usar la app: revisadas

Tres quejas del uso real, revisadas una por una antes de tocar nada — dos
eran fallos de verdad, la tercera era una instrucción fija que chocaba en
silencio con lo que se pedía.

### 1. La página seguía «genérica» y Prism no lo decía

El bucle de auto-revisión (consola → botones → genérico) comparte un tope de
`MAX_REVISIONES = 2` entre las tres cosas. El fallo: en el último intento
permitido, la condición que decidía si se comprobaba el resultado
(`revisiones < MAX_REVISIONES`) ya era falsa, así que ese bloque entero se
saltaba — la respuesta del último intento de corrección NUNCA se llegaba a
mirar. Si seguía genérica, o con un botón roto, Prism se quedaba callado: el
toast de «puliéndola sola (2 de 2)» y después nada, como si hubiera
terminado bien.

Ahora el resultado SIEMPRE se comprueba; lo único que cambia con el
presupuesto agotado es que ya no se relanza más, solo se avisa —
`avisoIntentosAgotados()`, uno por cada camino (consola en
`auto-revision.ts`, botones en `prueba-botones.ts`, genérico en
`generico.ts`) — nombrando lo que SIGUE sin arreglar, nunca un «algo falló»
genérico.

### 2. El código ya no se vuelca crudo en el chat

`proyectoDeLaRespuesta` (la misma función que ya reconocía un proyecto real
para el bucle de auto-revisión) resulta que también funciona con la cerca de
código todavía SIN CERRAR — así que sirve igual mientras se está escribiendo.

- **Mientras escribe**: el chat enseña el texto de antes de la cerca (el
  «aquí tienes tu página») y un aviso de trabajo — nunca el HTML a medio
  escribir creciendo token a token. La vista previa en vivo, al lado, es
  donde se ve crecer la página de verdad.
- **Terminado**: el bloque de código nace COLAPSADO con un botón «Ver
  código» arriba de la cabecera — sigue estando entero (se puede copiar, se
  sigue contando para «Mostrar todo»), solo que no ocupa la pantalla por
  defecto. Un fragmento corto de ejemplo (por debajo de 400 caracteres) se
  sigue viendo entero como siempre: la regla es solo para el proyecto
  volcado entero.

### 3. «Un proyecto para un repo» entregaba un solo HTML

No era un fallo: la skill integrada «Desarrollador web experto» manda
SIEMPRE un único archivo autónomo, sin excepción — a propósito, para que la
vista previa en vivo funcione sin fricción en el caso normal. El choque real
es que no había excepción para cuando se pedía explícitamente lo contrario.

`multi-archivo.ts` detecta la intención (proyecto, repo, repositorio, varios
archivos, estructura de carpetas…) y AMPLÍA la skill solo en ese caso:
`index.html` + `styles.css` + `app.js` separados y enlazados de verdad, en
vez de todo inline. El resto de encargos —landing, app, juego— se quedan en
un solo archivo, tal cual.

### Pruebas

- 3 unitarios nuevos (`auto-revision.test.ts`, `prueba-botones.test.ts`,
  `generico.test.ts`) para los tres `avisoIntentosAgotados()` y el nuevo
  `quedanIntentos()`.
- 1 E2E nuevo en `generico.spec.ts` con un mock que NUNCA mejora
  (`mock-generica-terca`): confirma que el aviso final aparece y que se
  pidieron exactamente 2 correcciones, ni una más.
- 2 E2E nuevos (`codigo-oculto-en-chat.spec.ts`): que durante el streaming no
  hay ni un `<pre>` con HTML a medio escribir y sí el aviso de trabajo; que
  terminado nace colapsado con el resumen de líneas y se abre al pulsar.
- 5 unitarios (`multi-archivo.test.ts`) + 2 E2E (`proyecto-multi-archivo.spec.ts`,
  mock `mock-proyecto-repo`): la instrucción de excepción viaja de verdad en
  el prompt y el modelo entrega los tres archivos separados; una landing
  normal NO la dispara.
- Verificados en rojo los tres arreglos, revirtiendo cada cambio por
  separado: el bucle silencioso volvía (90 s de timeout esperando un aviso
  que no llegaba), el HTML crudo volvía a aparecer completo en el chat, y la
  instrucción de excepción dejaba de viajar en el prompt.

### Un test que colaba por casualidad, destapado al arreglar el #2

La suite completa soltó UN fallo real:
`editar-preview.spec.ts` comprobaba que el titular editado «quedó en el
código» mirando `page.locator("main")` — pero el panel de la vista previa
(con su pestaña «Código» de verdad) es HERMANO de `<main>` en el layout, no
está dentro. La aserción pasaba igual porque el código de la respuesta se
volcaba TAMBIÉN sin colapsar en la propia burbuja del chat, que sí vive en
`<main>` — exactamente el fallo del punto 2. Con el chat ahora colapsando el
código, la aserción dejó de colar y el test falló de verdad por primera vez,
señalando que nunca había mirado la pestaña «Código» que decía comprobar.
Arreglado apuntando al `<pre>` de esa pestaña en vez de a `<main>`.

### Puerta

- ✓ lint · ✓ knip · ✓ tsc · ✓ build · ✓ **1 845** unitarios (1 833 antes) ·
  ✓ **235** E2E (230 antes), suite completa
- ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin `standalone` y con el
  `.nft.json`

## v4.11.0 — El motor 3D, solo donde su dirección lo permite

Quedó anotado en el worklog de v4.10.0: *"Nadie comprueba que el modelo use
el motor 3D solo en «experimental». El prompt lo prohíbe en las otras cinco
direcciones, pero si un modelo lo mete igual, la página se publica tal
cual."* Cerrado.

### Cómo se mide

`medirGenerico()` (el mismo barrido del DOM que ya usa el medidor de página
genérica) ahora también recoge los `data-fx3d` presentes de verdad en la
página YA PINTADA — no lo que el modelo dijo que iba a usar, lo que dejó en
el DOM. `senasEfectos3DFueraDeDireccion` (en `efectos.ts`) compara eso
contra lo que `EFECTOS_POR_DIRECCION` prohíbe para la dirección que se usó
de verdad ese turno, dato por dato — «tech», por ejemplo, SÍ permite
`3d-particulas` a propósito, así que la regla no es un bloqueo en bloque de
las cinco direcciones no-experimentales, sigue exactamente la lista negra
real de cada una.

Hacía falta un mapeo que no existía: lo que se guarda como «la dirección
usada» (`contextoUsado.diseno`, memoria del proyecto) es el `nombre`
legible ("Editorial de revista"), no el `id` interno ("editorial") que usa
`EFECTOS_POR_DIRECCION`. `idPorNombre` (`design-directions.ts`) es el
camino de vuelta.

### Comparte el bucle, no lo tripica

Esta comprobación y «parece hecha por una IA» son cosas distintas pero
tienen la misma forma (`SenaGenerica`) y necesitan exactamente el mismo
aviso/reintento — así que se juntan en una sola lista en vez de triplicar
esa fontanería por tercera vez. Para que eso no mintiera, se generalizó el
texto de `promptDeGenerico`, `resumenGenerico`, `reglaDeGenerico` y
`avisoIntentosAgotados` (`generico.ts`): antes decían "página genérica" sea
cual fuera el motivo real; ahora dicen lo que de verdad se midió. El toast
del chat pasó de "La página parece genérica" a "Hay algo que corregir" por
el mismo motivo — sería mentira si lo que se detectó es un motor 3D en la
dirección equivocada.

### Lo que salió al revisarlo dos veces (fases 4 y 6 del protocolo nuevo)

Escrito con la skill `protocolo-verificacion` recién publicada activa de
verdad, no como adorno — y cazó dos cosas antes de que llegaran a los
tests:

- Di por hecho que `promptDeGenerico` y `resumenGenerico` ya eran neutrales
  (no específicos de "genérico") sin releerlos con cuidado. No lo eran —
  tenían "página genérica" escrito literal. Verlo obligó a actualizar
  también el mock de pruebas y cuatro sitios en los E2E que buscaban esa
  frase exacta en el cuerpo de la petición.
- Un test propio asumía que las cinco direcciones no-experimentales
  prohíben los tres efectos 3D en bloque. Falso: "tech" permite
  `3d-particulas` a propósito. El test se reescribió para derivarse de
  `EFECTOS_POR_DIRECCION` de verdad en vez de un supuesto propio.

### Pruebas

- 4 unitarios nuevos en `efectos.test.ts` (detecta lo prohibido, no toca
  "experimental", sin motor 3D no hay nada que decir, sin dirección elegida
  no se juzga a ciegas) + 1 que recorre TODA la tabla `EFECTOS_POR_DIRECCION`
  contra el detector.
- 1 unitario nuevo en `design-directions.test.ts` (`idPorNombre` recorre las
  seis direcciones de vuelta).
- 2 E2E nuevos (`efectos-3d-fuera-de-direccion.spec.ts`, mock
  `mock-3d-mal-puesto`): el motor 3D en una landing "minimalista" se detecta
  y se pide quitarlo, y de verdad desaparece de la vista previa tras
  corregirse; en una landing "experimental" (donde sí está permitido) no se
  toca.
- Verificado en rojo revirtiendo `efectos.ts` + `use-generation.ts` +
  `design-directions.ts` a la vez: el E2E del caso prohibido se quedaba
  90s esperando una corrección que nunca llegaba.

### Lo que sigue sin cubrir

- **Un turno de "retoque"** (edición sobre un proyecto ya existente, no un
  encargo de UI nueva) no re-elige dirección, así que esta comprobación no
  se dispara ahí — solo cubre el turno en el que se generó o se corrigió la
  página. Si un retoque posterior añadiera un motor 3D a mano, no se
  cazaría con este mecanismo.
- **La lista negra de efectos 2D** sigue sin comprobación en tiempo de
  ejecución, igual que antes — deliberadamente fuera de esta tarea, que
  pedía específicamente el motor 3D.

### Puerta

- ✓ lint · ✓ knip · ✓ tsc · ✓ build · ✓ **1 851** unitarios (1 845 antes) ·
  ✓ **237** E2E (235 antes), suite completa
- ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin `standalone` y con el
  `.nft.json`

## v4.12.0 — La lista negra de efectos 2D, con la misma comprobación

Quedó anotado en el worklog de v4.11.0: *"La lista negra de efectos 2D
sigue sin comprobación en tiempo de ejecución, igual que antes —
deliberadamente fuera de esta tarea, que pedía específicamente el motor
3D."* Cerrado con el mismo mecanismo, no uno paralelo.

### Un detector, no dos

`senasEfectos3DFueraDeDireccion` se generalizó a `senasEfectosFueraDeDireccion`:
sigue siendo la misma comparación (lo que la página tiene de verdad contra
lo que `EFECTOS_POR_DIRECCION` prohíbe para la dirección usada), solo que
ahora mira `m.efectos2d` y `m.efectos3d` juntos en vez de solo el segundo.
Mantener dos funciones casi idénticas — una por familia — era duplicar la
única parte que de verdad importaba: la comparación. El texto de cada
efecto prohibido sale de `efectoPorId(id)?.uso` (el catálogo ya existente),
no de una frase nueva escrita a mano por familia.

`medirGenerico()` (`generico.ts`) gana un segundo campo, `efectos2d`, del
MISMO barrido del DOM que ya recoge `efectos3d` — no un segundo recorrido
por lo mismo. La mayoría de efectos 2D se marcan con `data-fx="<id>"`
directo; los `soloCss` (marquee, noise, grid/dots, underline, sheen, float,
blob) solo dejan una clase suelta, sin atributo, así que se detectan por
`querySelector` de la clase.

### La colisión de `.fx-mesh`

El motor 3D reutiliza la clase `fx-mesh` del efecto 2D "mesh" para su
propio estilo — el canvas de `<canvas data-fx3d="3d-malla" class="fx-mesh">`
lleva las dos cosas encima. Sin distinguirlas, cualquier página con el
motor 3D activo contaría también como si usara el efecto 2D "mesh", que es
falso: son dos cosas que comparten una clase por casualidad de CSS, no por
significar lo mismo. Se resuelve mirando `data-fx3d`: un elemento con esa
clase solo cuenta como el "mesh" 2D si NO tiene el atributo — si lo tiene,
es el canvas del motor 3D usando la clase para su tamaño, y ya se cuenta
aparte en `efectos3d`.

### Pruebas

- 4 unitarios nuevos en `efectos.test.ts`: un efecto 2D prohibido se
  detecta igual que uno 3D (`marquee` en "editorial"), uno permitido no es
  una seña, un 2D y un 3D prohibidos a la vez salen como un solo hallazgo
  con los dos nombrados (no dos hallazgos duplicados), y un recorrido de
  TODO `EFECTOS_POR_DIRECCION` para la mitad 2D del catálogo (el mismo
  patrón data-driven que ya se usó para la mitad 3D en v4.11.0).
- 2 E2E nuevos (`efectos-2d-fuera-de-direccion.spec.ts`, mock
  `mock-2d-mal-puesto`): un `<div class="fx-marquee">` en una landing
  "editorial de revista" (donde está prohibido) se detecta y se pide
  quitarlo, y de verdad desaparece de la vista previa tras corregirse; en
  una landing "brutalista" (donde sí está permitido) no se toca.
- El marcador de corrección tuvo que ser el mismo que en v4.11.0 (la
  apertura de `promptDeGenerico`, "y la he medido") y no `.includes("marquee")`
  a secas: el propio prompt de sistema de "editorial" ya nombra "marquee"
  en su lista de PROHIBIDOS (`promptEfectos`), así que esa palabra sale en
  el primer turno igual sin haberse corregido nada — el mismo colapso que
  ya apareció con "motor 3D" en la dirección "experimental".
- Verificado en rojo revirtiendo `efectos.ts` + `generico.ts` +
  `use-generation.ts` a la vez (manteniendo el mock nuevo): el E2E del caso
  prohibido se quedaba 90s esperando una corrección que nunca llegaba,
  exactamente igual que el fallo real que este cambio cierra.

### Lo que rompió la generalización, y que el gate completo sí cazó

La primera vuelta del gate (suite E2E completa) salió con un fallo real:
`efectos-3d-fuera-de-direccion.spec.ts`, el test de v4.11.0 para el motor
3D, se quedaba 90s esperando una corrección que sí estaba pasando —
`senasEfectosFueraDeDireccion` SÍ detectaba el motor 3D fuera de sitio y SÍ
se lo devolvía al modelo. Lo que rompió fue el texto: la versión vieja
(`senasEfectos3DFueraDeDireccion`) tenía la frase «el motor 3D» escrita a
mano en el aviso, y tanto el test como el propio mock `mock-3d-mal-puesto`
usaban `.includes("motor 3D")` como marcador de «ya se corrigió». La
generalización de v4.12.0 volvió ese texto neutro (solo nombra los ids
reales, como se explica arriba) — correcto para servir a 2D y 3D por
igual, pero deja de contener esa frase literal.

Se corrigieron los dos sitios que dependían de ella, con el mismo marcador
ya usado en el segundo test del propio archivo y en el mock nuevo: la
apertura de `promptDeGenerico` (`"y la he medido"`), que no depende de qué
se corrigió. Sin la vuelta completa del gate esto no se habría visto: los
unitarios no tocan el mock ni el texto exacto que viaja por HTTP, y el E2E
nuevo de 2D no ejercita el mock viejo de 3D.

### Lo que sigue sin cubrir

- Mismo hueco que v4.11.0, ahora para las dos familias: un turno de
  "retoque" (edición sobre un proyecto existente, no un encargo de UI
  nueva) no re-elige dirección, así que esta comprobación no se dispara
  ahí.

### Puerta

- ✓ lint · ✓ knip · ✓ tsc · ✓ **1 855** unitarios (1 851 antes) ·
  ✓ **239** E2E (237 antes), suite completa
- ✓ build · ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin `standalone`
  y con el `.nft.json`

## v4.13.0 — QA por visión: `visual_review` VE la página, no la mide

Auditoría contra el plan «Prism Web AI» que trajo el usuario: casi todo el
MVP que describe ya existía en Prism con otro nombre (tools de archivos,
sandbox, checkpoints con `git_snapshot`/`snapshot_diff`, memoria de
proyecto persistida en `.prism/`, permisos por herramienta…). El hueco
real, y el que el usuario eligió como primer paso: todo el QA visual de
hoy —`generico.ts`, `efectos.ts`, `visual-qa.ts`— **mide el DOM**, nunca
**ve la página**. Ningún selector detecta que un titular pesa poco frente
al hero, o que dos bloques quedan descompensados: eso hace falta VERLO.

### Cómo se captura, sin librería y sin red

El mismo problema de origen que `visual-qa.ts`: el iframe corre con
`sandbox="allow-scripts…"` SIN `allow-same-origin`, así que el padre no
puede leer su DOM ni dibujarlo con un `html2canvas` que viva fuera. La
captura (`screenshot.ts`) se hace DESDE DENTRO, con lo que ya da el
navegador:

1. `XMLSerializer` serializa el documento a XML.
2. Se envuelve en `<svg><foreignObject>` — un SVG es una imagen válida y
   su contenido HTML se pinta tal cual se ve.
3. Ese SVG (como `data:` URI) se carga en una `Image` y se dibuja en un
   `<canvas>` del MISMO documento — nunca una imagen ajena sin CORS, que
   es justo lo que dejaría el canvas contaminado.
4. `canvas.toDataURL('image/jpeg', 0.85)`, con el lado máximo capado a
   1152 px — el mismo tope que ya usa `attachments.ts` para lo que sube
   el usuario: la captura es para que un modelo la MIRE, no para
   archivarla.

Se probó primero AISLADO (un `parent.html` con un iframe sandbox idéntico
al real, gradiente + sombra + fuente por `<link>`) antes de escribir una
sola línea de la integración: la técnica podía fallar por «canvas
contaminado» y mejor saberlo en un script de 40 líneas que a mitad de la
tool. Funcionó a la primera — el resultado, con el gradiente y la sombra
intactos, se mandó como archivo antes de seguir.

**Límite honesto, documentado en el propio `screenshot.ts`**: un
`<canvas>` con contenido pintado a mano (WebGL, 2D) NO sale en la
captura — `foreignObject` serializa el DOM, no el bitmap que un canvas
tiene encima. El motor 3D (`prism-3d.js`) sale en blanco dentro de la
foto. No es un bug, es lo que la técnica puede dar.

### La herramienta: bajo demanda, no automática

Tres decisiones de producto, puestas al usuario antes de escribir código
porque cambiaban bastante la implementación:

- **Tool del agente, no un paso automático.** `visual_review` es una
  herramienta más del catálogo (como `read_url` o `run_regression`): el
  agente decide cuándo pedirla. No se dispara en cada generación —una
  llamada de visión es cara, y el propio plan del usuario lo marcaba
  como el driver de coste a vigilar.
- **El mismo modelo de la conversación, no uno de visión aparte.**
  `visionCritique` (`use-agent-tools.ts`) llama a `streamChat` con el
  MISMO `providerId`/`modelId`/clave que ya está hablando con el
  usuario. Si no admite imágenes, `chat-client.ts` ya arma el aviso «no
  admite imágenes» en el mensaje del error (`assertOk`, vía
  `esFalloDeImagen`) — la herramienta solo reconoce ESE texto en vez de
  reinventar la detección, y responde con eso en lugar de fingir una
  crítica.
- **Informa, no reintenta.** A diferencia de lo genérico o los efectos
  fuera de dirección, `visual_review` NO entra en el bucle de
  auto-revisión (`MAX_REVISIONES`): una crítica de visión es más
  subjetiva que un contraste medido, y reintentar en bucle contra algo
  que el modelo puede alucinar es peor que no reintentar. Decide el
  agente (o el usuario) si corrige.

### Reutilizado, no duplicado

`sandbox-runner.ts` ya montaba un iframe OCULTO para `run_project`
(headless, sin tocar la vista previa visible): `opts.screenshot` es una
tercera bandera junto a `qa`/`botones`, no un segundo ejecutor. Se
ensancha a 1280×800 SOLO cuando se pide screenshot (`run_project`/
`run_regression` normales siguen midiendo a 390px, que es lo que ya
prueban). La captura reutiliza `FX_ASENTAR` (de `efectos.ts`) para dejar
los efectos en su estado FINAL antes de disparar el obturador — sin eso
la foto saldría a medio entrar, con secciones en `opacity:0` esperando el
scroll.

### Pruebas

- 12 unitarios en `screenshot.test.ts` (inyección idempotente, sin
  cerrar `</script>` por accidente, usa la técnica sin red, asienta y
  desasienta los efectos, tope de 1152px, un fallo se reporta nunca se
  calla) + 3 de `promptCritica`.
- 4 unitarios en `visual-review.test.ts`: sin `vision` no hay
  `visionCritique` (la tool lo dice en vez de fingir), llama al MISMO
  proveedor/modelo con la captura como adjunto, reconoce «no admite
  imágenes» sin confundirlo con otro fallo (clave inválida, red…).
- 6 unitarios nuevos en `tool-runner.test.ts` (sin Sandbox, sin
  `visionCritique`, proyecto que no se ejecuta, captura que falla, el
  camino feliz con `foco`, el aviso de «no admite imágenes»).
- 2 E2E (`visual-review.spec.ts`, mocks `mock-visual-review` /
  `mock-visual-review-sin-vision`): el agente escribe una página, pide
  `visual_review`, la captura real se toma en el sandbox oculto, la
  llamada INTERNA de visión (con la imagen adjunta) vuelve al mismo mock
  y la crítica llega al chat; con un modelo que "rechaza" la imagen, la
  herramienta lo dice y no inventa nada.
- Verificado en rojo: se apartó `screenshot.ts` y se revirtieron
  `sandbox-runner.ts` + `tool-runner.ts` + `tools-catalog.ts` +
  `tool-permissions.ts` + `use-agent-tools.ts` + el mock a la vez — los
  dos E2E fallaban (herramienta/modelo inexistentes), confirmado antes de
  restaurar.
- El primer intento de gate completo destapó tres tests VIEJOS con listas
  de herramientas escritas a mano (`tool-permissions.test.ts` ×3,
  `tools-catalog.test.ts`, y en E2E `permisos-agente.spec.ts` ×2 y
  `tools-agente.spec.ts`) que no contaban con una 17ª herramienta —
  mantenimiento esperado, no un fallo real; se actualizaron todos.
- Una segunda vuelta del gate completo tuvo un fallo aislado en
  `preview-botones.spec.ts` (timing del barrido de botones, área que este
  cambio no toca) que no se repitió ni en una tercera vuelta completa ni
  en tres ejecuciones sueltas del mismo archivo: flake bajo carga, no
  regresión.

### Lo que sigue sin cubrir

- El límite del canvas/WebGL documentado arriba: la escena 3D
  (`prism-3d.js`) no aparece en la captura. Cubrirlo de verdad pediría
  leer el framebuffer del propio motor, no esta técnica.
- Sin botón manual: la decisión fue "tool del agente primero" — extender
  el botón «QA visual» existente para disparar también esto queda fuera,
  sin pedirse.
- Responsive por visión (varios anchos, como ya hace el QA por DOM) no
  entra: una sola captura a 1280px, la que decide qué ancho usar es el
  propio `sandbox-runner.ts`, fijo.

### Puerta

- ✓ lint · ✓ knip · ✓ tsc · ✓ **1 877** unitarios (1 855 antes) ·
  ✓ **241** E2E (239 antes), suite completa
- ✓ build · ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin `standalone`
  y con el `.nft.json`

## v4.13.1 — La captura salía casi toda negra: fondo por defecto sin rellenar

El usuario pidió, tras el v4.13.0: "pruébalo todo, intenta crear algún
diseño y verifica cómo queda todo, usa la herramienta a ver qué error
detectas". Ni el gate automático ni los E2E lo habrían cazado —ninguno
mira de verdad el PÍXEL de la imagen capturada, solo el texto que viaja
después— así que tocaba manejar la app a mano: servidor real (`npm run
dev`), un script que conduce el navegador como lo haría una persona
—escribe el encargo, deja que el agente trabaje, espera la respuesta— y
al final EXTRAE la captura real que viajó en la petición de visión y la
mira.

Con una página mínima (`<body>` sin `background` propio, un `<h1>` con el
negro por defecto del navegador) la imagen resultante salía casi
TOTALMENTE NEGRA — el titular, invisible. La única pista de que algo se
había capturado era un rectángulo gris tenue en la esquina: el único
elemento con un `background` ESCRITO A MANO en el HTML.

### La causa

`foreignObject` no hereda el blanco por defecto del navegador — el fondo
de una página sin `background` explícito es, dentro del SVG, transparente.
Y `canvas.toDataURL('image/jpeg', …)` no tiene canal alfa: lo transparente
se exporta relleno de NEGRO, no de blanco. Con texto negro por defecto
sobre ese fondo ahora negro, el titular quedaba invisible encima de lo que
ya era invisible — dos negros sobre negro.

Esto no es un caso raro: es el caso NORMAL. La inmensa mayoría de páginas
que un modelo genera no ponen `background` a mano en el `<body>` (confían
en el blanco del navegador), así que sin este arreglo la herramienta
habría fallado en casi cualquier página real, no solo en la de prueba.

### El arreglo

Antes de `ctx.drawImage(...)`, `screenshot.ts` ahora rellena el canvas con
el fondo REAL de la página —`getComputedStyle(document.body)
.backgroundColor`, cayendo a `documentElement` y por último a blanco si
los dos son transparentes— y solo entonces dibuja la imagen encima. Una
página con fondo explícito (el gradiente de la prueba original) no cambia:
el relleno queda tapado por lo que se dibuja después.

### Pruebas

- 1 unitario nuevo en `screenshot.test.ts`: comprueba que el script
  rellena (`fillStyle`/`fillRect`) ANTES de `drawImage`, no después.
- Verificado en rojo apartando SOLO el arreglo (`git stash` de
  `screenshot.ts`) y confirmando que el test nuevo fallaba contra la
  versión ya comprobada y pusheada en v4.13.0 — el propio commit que
  acababa de subir tenía este fallo.
- Verificado visualmente contra la app real, dos veces: capturado
  ANTES del arreglo (negro, titular invisible) y DESPUÉS (fondo blanco,
  titular "Bienvenido a la tienda" legible, el botón de bajo contraste
  visible con su borde — coincide exactamente con lo que dice la crítica:
  "el botón principal casi no se distingue del fondo").

### Lo que sigue sin cubrir

- Solo se probó a mano el caso "fondo sin declarar" (el más común) y el
  caso "fondo con gradiente explícito" (de la prueba original de
  v4.13.0). Un fondo oscuro EXPLÍCITO (`background: #111`) no se probó a
  mano — por el mismo razonamiento (`getComputedStyle` devuelve el color
  real cuando está puesto, no transparente) debería capturarse tal cual,
  pero es INFERIDO, no confirmado con una imagen real.

### Puerta

- ✓ lint · ✓ knip · ✓ tsc · ✓ **1 878** unitarios (1 877 antes) ·
  ✓ **241** E2E, suite completa
- ✓ build · ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin `standalone`
  y con el `.nft.json`

## v4.14.0 — Recorte proactivo: no esperar a que el proveedor se queje

Un usuario reportó, en la app real, exactamente el hueco que el worklog de
v4.6.0 dejó anotado: *"si la conversación no le cabe a NINGUNO de tus
modelos, no hay a dónde ir... el modo ahorro y la ventana de contexto ya
existen, pero nadie los aplica solo"*. Captura de pantalla: `ctx ≈29,6k ·
92,5%` (zona roja del HUD), un `nvidia/nemotron` vía OpenRouter tardando
182s y devolviendo el error *"El modelo cerró la respuesta sin escribir
nada."*

### El diagnóstico, con datos, no con suposición

Prism ya recorta el historial cuando un proveedor se queja EXPLÍCITAMENTE
de que no cabe (`esDemasiadoGrande`, `decisiones.ts:101` — un 413, o texto
tipo «maximum context length»): quita turnos viejos con `recortar()`
(`recorte-contexto.ts`) y reintenta con el MISMO modelo. Pero la respuesta
del usuario no fue un error — fue un **HTTP 200 con el stream vacío**. Ese
camino (`use-generation.ts`, el `if (!aportado.trim())`) nunca comprueba
el tamaño del contexto: solo decide si saltar al siguiente modelo de la
cadena o rendirse. Y como probablemente cargaban el mismo historial
gigante, todos los candidatos de Auto fallaron igual — de ahí los 182s,
varios intentos y no uno.

### El arreglo: actuar sobre lo que ya se mide, no sobre lo que se supone

En vez de intentar adivinar la CAUSA de una respuesta vacía (podría ser
otra cosa), se actúa sobre un dato que la app YA calcula y ya le enseña al
usuario: el HUD de contexto (`ctx-hud.ts`) tiene su propio umbral de "zona
roja" (`UMBRAL_ROJO = 95`), pintado en el compositor antes de que el
usuario ni pulse enviar. Ahora, justo antes del primer intento de cada
turno, si ese nivel ya es rojo, se recorta con el mismo `recortar()` del
camino reactivo (misma `ventanaCtx` de Ajustes, mismo aviso «se quitaron N
mensajes viejos»), ANTES de mandar nada — sin esperar a que el proveedor
falle, calle, o tarde 182 segundos en decir que no tiene nada que decir.

Deliberadamente SIN la llamada de resumen que sí tiene el camino reactivo
(`mereceResumen`/`promptDeResumen`): esa cuesta una petición extra al
modelo, y aquí se dispararía en CADA turno con el contexto lleno, no solo
en el recorte ocasional de un modelo concreto — coste que no se pidió
asumir sin más.

### Reutilizado, no reinventado

Cero funciones nuevas para medir o decidir: `tokensDe` (ya existía en
`recorte-contexto.ts`), `calcularHud`/`VENTANA_DEFECTO` (ya existían en
`ctx-hud.ts`, ya usados por el HUD visible), `recortar()` (el mismo que
usa el camino reactivo). Solo cablea tres piezas que ya vivían separadas.

### Pruebas

- 1 E2E nuevo (`recorte-proactivo.spec.ts`): una sesión sembrada con
  `ventanaCtx: 1000` y suficiente historial para cruzar la zona roja,
  contra `mock-mini-free` (un modelo que NUNCA falla por tamaño — a
  propósito, para dejar claro que el disparo es el NIVEL de contexto, no
  un error del proveedor). Comprueba que el aviso «Historial recortado
  antes de enviar» sale ANTES de la respuesta, que responde a la primera
  con el mismo modelo, y que la PRIMERA petición que salió por red ya
  iba recortada (no hay un intento grande fallido antes).
- Verificado en rojo: revertido solo `use-generation.ts`, confirmado que
  el test nuevo fallaba (el aviso nunca aparecía) contra el código de
  v4.13.1, restaurado y confirmado en verde.
- Los dos tests de `recorte-y-reintento.spec.ts` (el camino REACTIVO, con
  `esDemasiadoGrande`) se corrieron junto al nuevo para comprobar que no
  interfieren: su sesión sembrada usa la ventana por defecto (32k) y se
  queda muy por debajo de zona roja, así que el recorte proactivo no
  actúa ahí — sigue siendo el 413 quien dispara ese camino.

### Lo que sigue sin cubrir

- Sin resumen en el camino proactivo (explicado arriba): lo que se
  recorta se pierde, no se resume. Si hiciera falta, es una extensión del
  mismo `mereceResumen` ya existente, no una pieza nueva.
- La ventana de referencia (`ventanaCtx`) sigue siendo una ESTIMACIÓN
  local (caracteres ÷ 4) contra un número configurable, no el límite real
  del proveedor — el mismo límite honesto que ya tenía el HUD antes de
  esto. Un modelo con una ventana real mucho más pequeña que la de
  referencia puede seguir fallando antes de llegar a zona roja.

### Puerta

- ✓ lint · ✓ knip · ✓ tsc · ✓ **1 878** unitarios · ✓ **242** E2E (241
  antes), suite completa
- ✓ build · ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin `standalone`
  y con el `.nft.json`

## v4.15.0 — La herramienta pedida como texto, no como `tool_calls`

El usuario, tras dos capturas seguidas mostrando el mismo patrón: *"Siguen
los errores cada vez está peor no se que estás haciendo"*. Con razón —esta
vez no era una variación del bug de contexto de v4.14.0, era uno distinto
y peor: la burbuja del chat enseñaba, literal, `<function=write_file>
<parameter=path> index.html </parameter> <parameter=content>...` en vez de
escribir la página. Pasó dos veces en la misma conversación, con
`nvidia/nemotron` vía OpenRouter en modo agente.

### El diagnóstico

El modelo SÍ intentaba llamar a la herramienta —no se quedó callado, no
alucinó texto suelto— pero con la plantilla de function-calling de su
PROPIO entrenamiento (variante Llama-3/Hermes: `<function=NOMBRE>
<parameter=CLAVE>valor</parameter></function>`), no con el campo
`tool_calls` que pide la API estilo OpenAI. `tools-translate.ts`
(`parseToolCallsFromChunk`, protocolo `openai`) solo lee
`delta.tool_calls`; si no es un array, devuelve `[]` y ya. La plantilla
nunca pasa por ahí: entra como `delta.content`, y `delta.content` es
exactamente lo que se enseña en la burbuja.

`tools-probe.ts` (`probeTools`) tampoco lo habría cazado: solo comprueba
que el proveedor ACEPTA el parámetro `tools` en la petición (un código
HTTP), nunca confirma que el modelo vaya a rellenar `tool_calls` de
verdad en una respuesta con contenido real. Un modelo puede pasar el
probe como "sí soporta tools" y aun así, en la práctica, servir su propia
plantilla como texto — que es justo lo que hace `nvidia/nemotron` aquí.

### El arreglo: reconocer la plantilla, no perseguir el proveedor

Nuevo módulo `tool-calls-texto.ts`: reconoce ESE patrón concreto y
confirmado (`pareceLlamadaEnTexto` para una comprobación barata antes de
correr el parser completo; `parseLlamadasEnTexto` extrae nombre+parámetros
como `ToolCall[]` de verdad; `quitarLlamadasEnTexto` deja solo el texto
que de verdad acompañaba a la llamada, normalmente nada). Nunca lanza: una
llamada CORTADA a mitad —una respuesta truncada, sin `</function>` de
cierre— no cuenta como llamada. Mejor no ejecutar nada que ejecutar con un
argumento a medias.

Se engancha en `ejecutarConTools` (`use-agent-tools.ts`), justo después de
pedir la vuelta al modelo: si la vía estructurada no trajo ningún
`tool_calls` pero el texto SÍ parece la plantilla, se parsea, se limpia el
texto visible (`baseOpts.onDelta(content)` con el contenido ya sin la
plantilla — `onDelta` REEMPLAZA lo mostrado, no lo añade, así que el
texto crudo desaparece de la burbuja en el mismo instante) y se sigue el
MISMO camino que una llamada estructurada: mismo `runTools`, misma
reinyección al modelo en la siguiente vuelta, mismo límite de
`agentMaxLoops`. Cero camino paralelo.

### Pruebas

- 9 unitarios nuevos (`tool-calls-texto.test.ts`): la plantilla real
  reportada, con espacios sueltos entre etiquetas (como llegó de verdad),
  varias llamadas en el mismo texto, una llamada cortada que NO cuenta, y
  que `quitarLlamadasEnTexto` conserva el texto que de verdad acompañaba
  a la llamada.
- 3 unitarios nuevos en `agent-tools-loop.test.ts`: el archivo se escribe
  de VERDAD (no solo se "detecta" la plantilla), la respuesta final es
  la de la segunda vuelta y no la plantilla cruda, el mensaje reinyectado
  al modelo no lleva la plantilla rota como si fuera su propio texto
  (reinyectarle su propio error es invitarlo a repetirlo), y una llamada
  cortada a mitad se trata como texto normal, no se ejecuta.
- 1 E2E nuevo (`llamada-en-texto.spec.ts`) con un modelo mock nuevo
  (`mock-llamada-en-texto`) que nunca llama a `onToolCalls` —manda la
  plantilla cruda como único contenido, igual que el proveedor real—:
  comprueba que el chat responde "Página escrita." tras ejecutar la
  herramienta y que `<function=`/`<parameter=` NUNCA aparecen literales
  en el texto visible.
- Verificado en rojo: revertido solo `use-agent-tools.ts` (`git stash`),
  confirmado que los 2 tests unitarios nuevos fallaban por la razón
  correcta (`volcados.length` en 0 — el archivo nunca se escribía;
  `registro[1]` indefinido — nunca hubo segunda vuelta) y que el E2E
  reproducía el bug real tal cual lo vio el usuario (el selector de
  "Página escrita." nunca aparecía, timeout a los 90s), restaurado y
  confirmado en verde.

### Errores propios de este arreglo, documentados sin maquillar

- Al añadir el modelo mock `mock-llamada-en-texto` a
  `src/app/api/mock-llm/[...path]/route.ts`, la primera versión comparaba
  contra `modelo` —una variable local de `buildReply(body)`, una función
  distinta— en vez de `body.model`, que es lo que existe en el handler
  `POST` donde vive el bloque nuevo (junto a `mock-visual-review` y los
  demás casos especiales). `npx tsc --noEmit` no lo cazó porque `modelo`
  SÍ existe en el archivo —solo que en otro alcance—, así que no fue un
  error de tipos sino de lectura propia del código; se detectó releyendo
  el bloque antes de confiar en él, se corrigió a `body.model` y se
  reverificó.
- La primera versión del E2E incluía una aserción final contra el iframe
  de vista previa del Sandbox (`iframe[title="Vista previa de la página
  generada"]`), esperando ver ahí el texto escrito por la herramienta.
  Falló: ese iframe está cableado a bloques ` ```html ` detectados en
  respuestas normales del chat, no a escrituras de `write_file` del
  agente hacia el Sandbox —dos rutas distintas que no se sincronizan
  entre sí, y no es parte de este bug. Se quitó esa aserción en vez de
  cablear una sincronización que no se pidió; el test unitario (via
  `onProjectFiles`) ya prueba que el archivo se escribió de verdad.

### Lo que sigue sin cubrir

- Se reconoce ÚNICAMENTE la plantilla confirmada
  (`<function=NOMBRE><parameter=CLAVE>valor</parameter></function>`,
  variante Llama-3/Hermes). Otros formatos de function-calling en texto
  plano que algún otro modelo pueda usar (JSON suelto en el contenido,
  XML con otra forma, etc.) no se reconocen —no hay evidencia real de
  ellos todavía, y adivinar formatos sin un caso confirmado es el mismo
  error que llevó a este bug (un probe que confía sin comprobar).
- Sigue sin haber forma de saber, ANTES de que ocurra, que un modelo va a
  usar su propia plantilla en vez de `tool_calls` —`tools-probe.ts` no
  cambia con este arreglo. Esto es una red de seguridad DESPUÉS del
  hecho, no una detección temprana.
- No se probó un tercer nivel de anidado (una llamada con un parámetro
  cuyo VALOR contenga, a su vez, la palabra `</parameter>` o
  `</function>` literal dentro de código HTML generado) —el regex no
  máximo-perezoso podría cortar antes de tiempo en ese caso extremo. No
  apareció en el reporte real ni en las pruebas, queda como hueco
  conocido.

### Puerta

- ✓ lint · ✓ knip (solo huecos preexistentes, ninguno de los archivos
  nuevos) · ✓ tsc
- ✓ **1 890** unitarios (1 878 antes) · ✓ **243** E2E (241 antes), suite
  completa
- ✓ build · ✓ `npm start` + `/api/version` (`4.15.0`) · ✓ `VERCEL=1` sin
  `standalone` y con el `.nft.json`

## v4.16.0 — Una tienda o un menú tienen que FUNCIONAR, no solo enseñarse

El usuario pidió probar la app de principio a fin, sin dejar nada sin
tocar: *"si se le manda a hacer una página, por qué no la hace completa,
hace las cosas a medias [...] que cuando se mande a hacer una página, ya
él haga la página con todo lo que lleva carrito, órdenes de compra,
reseña [...] que puedas tocar, accionar para entrar, a ver las cosas del
producto"*. No traía una captura de un fallo puntual — pedía una revisión
completa para encontrar por qué esto pasa siempre.

### La causa, encontrada leyendo lo que de verdad viaja al modelo

Grep de `carrito|checkout` en todo `src/lib/prism`: CERO resultados fuera
de un comentario de CI (`deploy.ts:47`, «Checkout» de una GitHub Action).
La skill que arranca activada por defecto y decide cómo se construye
cualquier página, **"Desarrollador web experto"** (`skills-data.ts:13-19`),
solo pide: un único HTML autónomo, responsive, con animaciones y
hover/focus cuidados. Nada dice que un carrito tenga que sumar de verdad,
que una tarjeta de producto lleve a su detalle, o que un botón de "Pedir"
tenga que hacer algo. `multi-archivo.ts` (v3.x) ya había resuelto el
mismo tipo de hueco pero para OTRA cosa —cuántos archivos entregar—, no
para esto. Sin la instrucción, el modelo entrega la landing bonita que ya
sabe hacer: exactamente el síntoma reportado, y no un bug de un turno
suelto — un hueco real en lo que se le pide siempre que el encargo es de
este tipo.

### El arreglo: la misma técnica que `multi-archivo.ts`, para otro hueco

`catalogo-interactivo.ts` detecta cuándo el encargo es una tienda, menú o
catálogo (`tienda`, `carrito`, `restaurante`, `menú`, `delivery`,
`marketplace`, `pedidos`, `checkout`…) y añade, como AMPLIACIÓN de la
skill activa —igual que hace `INSTRUCCION_VARIOS_ARCHIVOS`—, la exigencia
concreta: al menos 6-8 productos reales del rubro, cada tarjeta CLICABLE
con su vista de detalle, un carrito que suma de verdad (contador, panel,
cantidad +/-, total recalculado), un checkout que TERMINA en una
confirmación real (no un botón decorativo), y una sección de reseñas con
ejemplos realistas — todo con `addEventListener` de verdad, nunca
`href="#"` sin manejador. Se engancha en `prompt-actual.ts` junto a
`pideVariosArchivos`, con la misma condición (`!trivial`, dentro del
bloque de skills activas): una carta de presentación o un blog no lo
disparan, pedirles carrito sería ruido.

### Verificación: no solo que el texto viaje, que la interacción funcione de verdad

Antes de tocar el prompt, se comprobó con la app real (`npm run dev`) que
el HUECO no era técnico: se montó una tienda de zapatillas con carrito,
detalle de producto, checkout y confirmación —JavaScript real, sin
backend— y se condujo el navegador como una persona contra la vista
previa en vivo (iframe sandboxed, `allow-scripts` sin `allow-same-origin`):
clic en una tarjeta → abre el detalle, "Añadir al carrito" → sube el
contador, abrir el carrito → total correcto, "Confirmar pedido" → número
de pedido real. Los seis pasos funcionaron a la primera, cero errores de
consola — confirma que el sandbox de Prism no bloquea nada de esto; el
hueco era SOLO la instrucción que faltaba, no una limitación técnica.
Curiosamente, esa misma prueba disparó de forma genuina el detector de
páginas genéricas (`generico.ts`, señal `sin-pareja`: titular y cuerpo
con la misma tipografía, cosa cierta en el HTML de prueba) y hasta pidió
al modelo "continuar el trabajo" para corregirlo — confirma que ESE
sistema de calidad, ya existente, funciona con normalidad y es
independiente de este arreglo.

### Pruebas

- 5 unitarios nuevos (`catalogo-interactivo.test.ts`): detecta tienda,
  restaurante, catálogo, menú, delivery y marketplace; NO se dispara con
  un portfolio, una landing de software o un blog; la instrucción exige
  carrito, tarjetas clicables, checkout que termina y reseñas, y prohíbe
  explícitamente los botones sin manejador.
- 3 E2E nuevos (`tienda-interactiva.spec.ts`), mismo patrón que
  `saludo-sin-agente.spec.ts` (leer lo que VIAJA al modelo, no lo que se
  ve): pedir una tienda o un menú SÍ lleva la instrucción en el cuerpo de
  la petición; una landing normal (portfolio) NO la lleva.
- Verificado en rojo: revertido solo el cableado en `prompt-actual.ts`
  (`git stash`), confirmado que 2 de los 3 E2E fallaban por la razón
  correcta (la skill SÍ viajaba — «Desarrollador web experto» — pero sin
  la ampliación de tienda), restaurado y confirmado en verde.

### Lo que sigue sin cubrir

- La instrucción solo se activa si hay al menos una skill activa
  (`activas.length`, la misma condición que ya tenía
  `INSTRUCCION_VARIOS_ARCHIVOS`): si el usuario apaga TODAS las skills
  —incluida la de desarrollador web, que va encendida por defecto—, la
  instrucción tampoco viaja. Es coherente con lo que ya existía (la
  ampliación no tiene sentido sin la skill base que la usa), pero es una
  dependencia real, no una elección de este arreglo.
- Sigue sin haber forma de VERIFICAR después de generar que el modelo
  cumplió la instrucción (que el carrito sume de verdad, que el checkout
  no sea decorativo): esto es una instrucción más fuerte en el prompt, no
  una comprobación posterior. `visual_review` (v4.13.0) podría mirarlo si
  se le pide explícitamente, pero no se dispara solo para esto.
- No se probó con un modelo real de pago o gratuito (sin clave configurada
  en este entorno) — la verificación de "la instrucción viaja" y "el
  sandbox soporta la interacción" es sólida, pero si un modelo concreto
  la ignora o la cumple a medias sigue siendo comportamiento del modelo,
  fuera del control de Prism.

### Puerta

- ✓ lint · ✓ knip (sin huecos en los archivos nuevos) · ✓ tsc
- ✓ **1 895** unitarios (1 890 antes) · ✓ **246** E2E (243 antes), suite
  completa
- ✓ build · ✓ `npm start` + `/api/version` (`4.16.0`) · ✓ `VERCEL=1` sin
  `standalone` y con el `.nft.json`

## v4.17.0 — Antimuestrario + paletas listas (skill opcional)

El usuario preguntó por cuatro skills de la comunidad para agentes de
código —DESIGN.md de Google, Awesome DESIGN.md, Impeccable (Taste Skill) y
UI/UX Pro Max— y si valía la pena traer algo de eso a Prism. Tras mirar
las tres más concretas (`agent-design-taste`, `ui-ux-pro-max-skill` en
GitHub, y lo que documentan sobre Impeccable), la respuesta fue: sí, con
una versión destilada — no copiar 97/192 paletas ni 57/74 parejas
tipográficas tal cual, que es más peso del que el prompt necesita cargar
en cada turno.

### Primer intento, revertido: rompía el tope de presupuesto

La primera versión amplió directamente «Diseños que no se repiten» (la
skill que ya cubre el mismo terreno y va activada de fábrica) con un
antimuestrario concreto y cuatro paletas completas. `presupuesto.test.ts`
lo cazó al momento: el guardia de fábrica (`las skills de fábrica no se
pasan de presupuesto`, tope 3 000 caracteres — puesto ahí en su día por
una duplicación real, ver la nota del propio test) pasó de un total
verificado a **4 587**, y con el modo agente encendido a **6 734** contra
un aviso de **6 000**. Revertido: en vez de forzar el tope hacia arriba
para que quepa, el contenido se movió a una skill NUEVA, desactivada por
defecto — el mismo patrón que ya usan «Mentor de código» o «Analista de
datos» para extras que no todo el mundo necesita pagar en cada turno.

### La skill: `skill-anti-slop` — "Antimuestrario + paletas listas"

Ampliación explícita de «Diseños que no se repiten» (lo dice en su primera
línea), no una skill de variedad paralela — comprobado con un test que
verifica que NO repite la frase que identifica a la otra («nunca se
parezcan»). Trae, condensado de las tres fuentes:
- Antimuestrario: la combinación por defecto de cualquier generador
  (gradiente morado→azul + glassmorphism + radio uniforme de 24px + Inter
  en todo + tres tarjetas idénticas + un blob 3D), iconos hechos con
  emoji en vez de SVG, «+50.000 equipos confían en nosotros» sin fuente,
  centrar todo en móvil en vez de reorganizar, el mismo hero repetido
  sección tras sección.
- Interacción que se nota: `cursor: pointer` en lo clicable,
  `prefers-reduced-motion` respetado, contraste mínimo 4.5:1 comprobado.
- Cuatro combinaciones completas de paleta + pareja tipográfica listas
  para usar (spa/bienestar, fintech, editorial, dev tool) — con hex y
  nombres de fuente reales, no solo categorías.

### Pruebas

- 3 unitarios (`skill-anti-slop.test.ts`): existe y va desactivada por
  defecto, trae antimuestrario/paletas/reglas concretas, no duplica la
  frase de la otra skill de variedad.
- 1 E2E (`skill-anti-slop.spec.ts`): se activa desde el diálogo de Skills
  (interruptor apagado por defecto) y, activada, el texto SÍ viaja en la
  petición al modelo.
- Verificado en rojo: revertido solo `skills-data.ts` (`git stash`),
  confirmado que los 3 unitarios fallaban por la razón correcta (la skill
  no existe todavía), restaurado y confirmado en verde. El E2E ya había
  quedado probado en verde antes del stash con el mismo patrón que
  `saludo-sin-agente.spec.ts` y `tienda-interactiva.spec.ts` (leer lo que
  viaja, no lo que se ve).

### Lo que sigue sin cubrir

- Va DESACTIVADA por defecto: si el usuario no la enciende, no cambia
  nada de lo que ya generaba Prism. Es una opción, no una mejora
  automática — coherente con no volver a romper el presupuesto de fábrica.
- Solo cuatro paletas, elegidas por ser representativas de rubros
  distintos (bienestar, finanzas, editorial, dev tool) — no un catálogo
  exhaustivo como el de UI/UX Pro Max. Si hace falta más variedad, es
  ampliar esta lista, no rehacer la skill.
- No hay una comprobación posterior de que el resultado cumple el
  antimuestrario (que de verdad no haya gradiente morado, que los iconos
  sean SVG): es una instrucción más fuerte en el prompt, igual que
  `catalogo-interactivo.ts` (v4.16.0) — `generico.ts` sigue siendo la
  única detección automática después de generar, y no cubre estos puntos
  concretos.

### Puerta

- ✓ lint · ✓ knip (sin huecos en los archivos nuevos) · ✓ tsc
- ✓ **1 898** unitarios (1 895 antes) · ✓ **247** E2E (246 antes), suite
  completa
- ✓ build · ✓ `npm start` + `/api/version` (`4.17.0`) · ✓ `VERCEL=1` sin
  `standalone` y con el `.nft.json`

## v4.18.0 — Tres huecos que quedaron documentados, ahora cerrados

El usuario preguntó «¿qué nos quedaría por mejorar?» después de la skill
de v4.17.0. La respuesta salió de releer los "Lo que sigue sin cubrir" de
las últimas entregas —huecos ya conocidos, no inventados para la
ocasión— y eligió los cuatro: verificar el antimuestrario en vez de solo
pedirlo, que `tools-probe.ts` deje de ser ciego, una ventana de contexto
real por modelo, y probarlo todo con un modelo de pago real. Los tres
primeros son código; el cuarto necesita una clave que este entorno no
tiene — se pide al usuario al final.

### 1. El antimuestrario ahora se MIDE, no solo se pide

`skill-anti-slop` (v4.17.0) le pide al modelo no usar emoji como icono de
interfaz. Pedirlo no es comprobarlo — el mismo fallo de fondo que ya
resolvió `generico.ts` para el resto de señas de "página genérica"
(relleno, tarjetas clonadas, radio uniforme…). Nueva seña, `iconos-emoji`:
mide en el DOM pintado botones/enlaces cuyo ÚNICO contenido es un emoji
del bloque real de emoji (`\u{1F300}-\u{1FAFF}`, no el de símbolos
clásicos como ★ o ☰, que sí tienen precedente legítimo como iconografía y
habrían disparado falsos positivos). Comparte el mismo barrido del DOM que
ya hace el resto del medidor — cero coste extra.

### 2. `tools-probe.ts` deja de ser ciego

El probe solo comprueba que el proveedor ACEPTA el parámetro `tools` (un
código HTTP) — nunca si el modelo va a rellenar `tool_calls` de verdad.
nvidia/nemotron pasa el probe como "sí soporta tools" y aun así entrega su
propia plantilla en texto (`tool-calls-texto.ts`, v4.15.0). El probe, por
sí solo, nunca podría haberlo sabido: hace falta una generación REAL.

`llamadas-texto-medidas.ts` (mismo patrón reactivo y con caducidad que
`limites-medidos.ts`, pero a 30 días — esto es un rasgo del modelo, no un
cupo que se repone cada hora) anota, cuando el fallback de v4.15.0
reconoce y ejecuta de verdad una llamada en texto, que ESTE modelo lo
hace. Deliberadamente NO toca `ToolsSupport` ni `supportsTools()`: el
modelo sí soporta tools (el fallback las ejecuta), apagarlas sería peor
que la plantilla en texto. Es información aparte — `mensajeLlamadaComoTexto()`
la explica sin decir "no soporta tools", que sería mentira.

### 3. Una ventana de contexto real, cuando ya se sabe

El HUD de contexto y el recorte proactivo (v4.14.0) usaban SIEMPRE la
ventana de referencia genérica (`ventanaCtx`, 32k de fábrica) — aunque
`limites-medidos.ts` YA supiera, de un rechazo real de un proveedor
anterior («Limit 7000, Requested 21138»), que ESTE modelo admite mucho
menos. Dos fuentes de verdad que no se hablaban.

`ventanaReferencia()` (`ctx-hud.ts`) las junta: si hay un límite real
aprendido, fresco, y MÁS PEQUEÑO que la ventana configurada, gana el real.
Nunca al revés — un límite aprendido nunca ENSANCHA la ventana, solo la
ajusta cuando hay un dato mejor que adivinar. Wired en los dos sitios que
ya consumían la ventana genérica: el recorte proactivo de
`use-generation.ts` (con el primer candidato de la cadena, `chain[0]`,
que es el que se va a intentar primero) y el HUD visible del compositor
(`chat-app.tsx`, con el modelo de la sesión activa).

### Pruebas

- `generico.ts`: 1 unitario nuevo (botón con emoji único no es seña; dos
  sí) + 1 E2E (`iconos-emoji.spec.ts`, con `mock-iconos-emoji`: mide de
  verdad en la página pintada, pide SVG, y la segunda entrega llega
  corregida).
- `llamadas-texto-medidas.ts`: 6 unitarios (nunca visto, visto y fresco,
  caducado, borde exacto de la vigencia, mensaje sin nada visto, mensaje
  que NO dice "no soporta tools") + 1 unitario en `agent-tools-loop.test.ts`
  (el fallback de verdad anota, no solo se detecta) + la E2E de
  `llamada-en-texto.spec.ts` ampliada para comprobar la anotación en
  `localStorage` tras una interacción real con `mock-llamada-en-texto`.
- `ventanaReferencia`: 6 unitarios (sin nada aprendido, límite real más
  pequeño gana, nunca ensancha, sin número del proveedor no hay nada que
  ajustar, caducado se ignora, sin ventana configurada cae al defecto) + 1
  E2E (`ventana-real-aprendida.spec.ts`: misma sesión y matemática que
  `recorte-proactivo.spec.ts`, pero con la ventana CONFIGURADA en el
  default genérico —con la que sola nunca llegaría a zona roja— y un
  límite APRENDIDO de 1.000 tokens sembrado en `prism-limites-v1`: el
  recorte se dispara igual, demostrando que usó el real).
- Verificado en rojo los tres, cada uno por separado: revertido solo el
  archivo de wiring de cada fix (`git stash` de `generico.ts`,
  `use-agent-tools.ts`, y el trío `ctx-hud.ts`+`use-generation.ts`+
  `chat-app.tsx`), confirmado que las pruebas nuevas fallaban por la razón
  correcta, restaurado y confirmado en verde antes de seguir con la
  siguiente.

### Lo que sigue sin cubrir

- **Ninguno de los tres tiene todavía una superficie en la UI.**
  `iconos-emoji` solo se le devuelve al MODELO (como el resto de señas de
  `generico.ts`); `llamadas-texto-medidas.ts` no tiene ningún panel que
  enseñe «este modelo pide tools como texto» (existe `mensajeLlamadaComoTexto()`
  ya escrito para cuando lo haya, pero no está enganchado a nada visible);
  la ventana real aprendida se USA pero no se distingue visualmente de la
  configurada en el HUD (el número es correcto, pero no dice «esto es un
  dato real, no una estimación»). Los tres son mejoras de DATOS, no de
  interfaz — construir esa interfaz es la extensión natural, no se hizo
  aquí para no mezclar tres cambios de lógica con tres paneles nuevos en
  la misma entrega.
- `ventanaReferencia` en el recorte proactivo usa `chain[0]` (el primer
  candidato) como referencia. En modo Auto con varios candidatos, si el
  primero tiene un límite real muy distinto de los siguientes, el recorte
  se calcula para el primero — razonable (es el que se va a intentar), 
  pero no tiene en cuenta que Auto pueda saltar a otro candidato después.
- `iconos-emoji` solo reconoce el bloque de emoji "real"
  (`\u{1F300}-\u{1FAFF}`) para evitar falsos positivos con símbolos como
  ★ o ☰. Un emoji fuera de ese bloque usado como icono (poco común, pero
  posible) no se detecta — la misma decisión, con el mismo motivo, que
  `emojiEnTitulos` ya tomaba.
- Sigue sin haber un cuarto arreglo: **nada de esto se probó con un
  modelo de pago real**. Este entorno no tiene ninguna clave de API
  configurada (solo `.env.example`) — todo lo de hoy, como el resto de la
  sesión, se verificó con `mock-llm`. Si el usuario quiere que esto se
  pruebe de verdad contra OpenRouter, AiHubMix o el proveedor que use,
  hace falta que pegue una clave en Ajustes → Proveedores (o la comparta
  para esta sesión) — no hay forma de hacerlo sin eso.

### Puerta

- ✓ lint · ✓ knip (sin huecos en los archivos nuevos) · ✓ tsc
- ✓ **1 912** unitarios (1 898 antes) · ✓ **249** E2E (247 antes), suite
  completa
- ✓ build · ✓ `npm start` + `/api/version` (`4.18.0`) · ✓ `VERCEL=1` sin
  `standalone` y con el `.nft.json`

## v4.19.0 — "Se detiene mucho solo": la conexión muerta que nunca avisaba

El usuario mandó una captura real desde el móvil: DeepSeek vía NVIDIA NIM,
modo agente, 90 segundos de espera y la burbuja congelada en
"Razonamiento del modelo: ¡Ah, un g" — cortado a media palabra, sin
avisar, sin reintentar. *"Se detiene mucho solo"*.

### El primer diagnóstico, descartado con el propio código

La primera hipótesis fue que faltaba el aviso "el modelo se quedó
razonando sin escribir nada, prueba otro modelo". Al ir a escribirlo,
`decisiones.ts:248-258` (`decidirTrasVacio`) y su mensaje en
`use-generation.ts:1097-1099` YA EXISTEN — desde v4.5.0, mucho antes de
esta sesión. Si la captura no lo mostraba, el problema no era que faltara
el aviso: era que ese código nunca llegaba a ejecutarse.

### La causa real: un `await` que no vuelve nunca

`readSSE()` (`chat-client.ts`) lee el stream con un bucle `for(;;) { await
reader.read(); ... }` sin ningún límite de tiempo. Si la conexión muere a
media transmisión —lo típico de móvil + VPN: la red mata una conexión
"callada" sin cerrarla limpiamente, y más con un modelo de razonamiento,
que puede pasar tramos enteros pensando sin mandar ni un byte—,
`reader.read()` se queda esperando PARA SIEMPRE. El `await
runWithTools(...)` de `use-generation.ts` nunca vuelve, así que todo lo
que viene después —la detección de respuesta vacía, el aviso, el
failover a otro modelo— nunca se ejecuta. No es que el código no supiera
qué decir: es que nunca llegaba a decirlo.

### El arreglo: un techo al HUECO, no al tiempo total

`INACTIVIDAD_STREAM_MS` (45s): si no llega NINGÚN byte en ese hueco, se
cancela el reader y se lanza un error claro, que cae en el mismo
try/catch de `use-generation.ts` que ya maneja cualquier fallo de red
—mismo reintento, mismo failover a otro modelo, misma marca de salud del
modelo, todo ya construido y probado—. Deliberadamente NO es un tope al
tiempo TOTAL: un modelo de razonamiento que tarda 90s de verdad, pero
sigue mandando trozos, no se toca. Solo se corta el silencio.

### Pruebas

- 2 unitarios nuevos en `chat-client.test.ts`: una conexión que manda un
  trozo y luego se queda muda de verdad (con `vi.useFakeTimers()` y un
  `ReadableStream` cuyo `pull()` nunca resuelve tras el primer trozo)
  rechaza con un error claro en vez de colgarse; una conexión que manda
  trozos con retraso pero SIN llegar al hueco de inactividad no dispara
  nada — solo importa el hueco sin datos, no cuánto tarda en total.
- Verificado en rojo con las DOS pruebas, no una: revertido solo
  `chat-client.ts` y ambas colgaron hasta el timeout de vitest (5s) —la
  prueba más directa posible de que sin el arreglo esto se cuelga para
  siempre, que es exactamente lo reportado. Restaurado, verde en 52ms.
- Al escribir el mock del stream para el test, un primer intento tenía un
  bug real: `pull()` volvía a encolar el mismo trozo CADA VEZ que se
  llamaba (en vez de solo la primera), lo que disparó un bucle activo al
  100% de CPU en el propio test runner. Corregido llevando un índice
  fuera de `pull()` y devolviendo una promesa que nunca resuelve para
  representar honestamente "la conexión sigue abierta pero no manda
  nada" — documentado aquí porque revela lo fácil que es simular mal un
  stream colgado.

### Lo que sigue sin cubrir

- No hay E2E para esto: simular una conexión que se queda muda de verdad,
  con Playwright contra `mock-llm`, sin que el test se vuelva lento o
  frágil, no compensaba frente a la prueba unitaria con timers falsos
  (determinista, 52ms, reproduce el hueco exacto sin esperar 45s reales).
- El umbral (45s) es un número razonable, no medido contra tráfico real
  de ningún proveedor — si algún modelo de razonamiento legítimo tiene
  huecos más largos que eso entre trozos, se cortaría de más. No hay
  forma de saberlo sin más reportes reales.
- El resto del hilo con el usuario (más de un modelo configurado, probar
  sin VPN) sigue sin confirmarse — quedó respondido "no lo he probado"
  para la parte de la red. Si el corte sigue pasando incluso con el
  arreglo, el siguiente dato a pedir es si fue con o sin VPN.

### Puerta

- ✓ lint · ✓ knip (sin huecos nuevos) · ✓ tsc
- ✓ **1 914** unitarios (1 912 antes) · ✓ **249** E2E, suite completa
- ✓ build · ✓ `npm start` + `/api/version` (`4.19.0`) · ✓ `VERCEL=1` sin
  `standalone` y con el `.nft.json`

## v4.20.0 — Web Studio: el usuario trajo el código, aquí se revisó y se cerró la puerta

El usuario subió un ZIP ("prism-ai-4.20-web-studio") con cambios hechos
fuera de esta sesión y pidió revisar y subir a `main`. La propia
`docs/PLAN-V9-WEB-STUDIO.md` que traía el ZIP lo decía con toda honestidad:
*"no fue posible ejecutar la suite completa [...] no se afirma que lint,
build o test hayan pasado"*. Así que esta entrada es esa verificación
pendiente, hecha aquí.

### Qué trae Web Studio

Una superficie nueva en la barra lateral que junta cuatro piezas, todas
reutilizando sistemas que Prism YA tenía (nada de memoria, navegador, QA
o router nuevos, tal como dice el propio plan):
- **`web-studio.ts`**: arma un prompt especializado (Brief → Plan → Build
  → QA → Fix → Regression → Publish) que obliga al agente a inspeccionar
  el proyecto existente antes de tocar nada y a no afirmar que algo pasó
  una prueba sin haberla medido.
- **`project-health.ts`**: una puntuación derivada de señales que YA
  existen (mapa del proyecto, Visual QA, memoria de fallos, HTML). Sin
  dato, el componente enseña `null` → la UI pinta «—», nunca un 0/100 o
  100/100 inventado.
- **`security-center.ts`**: un escáner estático LOCAL (nunca manda el
  código a ningún sitio) de patrones conocidos — secretos incrustados,
  HTTP sin cifrar, `eval`, `innerHTML`, scripts externos —, con un
  disclaimer explícito de que es diagnóstico, no una auditoría.
- **`project-tasks.ts`**: un tablero Pendiente/En curso/Hecha persistido
  en local, donde los hallazgos de QA y seguridad pueden convertirse en
  tareas automáticamente.
- **`prism-studio-dialog.tsx`**: la superficie que junta las cuatro,
  abierta desde «Web Studio» en la barra lateral.

### Lo que se encontró al revisar de verdad

- **Un fallo de seguridad real**: el iframe oculto donde Security Center
  y Visual QA miden el HTML no llevaba el atributo `sandbox` que sí
  llevan los otros dos iframes de vista previa del proyecto
  (`preview-panel.tsx`, `sandbox-studio.tsx`: `allow-scripts
  allow-forms allow-modals allow-popups allow-pointer-lock`, siempre SIN
  `allow-same-origin`). Sin `sandbox`, un `srcDoc` corre en el mismo
  origen que la propia app — cualquier JS en el HTML medido habría
  podido leer el `localStorage` de Prism, donde viven las claves de API.
  Añadido, igual que en los otros dos.
- **Dos errores de `tsc` reales**: `sidebar.tsx` declaraba
  `onOpenStudio?: () => void;` en el tipo de las props pero nunca lo
  desestructuraba de los parámetros del componente — el botón "Web
  Studio" de la barra lateral literalmente no podía compilar. Y
  `project-tasks.ts` perdía el tipo literal `TaskStatus` al construir la
  tarea nueva (`status: "todo"` se ensanchaba a `string` dentro del
  objeto), rompiendo el store.
- **`project-tasks.ts` sin el envoltorio de la casa para `localStorage`**:
  usaba `createJSONStorage(() => localStorage)` en vez de
  `safeLocalStorage()` (el que ya usan `limites-medidos.ts` y
  `llamadas-texto-medidas.ts`), y le faltaba `"use client"` — el único de
  los cuatro módulos nuevos que de verdad toca el navegador. Corregido
  para que quede protegido igual que el resto de stores persistidos.
- Un import muerto (`X` de lucide-react, nunca usado) y un `(list as
  any[])` en la pestaña de tareas, sustituido por una tupla `as const`
  tipada de verdad.

### Pruebas

- Los 6 unitarios que ya traía el ZIP (`project-health.test.ts`,
  `security-center.test.ts`, `web-studio.test.ts`) pasan tal cual, sin
  tocarlos.
- 4 E2E nuevos (`web-studio.spec.ts`), probados primero a mano en el
  navegador real (`npm run dev`, clic real en la barra lateral) antes de
  escribirlos: abre desde la barra lateral y Health enseña «—» sin
  datos, en vez de una puntuación inventada; el iframe de medición SÍ
  lleva el `sandbox` correcto (la prueba directa del fallo de seguridad
  que se corrigió); Security Center analiza y siempre enseña el
  disclaimer; Project Tasks añade una tarea, la mueve de Pendiente a En
  curso y el contador de cada columna se actualiza.

### Lo que sigue sin cubrir

- El propio plan ya lo dice: el tablero de tareas no está conectado
  todavía al `AgentTrace` ni a los resultados de regresión — las tareas
  que crea QA/Security quedan sueltas, no enlazadas a la iteración del
  agente que las originó.
- `security-center.ts` es deliberadamente conservador (cinco patrones
  regex, con su propio disclaimer de que no es una auditoría) — no se
  amplió el catálogo de reglas en esta revisión, solo se verificó que lo
  que ya trae funciona y no miente sobre su alcance.
- No se probó `web-studio.ts` (`buildWebStudioPrompt` → "Iniciar con
  agente") contra un modelo real: el prompt se construye y se comprobó
  que llega al compositor con el modo agente encendido, pero seguir el
  flujo completo hasta una generación real requiere una clave de API que
  este entorno no tiene (mismo límite que el resto de la sesión).

### Puerta

- ✓ lint · ✓ knip (sin huecos nuevos) · ✓ tsc (limpio tras corregir los
  dos errores reales)
- ✓ **1 920** unitarios (1 914 antes) · ✓ **253** E2E (249 antes), suite
  completa
- ✓ build · ✓ `npm start` + `/api/version` (`4.20.0`) · ✓ `VERCEL=1` sin
  `standalone` y con el `.nft.json`

## v4.20.1 — Web Studio en el teléfono: un desborde real y una teoría que no lo era

El usuario, tras probar la v4.20.0 en el móvil: *"El nuevo módulo no se
adapta bien al teléfono"*. QA visual real a 320/390/768px (Playwright con
el Chromium de este entorno, no capturas de pantalla adivinadas)
confirmó el reporte: en el diálogo de Web Studio, la fila de nueva tarea
de la pestaña Tasks se quedaba con un campo de texto de apenas 68px de
ancho — ilegible, el placeholder recortado a "Nuev" — y las cuatro
pestañas (Overview/QA/Security/Tasks) se apretaban sin separación visible
entre sí a ese ancho.

### La teoría que no sobrevivió a la medición

La primera hipótesis, antes de medir con precisión, fue la clásica de
Grid/Flexbox: que el stepper de 7 etapas (fila con `overflow-x-auto` y
botones `min-w-max`) forzaba a su contenedor — la tarjeta "Workflow", un
elemento de la rejilla `grid-cols-[1.6fr_1fr]` — a crecer más de la
cuenta, empujando el propio diálogo fuera de la pantalla. Se añadió
`min-w-0` a esa tarjeta y a la de Project Health como arreglo preventivo.

Pero al escribir el test E2E permanente y medirlo de verdad (no solo
mirar una captura) — comparando `scrollWidth` contra `clientWidth` del
propio `[data-slot="dialog-content"]`, que revela el ancho de contenido
real aunque `overflow-hidden` lo esté recortando visualmente — el
resultado fue el mismo con y sin el `min-w-0`: sin desborde interno, ni
antes ni después. La explicación real: la fila del stepper ya lleva
`overflow-x-auto`, y un elemento con `overflow` distinto de `visible` es,
por la propia especificación de CSS Sizing, un contenedor de scroll — su
tamaño mínimo automático que cuenta para el layout de SUS ancestros pasa
a ser 0, no el ancho de su contenido. La fila ya se protegía a sí misma;
no había nada que min-w-0 tuviera que arreglar ahí. El `min-w-0` en las
dos tarjetas se dejó de todos modos (es inofensivo y documenta la
intención), pero el desborde real vivía en otro sitio.

### El fallo real, confirmado con test rojo-antes-de-verde

`git stash` del único archivo de origen tocado
(`prism-studio-dialog.tsx`) y una vuelta del test nuevo contra el código
de la v4.20.0 sin el arreglo: **falla exactamente donde debía** —
`ancho del campo de nueva tarea: esperado > 100, recibido 68.359375` a
320px. La fila de la pestaña Tasks (`<div className="mb-3 flex
gap-2">` con el input y el botón "Añadir" codo a codo) no tenía dónde
encoger: sin `flex-wrap` ni `min-w-0` en el campo, el botón de al lado se
quedaba con su ancho natural y el input se comía lo que sobraba, que a
320px era casi nada.

Arreglo, ya con el `git stash pop`:
- La fila pasa a `flex flex-wrap gap-2`: si no cabe todo junto, el botón
  baja de línea en vez de aplastar el campo.
- El `<Input id="prism-task-input">` lleva `min-w-0 flex-1 basis-40`:
  encoge por debajo de su ancho natural (el `min-w-0` que si hacía
  falta, aquí sí) y no baja nunca de 160px salvo que el flex-wrap ya haya
  liberado espacio.
- Las cuatro `TabsTrigger` bajan de `text-sm` a `text-[11px] px-1`: a
  ese tamaño, las cuatro etiquetas (Overview/QA/Security/Tasks) dejan de
  tocarse entre sí a 320-390px.

### Un hallazgo lateral: el falso desborde del menú móvil

El primer intento del test nuevo daba positivo en TODOS los anchos, pero
por un motivo ajeno al diálogo: por debajo del breakpoint `lg`, la barra
lateral vive dentro de un `Sheet` (hoja deslizante) que hay que abrir con
el botón de hamburguesa antes de llegar al botón "Web Studio" — y al
cerrarse tras el clic, sus nodos quedan a mitad de la animación de salida
(con posiciones negativas, fuera de la pantalla) en el instante exacto en
que el test medía. Se añadió una espera explícita a que
`[data-slot="sheet-content"]` desaparezca del DOM antes de medir. Sin
esa espera, el test habría sido un falso positivo constante, no una
medición real del diálogo.

### Pruebas

- `tests/e2e/web-studio.spec.ts`: 3 tests nuevos (`Web Studio sin
  desbordes a 320/390/768px`), cada uno comprobando cuatro cosas —
  `document.documentElement.scrollWidth === clientWidth` (sin scroll
  real de página), ningún elemento visible fuera del viewport que no
  esté recortado a propósito por un ancestro, el borde derecho del
  diálogo dentro del viewport, y `dialog.scrollWidth === clientWidth`
  (sin desborde interno aunque esté recortado) — más una quinta
  comprobación específica: el campo de nueva tarea mide más de 100px.
  Rojo confirmado antes del arreglo (falla en el campo de tarea a
  320px, verde en 390/768 porque a esos anchos el campo ya tenía sitio
  de sobra), verde después en los tres.

### Lo que sigue sin cubrir

- No se verificó visualmente en un dispositivo físico, solo en Chromium
  headless con viewport forzado — el comportamiento de teclado virtual
  en iOS/Android (que puede reducir la altura visible y no el ancho) no
  se prueba aquí.
- El `min-w-0` de las tarjetas Workflow/Health queda como higiene
  preventiva, no como arreglo de un fallo medido — si algún día esa fila
  deja de tener `overflow-x-auto`, el argumento de esta entrada deja de
  aplicar y habría que revisar de nuevo.

### Puerta

- ✓ lint · ✓ knip (mismo ruido preexistente, nada nuevo en los dos
  archivos tocados) · ✓ tsc limpio
- ✓ **1 920** unitarios · ✓ **256** E2E (253 antes + 3 nuevos), suite
  completa
- ✓ build · ✓ `npm start` + `/api/version` (`4.20.0` antes del bump) ·
  ✓ `VERCEL=1` sin `standalone` y con el `.nft.json`

## v4.21.0 — Dos ZIPs más, un Web Studio distinto: se porta la idea, no el código

El usuario subió dos actualizaciones más: `prism-ai-4.21.0-next-level.zip`
y `prism-ai-4.22.0-verified-cycle.zip`. Antes de tocar nada, revisar de
dónde partían: el `worklog.md` de los dos ZIPs se corta en la v4.19.0 —
es decir, ambos se construyeron ANTES de que la v4.20.0 (Web Studio:
Project Health, Security Center, Project Tasks, con su arreglo móvil en
la v4.20.1) llegara a `main`. Quien los generó no sabía que Web Studio ya
existía.

El resultado: los dos ZIPs reinventan "Web Studio" desde cero, con otro
nombre de archivo (`web-studio-dialog.tsx` + `project-workflow.ts`, en
vez de `prism-studio-dialog.tsx` + `web-studio.ts`), y **borran** los
cuatro módulos ya enviados (`project-health.ts`, `security-center.ts`,
`project-tasks.ts`, `web-studio.ts`) si se aplican tal cual. Su versión
es más simple: pierde el scoring de Health basado en evidencia, el
tablero de tareas persistente (las suyas son un `useState` en memoria,
se pierden al cerrar el diálogo) y el arreglo de móvil ya probado.

Sí traían una idea real y buena, explícita en su propio plan
(`PLAN-V11-VERIFIED-CYCLE.md`): que el QA de Web Studio "reutilice el
motor de Preview que ya existe" en vez de medir en un iframe aparte.
Consultado el usuario sobre cómo reconciliar los dos caminos — reemplazar
lo ya enviado, portar solo la idea, o revisarlo con más detalle antes de
decidir — eligió portar solo la idea y mantener lo ya enviado.

### Lo que se cambió

`PreviewPanel` (`preview-panel.tsx`) pasa a `forwardRef` y expone, por
`useImperativeHandle`, un método `runVisualQA()` que corre exactamente el
mismo `runVisualQA(iframeRef.current, QA_WIDTHS)` que ya usaba
internamente su propio botón de QA — solo que ahora un padre puede
pedirlo desde fuera, sobre el iframe EN VIVO que el usuario ya está
mirando, en vez de que `PrismStudioDialog` tenga que montar un segundo
iframe oculto y volver a renderizar/ejecutar la página desde cero.

`chat-app.tsx` mantiene un único `previewPanelRef` compartido entre las
dos instancias de `PreviewPanel` (escritorio y hoja móvil) — solo una
está montada a la vez — y se lo pasa a `PrismStudioDialog` como
`onRunVisualQA`.

`prism-studio-dialog.tsx`: `runQA()` ahora prueba primero
`onRunVisualQA()`; si vuelve vacío (la vista previa no está montada — el
usuario la cerró, o Web Studio se abrió sin haber abierto antes una
vista previa), cae al iframe propio de siempre. El iframe oculto no se
quitó: sigue siendo el respaldo, y sigue llevando su `sandbox` sin
`allow-same-origin`.

### Un límite honesto de lo que se pudo probar

Un test E2E de caja negra no puede distinguir CUÁL de los dos iframes
midió realmente — ambos acaban midiendo el mismo HTML de la sesión y
producen el mismo resultado visible. Lo que SÍ se probó, con dos tests
nuevos: que el QA sigue funcionando de principio a fin con la vista
previa abierta, y que sigue funcionando igual de bien cuando está
cerrada (cae al camino de respaldo). La prueba de que el camino correcto
se usa en cada caso es de lectura del propio diff (`onRunVisualQA`
antes que el iframe propio) y de `tsc`, no de una medición externa.

### Un falso positivo por el camino

El primer intento de los dos tests nuevos fallaba con la vista previa
YA abierta: pensé que el flag de demo (`prism-preview-demo=1` en
localStorage) rellenaba `previewCode` solo con ponerlo, como en otros
tests del archivo — pero ese flag solo evita que la demo se REPITA, no
sustituye a tener contenido real. Sin sesión real, `html` es `null` y el
botón "Ejecutar Visual QA" queda deshabilitado. Corregido sembrando una
sesión completa con un mensaje de asistente que trae HTML real (mismo
patrón que ya usa `download.spec.ts`), en vez de depender del flag de
demo.

### Pruebas

- `tests/e2e/web-studio.spec.ts`: 2 tests nuevos. Uno con una sesión
  real y la vista previa de escritorio abierta sola (el ancho por
  defecto de Playwright está por encima del corte de "estrecha"):
  ejecuta el QA y comprueba que llegan resultados reales para 320 y
  390px. El otro cierra la vista previa primero y comprueba que el QA
  sigue funcionando igual — la prueba directa de que el respaldo no se
  rompió.

### Lo que sigue sin cubrir

- Como ya se dijo: no hay forma de comprobar desde fuera cuál de los dos
  iframes sirvió cada medición concreta — solo que ambos caminos siguen
  dando resultado.
- El resto de las dos ZIPs (`project-workflow.ts`, `WebStudioDialog`,
  la reescritura entera de la superficie) se descartó: es una versión
  más pequeña de lo que ya está en `main`, construida sin saber que
  existía.

### Puerta

- ✓ lint · ✓ knip (mismo ruido preexistente) · ✓ tsc limpio
- ✓ **1 920** unitarios (sin cambios) · ✓ **258** E2E (256 antes + 2
  nuevos), suite completa
- ✓ build · ✓ `npm start` + `/api/version` (`4.20.1` antes del bump) ·
  ✓ `VERCEL=1` sin `standalone` y con el `.nft.json`

## v4.22.0 — Un cuarto ZIP traía ejecución remota sin autenticar: se descartó

El usuario subió `prism-ai-4.24.0-real-runtime.zip`. Mismo patrón que los
dos anteriores: su `worklog.md` se corta en la v4.19.0, así que se
construyó sin saber que la v4.20.0–v4.21.0 ya estaban en `main`. Antes de
aplicar nada, se revisó archivo por archivo contra el estado actual del
repo.

### Lo que traía y por qué se descartó la mitad

La pieza central era una ruta nueva, `/api/prism-web/runtime`: recibe
`{path, content}[]` arbitrarios desde el cliente, los escribe en un
directorio temporal, corre `npm ci/install --ignore-scripts` (esa parte
sí estaba bien protegida) y después `spawn("npm", ["run", <dev|start|
preview>], { cwd, env: { ...process.env, ... } })` — **sin ninguna
comprobación de autenticación en el `POST`**, pasando el entorno
COMPLETO del servidor (todas las claves y secretos) al proceso hijo, y
sin ningún aislamiento de contenedor o VM (el propio doc del ZIP admitía
que ese aislamiento "aún no existe"). Cualquiera que pudiera golpear esa
ruta ejecutaba código arbitrario en el servidor con las claves del
servidor a mano.

Peor: el ZIP no dejaba esto como algo opcional. Su parche a
`sandbox-runner.ts` redirigía la función YA EXISTENTE y ya confiada
`runProject()` — la que usa hoy el botón "Ejecutar" del Sandbox,
`visual_review`, y cualquier futuro `verify_project` — a este runtime
nuevo en cuanto detectaba `files["package.json"]`. Aplicar el ZIP tal
cual no habría añadido una función de riesgo aparte: habría comprometido
TODOS los caminos que ya confían en `runProject()`. Esto contradice
directamente el modelo de seguridad establecido de la app: iframe
sandboxed (`sandbox="allow-scripts…"` sin `allow-same-origin`), nunca
ejecución del lado del servidor.

Consultado el usuario con `AskUserQuestion` dado lo grave del hallazgo,
la respuesta fue clara: descartar el runtime por completo, revisar el
resto del ZIP por si traía algo aprovechable. Ni la ruta `runtime/
route.ts`, ni el parche a `sandbox-runner.ts`, ni la redirección de
`runProject()` se tocaron — no existen en el repo.

También se descartaron, por redundancia o alcance: el diff de
`preview-panel.tsx` (partía de la versión SIN `forwardRef`, ya
sustituida en la v4.21.0 — aplicarlo habría deshecho ese trabajo) y
`prism-web.ts` (un sistema nuevo de 8 "modos" de prompt que se solapa
con `web-studio.ts` ya existente, sin que se pidiera).

### Lo que sí se portó: `verify_project`

El ZIP también proponía una idea real, separable del runtime: que el
agente pudiera pedir una verificación INDEPENDIENTE del proyecto — no
solo confiar en que "el código parece correcto" — combinando comprobaciones
estáticas con evidencia real de ejecución y de QA visual.

- `web-verifier.ts` (nuevo): función pura `verifyWebProject(files,
  runtime?)`, sin dependencia de ejecución propia. Revisa HTML (`lang`,
  `title`, `viewport`, `alt` en imágenes, nombres accesibles), enlaces
  locales rotos, y patrones de secretos filtrados; y solo si se le pasa
  evidencia de runtime (`executed`, `errors`) y de QA marca
  `runtimeChecked`/`visualChecked`. `passed: true` exige AMBOS. Copiado
  del ZIP tal cual — es una función pura, sin ningún vínculo con el
  runtime descartado.
- Tool `verify_project` (`tool-runner.ts`): llama a `ctx.runProject({qa:
  true})` — el mismo camino seguro, en iframe sandboxed, que ya usan
  `run_project` y `visual_review` — y alimenta su resultado a
  `verifyWebProject()`. Nunca toca el runtime del servidor; ese camino
  ni siquiera existe en el repo.
- Regla nueva en `agent-loop.ts`: el ZIP proponía una regla "no marques
  pass sin evidencia", pero su propio parche numeraba mal la lista
  (repetía "2."). Se corrigió añadiéndola como regla 7, al final, sin
  arrastrar el bug de numeración del ZIP.
- Guarda de `..`/rutas absolutas (`projectPath()`) para `read_file`,
  `write_file`, `apply_patch`, `edit_file`, `list_files`. Hoy
  `projectFiles` es un mapa en memoria sin disco real detrás, pero una
  clave con `..` sigue siendo una confusión de límites en cuanto se use
  para exportar un ZIP o empujar a GitHub — higiene barata, se portó.

### Tres listas exhaustivas de nombres de tools, tres sitios

Convención de la casa (comentario en `tools-catalog.ts`): si se añade
una tool, hay que actualizar su test. Hay TRES sitios que comprueban la
lista completa y ordenada de nombres, no uno: `tests/unit/
tools-catalog.test.ts`, `tests/unit/tool-permissions.test.ts` — los dos
encontrados al correr los unitarios — y `tests/e2e/tools-agente.spec.ts`,
que solo salió a la luz al correr la suite E2E COMPLETA (fallaba en el
test 225 de 259, tras confirmar 224 en verde). Los tres se actualizaron
para incluir `verify_project`.

### Pruebas

- `tests/unit/web-verifier.test.ts` (nuevo, 3 tests): PASS con proyecto
  limpio, hallazgos de `alt`/enlace roto/secreto filtrado, y que
  `runtimeChecked`/`visualChecked` solo se marcan con evidencia real.
- `tests/unit/tool-runner.test.ts`: +5 tests de rutas (`..`, absolutas,
  `C:/`, bytes de control — todas rechazadas) y +4 de `verify_project`
  (sin Sandbox, ejecución fallida, hallazgos reales, limpio).
- `tests/e2e/verify-project.spec.ts` (nuevo): un modelo mock escribe una
  página rota (`<img>` sin `alt`, referencia local inexistente), llama
  `verify_project`, ve NO PASS con los hallazgos reales, escribe la
  versión corregida, vuelve a llamar `verify_project` y esta vez ve
  PASS con `runtime=sí, visual=sí`. Primer intento falló dos veces: el
  regex buscaba el `id` del hallazgo (`img-alt`) en vez del texto que de
  verdad se renderiza (`summarizeVerification` imprime `f.message`); y
  la página "corregida" del mock seguía citando un `<img>` que nunca se
  escribió como archivo, así que seguía dando NO PASS después del
  "arreglo". Corregido el regex y quitada esa imagen de la versión
  corregida del mock.

### Puerta

- ✓ lint · ✓ knip (mismo ruido preexistente) · ✓ tsc limpio
- ✓ **1 932** unitarios (1 920 + 12 nuevos) · ✓ **259** E2E (258 antes +
  1 nuevo), suite completa
- ✓ build · ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin
  `standalone` y con el `.nft.json`

## v4.23.0 — Tres ZIPs más, la misma ruta sin autenticar otra vez descartada

El usuario subió tres ZIPs seguidos: `prism-ai-4.25.0-verified-autofix.zip`,
`prism-ai-4.26.0-actionable-diagnostics.zip` y
`prism-ai-4.27.0-direct-code-repair.zip`. Mismo patrón que los anteriores
—`worklog.md` cortado en la v4.19.0—, y los tres traían, byte a byte
IDÉNTICA, la misma ruta `/api/prism-web/runtime` sin autenticar (RCE con
el entorno completo del servidor) que ya se descartó en la v4.22.0.
Confirmado con el usuario, se descartó otra vez — no hubo que revisarla de
nuevo, era el mismo archivo.

El ZIP 4.27 además proponía ELIMINAR `apply_patch` —la tool de parches
SEARCH/REPLACE en producción desde la v4.0, usada en 8 archivos, con sus
propios tests— y sustituirla por edición directa con `read_file`+
`edit_file`. Su propio doc admitía no haber podido correr su suite para
validar el cambio. Revisado el `worklog.md` del propio proyecto: `apply_patch`
nunca ha causado un bug documentado aquí; el argumento del ZIP («los parches
se desincronizan del archivo real») es genérico, no una observación real de
Prism AI. Consultado, se decidió NO quitarla — se porta solo lo nuevo y
seguro.

### Lo que sí se portó

- **`diagnose_project`** (tool nueva, `web-diagnostics.ts`): la misma
  verificación de `verify_project`, pero convertida en diagnóstico
  accionable — causa, acción recomendada, archivo candidato, criterio de
  cierre — en vez de solo PASS/NO PASS. No inventa líneas exactas; el
  agente sigue teniendo que leer el archivo antes de tocarlo. El ZIP
  añadía esto AL FINAL del `diagnostics.ts` YA EXISTENTE (una función sin
  relación: «Copiar diagnóstico» del proveedor/entorno) — se puso en un
  archivo nuevo (`web-diagnostics.ts`) en vez de mezclar dos funciones sin
  relación en el mismo módulo.
- **Auto-verificación tras mutación** (`use-agent-tools.ts`): tras
  cualquier `write_file`/`edit_file`/`apply_patch`, si el modelo no pidió
  `verify_project` en esa misma tanda, Prism lo hace por él y reinyecta la
  evidencia — el bucle pasa a ser editar → ejecutar → verificar → corregir
  sin que el modelo tenga que acordarse de pedirlo.

### Un bug de protocolo real en el propio ZIP, nunca detectado por sus tests

La auto-verificación del ZIP añadía el resultado de la llamada sintética
(`verify_project`) a la lista de resultados reinyectados, pero NO a la
lista de `tool_calls` que el mensaje `assistant` anuncia. Eso es un
mensaje `tool` cuyo `tool_call_id` el turno anterior nunca anunció — un
body inválido para la API real de OpenAI (rechaza con 400) y de Anthropic
(un `tool_result` sin `tool_use` correspondiente). El mock de pruebas del
propio ZIP no lo exige, así que su test («auto-verifies after a project
mutation») pasaba igual, sin que nadie lo notara. Corregido: la llamada
sintética se añade TAMBIÉN a `pendingToolCalls`, así que aparece en ambos
lados del turno, como haría una llamada real del modelo.

### Un segundo efecto colateral real, encontrado al correr `tools-medir.spec.ts`

`run_project`, `run_regression`, `verify_project` y `diagnose_project`
comparten a propósito `ctx.lastRun` — cualquier ejecución sirve de «antes»
para el siguiente `run_regression`, documentado así desde que existe
`run_project` (para que el modelo no tenga que preparar nada a mano). Pero
la auto-verificación es INVISIBLE para el modelo: si también fijara esa
referencia, la primera vez que el modelo llamara a `run_regression`
después de escribir un archivo, `run_regression` dejaría de decir «no
había ejecución anterior» — por una comparación que el modelo nunca pidió.
Esto lo detectó `tools-medir.spec.ts` (v3.40, ya en producción): su primer
`run_regression` espera exactamente ese mensaje, y con la auto-verificación
sin corregir dejaba de aparecer. Arreglado con un argumento interno
`silencioso` en `verify_project`: la auto-verificación sigue dando
evidencia real en su propio resultado, solo no se cuela como referencia
ajena para otra tool que el modelo no llamó.

### Pruebas

- `tests/unit/web-diagnostics.test.ts` (nuevo, 5 tests): causa/acción/
  candidato de un error de runtime, un hallazgo visual sin inventar línea,
  un secreto filtrado como `remove-secret`, proyecto limpio → `ready`,
  solo warnings → `needs-fix` (no bloqueado).
- `tests/unit/tool-runner.test.ts`: +4 tests de `diagnose_project` (sin
  Sandbox, fallo de runtime, hallazgos reales con archivo candidato,
  proyecto limpio → `ready`).
- `tests/unit/agent-tools-loop.test.ts`: +4 tests de la auto-verificación:
  se dispara sola tras una escritura; CADA `tool_result` reinyectado tiene
  su `tool_call` anunciado por el `assistant` (la prueba directa del bug
  de protocolo, arriba); no se duplica si el modelo ya llamó
  `verify_project`; no se dispara si la vuelta no mutó nada.
- `tests/e2e/diagnose-project.spec.ts` (nuevo): un mock escribe una imagen
  sin `alt`, diagnostica (`NEEDS-FIX`, con `index.html` como candidato),
  la arregla, vuelve a diagnosticar (`READY`). Primer intento con DOS
  `write_file` en la misma ronda con el mismo `id` (mismo nombre de tool):
  el cliente acumula por `id` al reensamblar el streaming y uno pisaba al
  otro, dejando el proyecto vacío a mitad de guion. Corregido pasando la
  imagen como `data:` URI (no necesita un segundo archivo) — y de paso
  documentado el porqué en el propio mock, para no repetirlo.
- Las tres tools medidoras de `run_project` ya en producción
  (`tools-medir.spec.ts`, `verify-project.spec.ts`, y las tres de
  `tools-agente.spec.ts`) se re-ejecutaron enteras tras el cambio: sin
  ellas no se habría visto ni el bug de `ctx.lastRun` ni si el catálogo
  ampliado seguía viajando entero.

### Puerta

- ✓ lint · ✓ knip (mismo ruido preexistente) · ✓ tsc limpio
- ✓ **1 945** unitarios (1 932 + 13 nuevos) · ✓ **260** E2E (259 antes +
  1 nuevo), suite completa
- ✓ build · ✓ `npm start` + `/api/version` · ✓ `VERCEL=1` sin
  `standalone` y con el `.nft.json`

## v4.24.0 — Forja Lab: un ZIP de 22 500 líneas, integrado y con una bala real encontrada

El usuario subió `forja-ia-v4.7.2-CORREGIDO.zip`: dos carpetas. `host-forja-ia/`
resultó ser el propio Prism AI, en un punto anterior a este mismo repo, bajo
su marca previa («Forja IA», antes del cambio a Prism AI) — comparado archivo
a archivo contra `main`, el 99% de las 401 diferencias eran solo texto de
marca (FORJA→Prism, el yunque→el prisma); se descartaron todas, no se
revierte el rebrand. Lo real: 10 archivos que `host-forja-ia` tenía y `main`
no — una página `/forja` (el «Estudio»), 5 componentes, `motor-client.ts` +
`lab-logica.ts`, y un bundle `motor-forja.mjs` de 1.87 MB. La segunda
carpeta, `forja-ia-v4.7.1/`, era el código fuente de ese bundle: 65 archivos,
22 514 líneas TypeScript — un motor de generación de páginas determinista
(ficha → maqueta → ADN visual → jueces con evidencia → anti-genérico →
composición), sin una sola llamada de red ni dependencia nueva, nunca antes
en este git.

### Qué se portó

- **Motor fuente completo** → `motor-forja/` (nueva carpeta en la raíz, fuera
  del build de Next: `tsconfig.json` y `eslint.config.mjs` la excluyen
  explícitamente). Es su propio sub-proyecto con su script de bundle
  (`integracion/adapter-test/construir-bundle.mjs`, esbuild), en vez de un
  blob opaco sin fuente versionada.
- **Forja Lab dentro de la app**: `src/app/forja/page.tsx` («El Estudio»,
  con Catálogo/Ficha→Maqueta/ADN/Jueces/Anti-genérico/Motor), los 5
  componentes de `src/components/forja/` y `motor-client.ts` (carga
  `/motor-forja.mjs` en runtime con `import()` dinámico, fuera de
  Turbopack). Entrada nueva «Forja Lab» en la barra lateral (`sidebar.tsx`)
  con Estudio y Ficha→Maqueta — sin tocar el logo, el `layout.tsx` ni
  `app-version.ts`, que sí traía el ZIP con la marca vieja.
- `AppSettings.maxTokensPorRol` (opcional) en `types.ts`: el componente ya
  lo leía (`cfg?.maxTokensPorRol?.[rol]`) pero el tipo no lo declaraba —
  `tsc --strict` lo habría rechazado en cuanto alguien lo usara con tipos.

### La bala real: el bundle entregado no era el que su propio código fuente produce

`entrada.mjs` —el fichero que declara qué exporta `motor-forja.mjs`— NO
incluía 16 de los 65 módulos del motor: `fuentes.ts`, `fuentes-usuario.ts`,
`conocimiento-global.ts`, `conocimiento-usuario.ts`, `director.ts`,
`arena.ts`, `representacion.ts`, `habilidades.ts`, `equipo.ts`, `modelo.ts`,
`adapter-opendesign.ts`, `voz.ts`, `canvas.ts`, `mejora-pagina.ts` y, el más
grave, **`composition-engine.ts`** — el módulo que el propio `CAMBIOS.md`
anuncia como la novedad de portada de ESTA MISMA versión (v4.7.2,
«Experience Composition»). El bundle que traía el ZIP nunca lo contenía:
`page.tsx` lee `motor.FUENTES_SEMILLA` para pintar el contador de fuentes
curadas en el Catálogo, y siempre habría mostrado 0 — sin crashear (hay
`?? []`), pero mintiendo en silencio sobre lo que el motor trae.

Corregido añadiendo las 16 exportaciones que faltaban a `entrada.mjs` (se
dejó fuera solo `autoaprendizaje.ts`, que hace lecturas de internet —
corresponde a una ruta de servidor, no al bundle del navegador) y
reconstruyendo con `construir-bundle.mjs`: el propio script trae un
post-chequeo de humo (`node --experimental` import del bundle) que confirmó
los 45 nombres críticos presentes y cero colisiones de `export *`. El bundle
nuevo son 479 exportaciones — antes 376 — y pesa 605 KB, un tercio de los
1.87 MB que traía el ZIP (ese tamaño no venía de más código: era el bundle
sin encoger de una build de desarrollo).

### Lo que NO se portó

- `integracion/api/forja/*` (rutas `chat`/`aprender`/`fuentes`/`estado`/
  `config`) y `integracion/forja-lab/` (`llamador.ts`, `arena-config.ts`):
  el propio `host-forja-ia` del ZIP —su implementación de referencia—
  tampoco las cableaba. Encienden un ciclo de aprendizaje que lee URLs de
  internet server-side; wirearlas es una decisión de producto aparte
  (¿quién paga esas llamadas, con qué límites, qué dominios se permiten),
  no una corrección de este ZIP.
- `integracion/PanelAprendizaje.tsx`: panel de administración de ese mismo
  ciclo, mismo motivo.
- `lab-logica.ts` (635 líneas): su propio comentario decía que existía para
  alimentar una página `/laboratorio` que consumiera esa lógica con el
  tema del host — esa página no estaba en ninguna parte del ZIP, ni en
  `host-forja-ia` ni en el módulo fuente. Decía además «reparar» un bug del
  `public/FORJA-IA-Laboratorio.html` estático (`veredictoDe`/`identidadDe`/
  `MECANICAS` perdidos por un `<title>` corrupto, `c1`/`c2` sin definir en
  el benchmark) — comprobado contra el `.html` que trae ESTA entrega: ya
  viene arreglado ahí mismo, el bug que describía es de una entrega
  anterior. Archivo sin consumidor y sin bug que reparar: no se sube (knip
  lo marcaba como fichero muerto).

### Revisado y sin hallazgos

- `ficha-tab.tsx` pinta la maqueta generada en un `<iframe sandbox=
  "allow-same-origin" srcDoc=…>`: sin `allow-scripts`, así que el HTML que
  el motor genera NO ejecuta JS dentro del iframe — no hay fuga hacia el
  `localStorage` de la app (ahí viven las claves API). No hacía falta
  tocarlo.
- `motor-tab.tsx` usa `dangerouslySetInnerHTML` para el «Objeto 3D
  forjado», pero el HTML/CSS viene de `objeto-3d.ts` (catálogo propio,
  determinista, sin texto de usuario ni de modelo) — no de una IA. Riesgo
  descartado.

### Puerta

- ✓ lint (`eslint .`, con `motor-forja/**` excluido — no comparte las
  reglas del host) · ✓ tsc limpio (`motor-forja` fuera de `include`)
- ✓ **1 945** unitarios, sin regresiones (los 4 previos + 0 nuevos: el
  motor de Forja Lab trae su propia suite de verificación determinista,
  fuera de Vitest, en `motor-forja/integracion/adapter-test/verificacion-*`)
- ✓ build (`next build`, `/forja` sale como ruta estática) · ✓ `npm start`
  sirvió `/`, `/forja` y `/motor-forja.mjs` con 200 y el bundle cargó en
  Node sin errores de import

## v4.25.0 — Forja Lab probado de verdad: la maqueta salía vacía siempre

El usuario pidió levantar el servidor de verdad y usar Forja Lab como
usuario real, no solo revisar código — «a ver si realmente crea una
página web sin necesidad de API». Se hizo con un navegador real
(Playwright/Chromium) contra `npm start`. Primer intento: pidió una
landing de panadería y salió SIEMPRE la misma maqueta — cabecera + 3
tarjetas genéricas («Hecho a mano» / «Con intención» / «A tu medida»),
sin usar una sola palabra del brief. El usuario ya había visto este
patrón «vacío» y avisó que llevaba 5 entregas intentándose corregir sin
éxito.

### La causa: el demo nunca llamaba al motor de contenido

`ficha-tab.tsx` (pestaña «Ficha → Maqueta» del Estudio) sí llama a
`ejecutarForja` de verdad, pero el «Codificador» de esa llamada era un
`mock()` local que devolvía `maquetaDesdeTokens()` — una plantilla HTML
fija con 3 tarjetas hardcodeadas, tokens de color aparte. El motor SÍ
tiene un sistema para esto desde v4.7 («La Página, no el Hero»):
`construirPlanoContenido()` extrae hechos del brief (precios, horarios,
ciudad, teléfono, enumeraciones) y decide qué secciones lleva la página
según el vertical detectado (saas/ecommerce/restaurante/local/…) — pero
nadie en el demo lo invocaba. La corrección de v4.7 arregló el motor
real; el atajo de demo del Estudio nunca se enteró.

### La corrección

`src/lib/prism/forja-pagina-demo.ts` (nuevo): `paginaCompletaDesdeMensaje()`
llama a `motor.construirPlanoContenido(mensaje)` y renderiza CADA sección
del plano (nav, hero, prueba social, oferta, cómo funciona, detalle,
equipo, testimonios, precios, FAQ, ubicación, cierre, pie) con contenido
real cuando el brief lo trae (precios, horarios, ciudad, teléfono) y con
un banco de textos variados por vertical cuando no — nunca un dato que
parezca real e inventado: los huecos sin dato quedan marcados
`[DATO DEMO]`, tal como exige el propio plano de contenido. Usa
`svgIcono()`/`figuraPlaceholder()` de `iconos.ts` para no caer en emoji
como icono. `ficha-tab.tsx` pierde `maquetaDesdeTokens()` y sus 3
funciones auxiliares (código muerto tras el cambio).

Primera versión tenía un bug propio: pedir más ítems de los que había en
el banco de copy producía texto LITERALMENTE repetido («Cuéntanos qué
necesitas» dos veces en «Cómo funciona», tres testimonios duplicados).
`tomar()` dejó de dar la vuelta al array — entrega los que hay y ya, una
sección con menos piezas es mejor que una con dos frases idénticas. Los
pasos de «Cómo funciona» y los roles de «Quién está detrás» se acotan a
un tamaño natural (el propio catálogo de secciones del motor documenta
«3-5 pasos», no 6+) en vez de forzar el mínimo del nivel de detalle.

### Un bug real en el motor, encontrado al probar con datos reales

Con un brief de SaaS («planes desde 29€/mes y 79€/mes») ningún precio se
extraía. `RX_PRECIO` en `plano-contenido.ts` exigía un `\b` final tras el
símbolo de moneda — pero `\b` nunca casa entre dos caracteres NO
alfanuméricos, y en «29€/mes» el `€` va seguido de `/`. La rama
número+símbolo nunca pudo casar el formato de precio por periodo más
común en español («…€/mes», «…€/año»). Separada la alternancia: la rama
de símbolo ya no exige `\b` final (el símbolo delimita por sí solo), la
rama de palabra (`euros`, `usd`…) sigue exigiéndolo. Verificado con el
propio `verificacion-v47.mjs` del módulo (95/95) y con un caso real
(«29€/mes y 79€/mes» → ambos precios extraídos, sin falsos positivos en
«100usdmensual» pegado dentro de una palabra).

### Verificado de extremo a extremo con navegador real

Dos briefs distintos contra `npm start` con Playwright: panadería
(«7 a 20h» → sección «Dónde estamos» con el horario real; vertical
`local` detectado → 10 secciones) y SaaS con dos precios («29€/mes»,
«79€/mes» → sección «Precios» con ambos planes reales; vertical `saas`
detectado → 11 secciones, incluye la sección de precios que la panadería
no lleva). Antes: 2.366 caracteres de HTML, 3 tarjetas gemelas, ignoraba
el brief entero. Ahora: ~18-20k caracteres, 10-11 secciones reales, sin
texto duplicado, con los hechos del brief cuando existen y `[DEMO]`
explícito cuando no. Sigue sin llamar a ningún proveedor de IA: 100%
determinista, coste cero, tal como pide el propio módulo — lo que
cambió es que ahora usa TODO lo que el motor ya traía, no solo el tema
de color.

### Puerta

- ✓ lint · ✓ tsc limpio (`motor-forja` fuera de `include`, sin cambios)
- ✓ **1 945** unitarios sin regresiones
- ✓ `verificacion-v47.mjs` del módulo: 95/95 (incluida la extracción de
  precios corregida)
- ✓ build · smoke test con `npm start`: dos briefs distintos generados
  con Chromium real, capturas y HTML resultante revisados a mano

## v4.25.1 — El logo del README no era el de la app, y dos archivos huérfanos

El usuario avisó tras el merge: «no se cambiaron los logos, sigue el logo
viejo, y elimina archivos innecesarios». Revisado dónde vive cada logo:

- **`public/logo.svg`** (el que muestra la cabecera de `README.md`) no era
  el prisma violeta→cian→rosa actual (`public/icons/prism-icon.svg`,
  `logo.tsx`): era un icono cuadrado con una «Z» blanca, de una entrega muy
  anterior a Forja Lab e incluso a la marca «Forja IA» (`git log` lo sitúa
  en `1e324ec`, sin relación con este trabajo). Nadie lo había tocado en
  el rebrand a Prism AI porque en el propio código de la app nadie lo
  referencia — solo lo veía quien abriera el README en GitHub.
  Reemplazado su contenido por el mismo SVG que ya usan el favicon y el
  icono de instalación, así README y app enseñan el mismo logo.
- Dos archivos que sí llegaron con la integración del Forja Lab y no los
  usa nada: `public/panel-v42.html` y `public/FORJA-IA-Laboratorio.html`
  (páginas de demo aisladas, sin ningún enlace desde la app real —
  comprobado con grep en `src/`) seguían con el texto «FORJA IA» y su
  paleta naranja, y `panel-v42.html` era el único sitio que apuntaba al
  `logo.svg` viejo. Eliminados. `public/icons/forja-icon.svg` (añadido en
  la integración, nunca referenciado desde `layout.tsx` ni el manifest)
  también fuera.

### Puerta

- ✓ lint · ✓ tsc limpio
- ✓ **1 945** unitarios sin regresiones
- ✓ build OK

## v4.26.0 — Rebrand completo: Prism AI vuelve a ser Forja IA

El usuario renombró el repositorio de GitHub a `FORJA-IA` y avisó que la
app seguía enseñando "Prism" y el logo viejo en varios sitios. Aquí se
entiende por qué: yo había asumido que "Prism AI" era la marca definitiva
y descarté como "revert" todo lo que el ZIP de Forja Lab traía con la
marca "Forja IA" — al revés de lo que el usuario quería. Confirmado con
él explícitamente (todo el texto visible Y el código interno, con el
yunque naranja original del ZIP como logo), se deshace el rebrand a Prism
en toda la app.

### Qué cambió

- **Texto**: reemplazo mecánico de "Prism AI" → "Forja IA" y "Prism"
  suelto → "Forja" en `src/`, `tests/`, `docs/`, `scripts/`, `README.md`,
  `public/manifest.json`, `.env.example`, `Dockerfile`, `setup.sh/.bat`,
  `assets/prism-fx.css`, `public/sw.js` — con cuidado de NO tocar
  `usePrism` (el hook de Zustand), las clases CSS `prism-gradient-*` /
  `prism-violet` (identificadores internos, cero coste de renombrar mal y
  cero beneficio visible) ni las rutas `src/lib/prism/` /
  `src/components/prism/` (así se organizaba el código incluso en la
  Forja IA original, antes de existir "Prism" como marca — renombrar
  carpetas aquí es un refactor invasivo sin beneficio para el usuario).
- **Logo**: `logo.tsx` recupera el `ForjaLogo` original del ZIP (el
  yunque con la chispa, degradado durazno→naranja) en vez del triángulo
  violeta. Iconos PWA/favicon regenerados desde el kit de marca del ZIP
  (`motor-forja/marca/`) — ya venían pre-renderizados, no hizo falta
  `cairosvg`.
- **Acento de color**: la app ya tenía un sistema de temas de acento
  (`accent.ts`, 6 presets) con un preset "naranja" (`#f97316`) que
  coincide casi exacto con el naranja del yunque. Se cambió
  `ACCENT_DEFAULT` y `DEFAULT_SETTINGS.accent` de "violeta" a "naranja",
  y los valores por defecto en `:root`/`.dark` de `globals.css` (antes
  oklch violeta) para que no haya un parpadeo violeta antes de que el
  JS aplique el acento — con una regla `html[data-accent="violeta"]`
  nueva para que quien lo prefiera lo siga teniendo disponible.
- **`Prism <span>AI</span>`** en el encabezado de la barra lateral y
  onboarding: el reemplazo mecánico no lo pilló (el texto va partido en
  dos nodos JSX) — corregido a mano a "Forja **IA**" (orden del acrónimo
  en español).

### Lo que se protegió a propósito (riesgo de pérdida de datos)

- **`"prism-ai-v1"`** (la clave de `localStorage` donde vive TODO el
  estado persistido: sesiones, ajustes, proveedores) y `"prism-vault-v1"`
  (bóveda cifrada de claves API) NO se tocan. Renombrar la clave habría
  hecho que la app dejara de encontrar los datos de quien ya la usaba —
  no es una cuestión de marca, es continuidad de datos reales.
- El marcador `app: "prism-ai"` de los backups exportados (`exportData`/
  `importData` en `store.ts`) pasa a escribirse como `"forja-ia"`, pero
  `importData` sigue aceptando también `"prism-ai"` para no romper la
  importación de una copia de seguridad ya guardada de una versión
  anterior.
- `PRISM_ACCESS_CODE` (variable de entorno real, configurable en
  Vercel/VPS) se deja igual: cambiar el nombre sin poder migrar la
  variable ya puesta en el despliegue real del usuario habría desactivado
  su proxy en producción sin aviso. Si en algún momento quiere
  renombrarla también, hay que coordinarlo con el valor que tenga puesto
  donde despliega.
- `NEXT_PUBLIC_PRISM_VERSION/COMMIT/BUILT` sí se renombraron a
  `NEXT_PUBLIC_FORJA_*`: estas las genera `next.config.ts` en cada build,
  no las configura el usuario a mano en ningún sitio — cero riesgo.

### Verificado

Con navegador real (Playwright) contra `npm start`: sidebar con el
yunque, "Forja IA" y el acento naranja en el botón de nueva conversación,
las insignias y el footer con la versión — capturas revisadas a mano. La
sesión anterior del usuario (persistida en `prism-ai-v1`, sin tocar)
seguía ahí intacta tras el cambio, confirmando que la protección del
storage funcionó.

### Puerta

- ✓ lint · ✓ tsc limpio
- ✓ **1 945** unitarios sin regresiones (los textos "Forja IA" en headers
  de test y aserciones de contenido cambiaron juntos, así que siguen
  casando)
- ✓ build OK · smoke test visual con navegador real
