import {  expect, test  } from "./fixtures";
import { readFile } from "node:fs/promises";

/** La vista previa pinta el HTML, pero una respuesta puede traer un proyecto
 * entero. Antes, «descargar» bajaba solo lo pintado y el resto —styles.css,
 * app.js— se quedaba en el chat para copiarlo a mano bloque por bloque.
 *
 * Aquí se comprueba de verdad: se descarga el ZIP y se mira dentro. */

const RESPUESTA = [
  "Aquí tienes la página:",
  "",
  "**index.html**",
  "```html",
  '<!doctype html><html><head><link rel="stylesheet" href="styles.css"></head>',
  '<body><h1>Cafetería</h1><div id="productos"></div><script src="app.js"></script></body></html>',
  "```",
  "",
  "**styles.css**",
  "```css",
  "body { background: #001; color: #eee }",
  "```",
  "",
  "**app.js**",
  "```js",
  "document.getElementById('productos').textContent = 'Auriculares · 49\u20ac';",
  "```",
].join("\n");

async function seed(page: import("@playwright/test").Page) {
  await page.addInitScript((respuesta) => {
    localStorage.setItem(
      "forja-ai-v1",
      JSON.stringify({
        state: {
          sessions: [
            {
              id: "s1",
              title: "Cafetería de especialidad",
              createdAt: 1,
              updatedAt: 2,
              messages: [
                { id: "u1", role: "user", content: "Hazme una página", createdAt: 1 },
                { id: "a1", role: "assistant", content: respuesta, createdAt: 2 },
              ],
            },
          ],
          activeSessionId: "s1",
          onboardingDone: true,
          favorites: [],
          radarSeenIds: [],
          settings: {
            defaultModelKey: "custom::mock-mini-free",
            systemPrompt: "x",
            temperature: 0.7,
            maxTokens: null,
            stream: true,
            contextWindow: 10,
            sendKeyOnProxy: true,
            onlyFree: false,
            agentMode: false,
            agentMaxLoops: 3,
            accent: "violeta",
            accentCustom: "#8b5cf6",
            autoSpeak: false,
            accessCode: "",
          },
          providers: {
            custom: {
              apiKey: "k",
              baseUrl: "/api/mock-llm",
              enabled: true,
              models: ["mock-mini-free"],
              useProxy: false,
            },
          },
          version: 1,
        },
        version: 0,
      })
    );
  }, RESPUESTA);
}

test("la vista previa pinta la página ENTERA, con su CSS y su JS", async ({ page }) => {
  await seed(page);
  await page.goto("/");

  const marco = page.frameLocator('iframe[title="Vista previa de la página generada"]');
  // el h1 está en el HTML: eso ya se veía antes
  await expect(marco.locator("h1")).toHaveText("Cafetería", { timeout: 30_000 });

  // esto NO se veía: lo pinta app.js, que dentro del iframe no existía como archivo
  await expect(marco.locator("#productos")).toHaveText("Auriculares · 49€");

  // y el CSS hermano también entra
  const fondo = await marco.locator("body").evaluate((el) => getComputedStyle(el).backgroundColor);
  expect(fondo).toBe("rgb(0, 0, 17)");
});

test("descarga el proyecto entero, no solo lo que se ve pintado", async ({ page }) => {
  await seed(page);
  await page.goto("/");

  // la vista previa se abre sola al detectar HTML en la respuesta
  const descargar = page.getByLabel("Descargar lo creado");
  await expect(descargar).toBeVisible({ timeout: 30_000 });
  await descargar.click();

  await expect(page.getByText("Esta respuesta creó 3 archivos")).toBeVisible();

  const [descarga] = await Promise.all([
    page.waitForEvent("download"),
    page.getByRole("menuitem", { name: /Descargar todo/ }).click(),
  ]);

  // el nombre sale del título de la conversación, no de una fecha suelta
  expect(descarga.suggestedFilename()).toMatch(/^cafeteria-de-especialidad-\d{4}-\d{2}-\d{2}\.zip$/);

  const ruta = await descarga.path();
  const bytes = await readFile(ruta);
  const texto = bytes.toString("latin1");
  // los nombres viajan en claro en la cabecera de cada entrada del ZIP
  expect(texto).toContain("index.html");
  expect(texto).toContain("styles.css");
  expect(texto).toContain("app.js");
  expect(bytes.subarray(0, 2).toString()).toBe("PK");
});

test("un archivo suelto se puede bajar por su cuenta", async ({ page }) => {
  await seed(page);
  await page.goto("/");

  await page.getByLabel("Descargar lo creado").click();
  const [descarga] = await Promise.all([
    page.waitForEvent("download"),
    page.getByRole("menuitem", { name: "styles.css" }).click(),
  ]);
  expect(descarga.suggestedFilename()).toBe("styles.css");
  const contenido = await readFile(await descarga.path(), "utf8");
  expect(contenido).toContain("background: #001");
});


/* ------------------------------------------------------------------ */
/* la vista previa en el móvil                                        */
/* ------------------------------------------------------------------ */

test.describe("en el móvil la vista previa no parte la pantalla", () => {
  test.use({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });

  test("el chat se queda entero y hay un botón que lleva al diseño", async ({ page }) => {
    await seed(page);
    await page.goto("/");

    const chat = page.getByRole("main");
    await expect(chat).toBeVisible({ timeout: 30_000 });

    // el chat ocupa el ancho: antes ResizablePanelGroup lo dejaba en ~195 px
    const anchoChat = (await chat.boundingBox())!.width;
    expect(anchoChat).toBeGreaterThan(340);

    // y la vista previa NO está partiendo la pantalla al lado
    await expect(page.getByTitle("Descargar .html")).toHaveCount(0);

    // el botón dice lo que hace, no es un icono suelto entre otros cinco
    const verDiseno = page.getByRole("button", { name: /Ver el diseño a pantalla completa/i });
    await expect(verDiseno).toBeVisible();
    await expect(verDiseno).toContainText("Ver diseño");

    await verDiseno.click();

    // y se abre ocupando el teléfono entero
    const hoja = page.getByRole("dialog");
    await expect(hoja).toBeVisible();
    await expect
      .poll(async () => {
        const c = await hoja.boundingBox();
        return c && { x: Math.round(c.x), w: Math.round(c.width) };
      })
      .toEqual({ x: 0, w: 390 });

    // con la página generada dentro y su descarga a mano
    await expect(hoja.getByTitle("Vista previa de la página generada")).toBeVisible();
    await expect(hoja.getByLabel("Descargar lo creado")).toBeVisible();
  });
});
