/** Forja IA — Sandbox: ejecuta proyectos web estáticos (estilo Spck).
 * Del ZIP o del Repo Studio se construye un HTML autocontenido:
 *  - <link rel=stylesheet> locales → <style> inline (con @import y url() reescritos)
 *  - <script src> locales → inline (clásicos)
 *  - imágenes/audio/vídeo locales → data URLs
 *  - se inyecta un puente de consola (postMessage) para ver logs y errores
 * El resultado se ejecuta en un iframe sandbox SIN same-origin: tu app y tus
 * claves están siempre aisladas del proyecto ejecutado.
 */

import {
  buildModuleGraph,
  importMapTag,
  rewriteSpecifiers,
  MODULE_SCHEME,
} from "./sandbox-modules";

export const SANDBOX_ORIGIN = "forja-sandbox";

/** Semilla: archivos de texto (p. ej. desde Repo Studio) para abrir el Sandbox con contenido. */
export interface SandboxSeed {
  name: string;
  files: { path: string; content: string }[];
}

/** Proyecto listo para publicar: bytes crudos, para que los binarios sobrevivan
 * al viaje del Sandbox a GitHub. */
export interface PublishSeed {
  name: string;
  files: { path: string; data: Uint8Array }[];
}

export interface RunBuildResult {
  html: string;
  entryPath: string;
  missing: string[];
  inlined: number;
  /** módulos ES incluidos en el import map (0 = el proyecto no usa módulos) */
  modules: number;
  /** paquetes de npm importados que el Sandbox no puede resolver */
  bareImports: string[];
  /** Peso del proyecto: el HTML ya empaquetado (CSS, JS e imágenes dentro)
   * pero ANTES del puente de consola que Forja inyecta para poder observarlo.
   * Es lo que el usuario se llevaría al exportar, y por tanto lo único que
   * tiene sentido enseñarle como «peso». `html.length` incluye ~1,8 KB de
   * instrumentación que no es suya y que no puede bajar. */
  htmlBytes: number;
}

/* Qué se trata como texto. Además de lo que el Sandbox ejecuta (web), están
 * los lenguajes que la gente trae para que se los revisen: se puede leer y
 * corregir un .py aunque el Sandbox no sepa ejecutarlo. */
const TEXT_EXT = new Set([
  "html", "htm", "css", "js", "mjs", "cjs", "json", "md", "txt", "svg", "xml",
  "csv", "ts", "tsx", "jsx", "yml", "yaml", "ini", "toml", "env", "gitignore",
  "py", "rb", "php", "java", "kt", "go", "rs", "c", "h", "cpp", "hpp", "cs",
  "swift", "sh", "bash", "zsh", "sql", "graphql", "vue", "svelte", "astro",
  "scss", "sass", "less", "lock", "cfg", "conf", "properties", "gradle",
  "dockerfile", "makefile", "tsv", "log", "diff", "patch",
]);
const IMAGE_MIME: Record<string, string> = {
  png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif",
  webp: "image/webp", avif: "image/avif", svg: "image/svg+xml", ico: "image/x-icon",
  bmp: "image/bmp",
};
const AUDIO_MIME: Record<string, string> = {
  mp3: "audio/mpeg", wav: "audio/wav", ogg: "audio/ogg", m4a: "audio/mp4",
};
const VIDEO_MIME: Record<string, string> = {
  mp4: "video/mp4", webm: "video/webm", mov: "video/quicktime",
};
const MAX_ASSET = 3 * 1024 * 1024; // 3 MB por recurso inline
const MAX_INLINE = 120; // nº máximo de recursos inlineados

export function extOf(path: string): string {
  const i = path.lastIndexOf(".");
  return i < 0 ? "" : path.slice(i + 1).toLowerCase();
}

export function isTextPath(path: string): boolean {
  return TEXT_EXT.has(extOf(path));
}

export function isHtmlPath(path: string): boolean {
  const e = extOf(path);
  return e === "html" || e === "htm";
}

export function decodeText(data: Uint8Array): string {
  return new TextDecoder().decode(data);
}

export function encodeText(s: string): Uint8Array {
  return new TextEncoder().encode(s);
}

/** Resuelve «rel» respecto al DIRECTORIO base ("" = raíz del proyecto).
 * Una ruta absoluta «/x» se ancla a la raíz del proyecto (como la raíz de un sitio web). */
export function resolvePath(baseDir: string, rel: string): string {
  const base = rel.startsWith("/") ? "" : baseDir.replace(/\/+$/, "");
  rel = rel.replace(/^\/+/, "");
  const parts = base ? base.split("/") : [];
  for (const seg of rel.split("/")) {
    if (!seg || seg === ".") continue;
    if (seg === "..") parts.pop();
    else parts.push(seg);
  }
  return parts.join("/");
}

/**
 * Carpeta raíz común de un proyecto, o "" si los archivos no comparten una.
 *
 * Un ZIP casi siempre trae el sitio DENTRO de su carpeta (`mi-web/index.html`),
 * mientras que el HTML se escribió pensando en la raíz de un dominio
 * (`href="/css/estilos.css"`). Sin saber cuál es esa carpeta, esa referencia
 * apunta a `css/estilos.css`, que no existe, y la página se abre sin estilos
 * y sin scripts: el fallo que se veía como «solo carga el HTML con texto».
 *
 * Se ignoran los restos que mete macOS al comprimir (`__MACOSX/`, `._algo`):
 * si contaran, ningún ZIP hecho en un Mac tendría raíz común.
 */
export function raizComun(paths: string[]): string {
  const utiles = paths.filter(
    (p) => !p.startsWith("__MACOSX/") && !(p.split("/").pop() ?? "").startsWith("._")
  );
  if (!utiles.length) return "";
  const primera = utiles[0].split("/")[0];
  if (!utiles[0].includes("/")) return "";
  return utiles.every((p) => p.startsWith(`${primera}/`)) ? primera : "";
}

/** Normaliza quitando query/hash. Devuelve null si es externo o especial. */
export function localRef(src: string): string | null {
  const s = src.trim();
  if (!s) return null;
  if (/^(https?:)?\/\//i.test(s) || /^(data|blob|mailto|tel|javascript):/i.test(s)) return null;
  if (s.startsWith("#")) return null;
  const clean = s.split("#")[0].split("?")[0].replace(/^\.\//, "");
  return clean || null;
}

/** Elige el HTML de entrada: el preferido, si no index.html superficial, si no el más superficial. */
/** ¿Se llama `index.html` (o `.htm`), esté donde esté? */
function esIndex(path: string): boolean {
  return /^index\.html?$/i.test(path.split("/").pop() ?? "");
}

/**
 * Elige por dónde se abre un proyecto.
 *
 * Orden: **el `index.html` manda, esté en la carpeta que esté**; a igualdad, el
 * menos hondo; y a igualdad de todo, alfabético para que sea estable.
 *
 * Antes el `index.html` solo ganaba si estaba en la RAÍZ del ZIP, y casi
 * ningún ZIP es así: el «Download ZIP» de GitHub, y cualquier proyecto
 * exportado, meten todo dentro de una carpeta. En cuanto había una carpeta
 * envolviendo, la regla no se aplicaba y quedaba el desempate alfabético — o
 * sea que `mi-web/about.html` abría antes que `mi-web/index.html`, y
 * `sitio/aaa.html` antes que `sitio/index.htm`.
 */
export function pickEntryPath(paths: string[], preferred?: string | null): string | null {
  const htmls = paths.filter(isHtmlPath);
  if (!htmls.length) return null;
  if (preferred && htmls.includes(preferred)) return preferred;
  const depth = (p: string) => p.split("/").length;
  const sorted = [...htmls].sort(
    (a, b) =>
      Number(esIndex(b)) - Number(esIndex(a)) ||
      depth(a) - depth(b) ||
      a.localeCompare(b)
  );
  return sorted[0] ?? null;
}

/** ¿Este proyecto no tiene ningún HTML porque hace falta compilarlo primero
 * (Vite, Next, CRA…)? El Sandbox ejecuta el HTML/CSS/JS tal cual está, sin
 * bundler: un `package.json` con `build`/`dev` y sin ni un solo HTML es la
 * huella de un proyecto que necesita ese paso antes de poder verse aquí —
 * distinto de un proyecto roto al que de verdad le falta el index.html. */
export function pareceProyectoConBuild(paths: string[]): boolean {
  if (paths.some(isHtmlPath)) return false;
  const depth = (p: string) => p.split("/").length;
  return paths.some((p) => p.split("/").pop() === "package.json" && depth(p) <= 2);
}

function mimeFor(path: string): string | null {
  const e = extOf(path);
  return IMAGE_MIME[e] ?? AUDIO_MIME[e] ?? VIDEO_MIME[e] ?? null;
}

function toDataUrl(data: Uint8Array, mime: string): string {
  let bin = "";
  const chunk = 0x8000;
  for (let i = 0; i < data.length; i += chunk) {
    bin += String.fromCharCode(...data.subarray(i, i + chunk));
  }
  return `data:${mime};base64,${btoa(bin)}`;
}

/* ---------- resolución de recursos del proyecto ---------- */

/** Dónde acabó un recurso y su contenido, si existe. */
export interface RecursoResuelto {
  /** ruta con la que se encontró, o la literal si no se encontró */
  path: string;
  data?: Uint8Array;
}

export type Resolver = (baseDir: string, ref: string) => RecursoResuelto;

/**
 * Construye el resolutor de recursos del proyecto.
 *
 * Primero prueba la ruta tal cual la escribió el HTML. Si ahí no hay nada y el
 * proyecto vive dentro de una carpeta, lo vuelve a intentar dentro de ella:
 * es lo que arregla el `href="/css/estilos.css"` de un ZIP que trae
 * `mi-web/css/estilos.css`.
 *
 * Solo se prueban esas dos rutas, y en ese orden. Buscar por nombre de archivo
 * por todo el proyecto acertaría más veces y se equivocaría en silencio cuando
 * hay dos `estilos.css`; aquí, si no está en ninguna de las dos, se reporta
 * como ausente y el usuario lo ve.
 */
export function hacerResolver(files: Map<string, Uint8Array>, raiz: string): Resolver {
  return (baseDir, ref) => {
    const p = resolvePath(baseDir, ref);
    const d = files.get(p);
    if (d) return { path: p, data: d };
    if (raiz && !p.startsWith(`${raiz}/`)) {
      const conRaiz = `${raiz}/${p}`;
      const d2 = files.get(conRaiz);
      if (d2) return { path: conRaiz, data: d2 };
    }
    return { path: p };
  };
}

/* ---------- reescritura de CSS ---------- */

function rewriteCssUrls(css: string, baseDir: string, resolver: Resolver, res: RunBuildResult): string {
  // @import "x.css" / @import url(x.css)
  css = css.replace(/@import\s+(?:url\(\s*)?["']?([^"')]+)["']?\s*\)?\s*;/gi, (m, ref: string) => {
    const local = localRef(ref);
    if (!local) return m;
    const { path: p, data } = resolver(baseDir, local);
    if (!data) {
      res.missing.push(p);
      return m;
    }
    res.inlined++;
    if (res.inlined > MAX_INLINE) return m;
    const inner = decodeText(data);
    const nested = rewriteCssUrls(inner, p.includes("/") ? p.slice(0, p.lastIndexOf("/")) : "", resolver, res);
    return `/* @import ${p} */\n${nested}`;
  });
  // url(...) → data URL
  css = css.replace(/url\(\s*["']?([^"')]+)["']?\s*\)/gi, (m, ref: string) => {
    const local = localRef(ref);
    if (!local) return m;
    const { path: p, data } = resolver(baseDir, local);
    if (!data) {
      res.missing.push(p);
      return m;
    }
    const mime = mimeFor(p);
    if (!mime || data.length > MAX_ASSET) return m; // lo deja tal cual
    res.inlined++;
    return `url("${toDataUrl(data, mime)}")`;
  });
  return css;
}

/* ---------- puente de consola ---------- */

export const CONSOLE_BRIDGE = `(function(){
  var O=${JSON.stringify(SANDBOX_ORIGIN)};

  /* ——— Almacenamiento de mentira, para que la página no se muera ———

     El iframe corre SIN allow-same-origin, y tiene que seguir así: con él, la
     página generada sería del mismo origen que Forja y podría leer tus claves
     del localStorage. El precio es que ahí dentro **tocar localStorage lanza
     una excepción**.

     Y ahí estaba un fallo que parecía de otra cosa: media web generada guarda
     el tema o el estado en localStorage antes de nada. La excepción mataba el
     script en su primera línea, los addEventListener de detrás no llegaban a
     ejecutarse, y los botones se veían perfectos sin hacer nada. «Toco Ajustes
     y no entra».

     Se sustituye por uno en memoria. Dura lo que dura la vista previa —al
     recargar se vacía—, y se dice por consola una vez para que nadie crea que
     ahí se guardó algo de verdad. */
  function memoria(){
    var d={};
    return {
      getItem:function(k){return Object.prototype.hasOwnProperty.call(d,String(k))?d[String(k)]:null;},
      setItem:function(k,v){d[String(k)]=String(v);},
      removeItem:function(k){delete d[String(k)];},
      clear:function(){d={};},
      key:function(i){var ks=Object.keys(d);return i<ks.length?ks[i]:null;},
      get length(){return Object.keys(d).length;}
    };
  }
  var simulados=[];
  ['localStorage','sessionStorage'].forEach(function(n){
    var ok=false;
    try{ var s=window[n]; s.setItem('__forja__','1'); s.removeItem('__forja__'); ok=true; }catch(e){ ok=false; }
    if(!ok){
      try{ Object.defineProperty(window,n,{value:memoria(),configurable:true,writable:false}); simulados.push(n); }catch(e){}
    }
  });
  /* document.cookie también lanza en un origen opaco. Se neutraliza para que
     asignarle algo no tire la página entera. */
  try{ void document.cookie; }catch(e){
    try{
      var galletas='';
      Object.defineProperty(document,'cookie',{
        get:function(){return galletas;},
        set:function(v){galletas=galletas?galletas+'; '+v:String(v);},
        configurable:true
      });
      simulados.push('cookie');
    }catch(e2){}
  }
  function send(level,args){
    try{
      var text=Array.prototype.map.call(args,function(a){
        if(typeof a==='string')return a;
        try{return JSON.stringify(a,function(k,v){return typeof v==='function'?'ƒ':v;});}catch(e){return String(a);}
      }).join(' ');
      if(text&&text.length>2000)text=text.slice(0,2000)+'…';
      parent.postMessage({source:O,level:level,text:text},'*');
    }catch(e){}
  }
  ['log','info','warn','error','debug'].forEach(function(level){
    var orig=console[level]?console[level].bind(console):function(){};
    console[level]=function(){send(level==='debug'?'log':level,arguments);orig.apply(null,arguments);};
  });
  window.addEventListener('error',function(e){send('error',[(e.message||'Error')+(e.lineno?' (línea '+e.lineno+')':'')]);});
  window.addEventListener('unhandledrejection',function(e){send('error',['Promesa rechazada: '+((e.reason&&(e.reason.message||e.reason))||'desconocida')]);});

  /* Qué acaba de tocar el usuario. Sirve para que un error tenga contexto:
     «al pulsar Guardar» le dice al modelo dónde mirar; un stack trace suelto,
     no. Va en captura para enterarse ANTES de que el manejador reviente. */
  if(simulados.length){
    send('info',['Forja: '+simulados.join(' y ')+' simulados en memoria dentro de la vista previa (el iframe no tiene origen propio). La página funciona; lo que guardes aquí no persiste.']);
  }

  document.addEventListener('click',function(e){
    try{
      var el=e.target;
      while(el&&el!==document.body&&!(el.tagName&&/^(BUTTON|A|INPUT|SELECT|SUMMARY|LABEL)$/.test(el.tagName))&&el.getAttribute&&el.getAttribute('role')!=='button'){el=el.parentElement;}
      if(!el||el===document.body)return;
      var t=(el.innerText||el.value||el.getAttribute('aria-label')||el.title||'').replace(/\\s+/g,' ').trim();
      parent.postMessage({source:O,gesto:(t?t.slice(0,60):(el.tagName||'').toLowerCase())},'*');
    }catch(e2){}
  },true);
})();`;

/** Mete el puente de consola en un HTML ya construido.
 *
 * Sale de `buildRunHtml`, donde estaba en línea, porque la vista previa EN
 * VIVO lo necesita igual: hasta ahora, si algo reventaba mientras usabas la
 * página generada, el error moría dentro del iframe y no se enteraba nadie.
 *
 * Se inserta justo al ABRIR `<head>`, no antes de cerrarlo. Se metía al
 * final del `<head>` y medio proyecto generado trae su propio script ahí
 * dentro —típicamente para poner el tema oscuro antes del primer
 * pintado— que toca `localStorage` de verdad. Ese script vive ANTES en el
 * documento que el puente, así que corría primero, lanzaba la excepción
 * que el propio puente existe para evitar, y moría en su primera línea.
 * Yendo el puente delante de todo lo demás del `<head>`, ningún script del
 * proyecto lo adelanta.
 *
 * Idempotente: no se mete dos veces. */
export function injectConsoleBridge(html: string): string {
  if (!html || html.includes(SANDBOX_ORIGIN)) return html;
  const tag = `<script>${CONSOLE_BRIDGE}</script>`;
  if (/<head[^>]*>/i.test(html)) return html.replace(/<head[^>]*>/i, (m) => `${m}\n${tag}`);
  if (/<html[^>]*>/i.test(html)) return html.replace(/<html[^>]*>/i, (m) => `${m}\n${tag}`);
  if (/<body[^>]*>/i.test(html)) return html.replace(/<body[^>]*>/i, (m) => `${m}\n${tag}`);
  return `${tag}\n${html}`;
}

/* ---------- construcción del HTML ejecutable ---------- */

function attrRegex(tag: string, attr: string): RegExp {
  return new RegExp(`<${tag}\\b[^>]*\\b${attr}\\s*=\\s*["']([^"']*)["'][^>]*>`, "gi");
}

/** Elemento <script src="…"> completo, incluido su </script> de cierre: al
 * inlinear hay que sustituirlo entero o queda un cierre huérfano. */
const SCRIPT_ELEMENT = /(<script\b[^>]*\bsrc\s*=\s*["']([^"']*)["'][^>]*>)\s*<\/script\s*>/gi;

export function buildRunHtml(
  entryPath: string,
  files: Map<string, Uint8Array>
): RunBuildResult {
  const res: RunBuildResult = {
    html: "",
    entryPath,
    missing: [],
    inlined: 0,
    modules: 0,
    bareImports: [],
    htmlBytes: 0,
  };
  const entryData = files.get(entryPath);
  if (!entryData) {
    res.html =
      '<!doctype html><meta charset="utf-8"><body style="font-family:system-ui;padding:2rem">' +
      "<h2>No se encontró la entrada</h2><p>El archivo de entrada desapareció del proyecto.</p></body>";
    res.htmlBytes = res.html.length;
    return res;
  }
  const dirOf = (p: string) => (p.includes("/") ? p.slice(0, p.lastIndexOf("/")) : "");
  // Los recursos se buscan con el resolutor, que conoce la carpeta raíz del
  // proyecto: sin eso, un ZIP con carpeta y rutas absolutas se abre pelado.
  const resolver = hacerResolver(files, raizComun([...files.keys()]));

  let html = decodeText(entryData);
  const baseDir = dirOf(entryPath);

  // Grafo de módulos ES del proyecto: hace falta antes de tocar los <script>.
  // Los <script type="module" src> del HTML son las raíces del recorrido.
  const moduleRoots: string[] = [];
  for (const m of html.matchAll(SCRIPT_ELEMENT)) {
    if (!/\btype\s*=\s*["']module["']/i.test(m[1])) continue;
    const local = localRef(m[2]);
    if (local) moduleRoots.push(resolver(baseDir, local).path);
  }
  const graph = buildModuleGraph(files, moduleRoots);
  res.modules = graph.count;
  res.bareImports = [...graph.bare];
  res.missing.push(...graph.missing);

  // 1) <img>/<source>/<video>/<audio>/<track> src|poster → data URL.
  //    Va primero: así el barrido no vuelve a pasar por el CSS y el JS que se
  //    inlinean después (una cadena «src=...» dentro de un script no es un recurso).
  html = html.replace(
    /\b(src|poster)\s*=\s*["']([^"']+)["']/gi,
    (m, attrName: string, ref: string) => {
      const local = localRef(ref);
      if (!local) return m;
      const { path: p, data } = resolver(baseDir, local);
      if (!data) {
        res.missing.push(p); // recurso local que no está en el proyecto
        return m;
      }
      const mime = mimeFor(p);
      if (!mime || data.length > MAX_ASSET) return m; // existe pero no se inlinea
      res.inlined++;
      return `${attrName}="${toDataUrl(data, mime)}"`;
    }
  );

  // 2) <link rel=stylesheet href=local> → <style>
  html = html.replace(attrRegex("link", "href"), (tag, ref: string) => {
    const lower = tag.toLowerCase();
    if (!/rel\s*=\s*["']?stylesheet/i.test(lower)) return tag;
    const local = localRef(ref);
    if (!local) return tag;
    const { path: p, data } = resolver(baseDir, local);
    if (!data) {
      res.missing.push(p);
      return tag;
    }
    res.inlined++;
    if (res.inlined > MAX_INLINE) return tag;
    const css = rewriteCssUrls(decodeText(data), dirOf(p), resolver, res);
    return `<style data-forja-from="${p}">\n${css}\n</style>`;
  });

  // 3) <script src=local> → inline
  html = html.replace(SCRIPT_ELEMENT, (whole, tag: string, ref: string) => {
    const local = localRef(ref);
    if (!local) return whole;
    const { path: p, data } = resolver(baseDir, local);
    if (!data) {
      res.missing.push(p);
      return whole;
    }
    res.inlined++;
    if (res.inlined > MAX_INLINE) return whole;
    const typeMatch = tag.match(/\btype\s*=\s*["']([^"']*)["']/i);
    const typeAttr = typeMatch ? ` type="${typeMatch[1]}"` : "";
    // Un módulo no se pega en línea: se pide por su especificador del import map,
    // para que sus propios import relativos sigan resolviéndose.
    if (/\bmodule\b/i.test(typeMatch?.[1] ?? "") && graph.count) {
      return `<script type="module" data-forja-from="${p}">\nimport ${JSON.stringify(MODULE_SCHEME + p)};\n</script>`;
    }
    // «</script>» dentro del código cerraría la etiqueta antes de tiempo
    const code = decodeText(data).replace(/<\/script/gi, "<\\/script");
    return `<script${typeAttr} data-forja-from="${p}">\n${code}\n</script>`;
  });

  // 3 bis) módulos escritos directamente en el HTML: se reescriben sus imports
  html = html.replace(
    /(<script\b[^>]*\btype\s*=\s*["']module["'][^>]*>)([\s\S]*?)(<\/script\s*>)/gi,
    (whole, open: string, body: string, close: string) => {
      if (/\bdata-forja-from=/.test(open) || !body.trim()) return whole;
      const next = rewriteSpecifiers(
        entryPath,
        body,
        (q) => files.has(q),
        (target) => res.missing.push(target),
        (spec) => res.bareImports.push(spec)
      );
      return `${open}${next}${close}`;
    }
  );

  // 4) el import map debe ir antes de que se cargue el primer módulo
  const mapTag = importMapTag(graph);
  if (mapTag) {
    if (/<head[^>]*>/i.test(html)) {
      html = html.replace(/<head[^>]*>/i, (m) => `${m}\n${mapTag}`);
    } else if (/<html[^>]*>/i.test(html)) {
      html = html.replace(/<html[^>]*>/i, (m) => `${m}\n${mapTag}`);
    } else {
      html = `${mapTag}\n${html}`;
    }
  }

  // El peso se apunta AQUÍ, con el proyecto ya empaquetado y antes de que
  // Forja le meta nada suyo. Medirlo después contaba como peso de la página
  // los kilobytes del puente de consola, que no salen de aquí.
  res.htmlBytes = html.length;

  // 5) inyección del puente de consola
  html = injectConsoleBridge(html);

  res.html = html;
  res.missing = [...new Set(res.missing)];
  res.bareImports = [...new Set(res.bareImports)];
  return res;
}

/** Filtra basura típica de ZIPs (macOS, metadatos) */
export function isJunkPath(path: string): boolean {
  return path.startsWith("__MACOSX/") || /(^|\/)\.DS_Store$/i.test(path);
}

/* ---------- navegación por el proyecto ---------- */

/** Nodo del árbol de archivos que se pinta en el panel izquierdo del Sandbox. */
export interface TreeNode {
  /** nombre visible (solo el último segmento) */
  name: string;
  /** ruta completa; en las carpetas, sin barra final */
  path: string;
  dir: boolean;
  /** solo en carpetas: hijos ya ordenados (carpetas primero, luego alfabético) */
  children: TreeNode[];
  /** solo en carpetas: nº de archivos que contiene, incluidos los de subcarpetas */
  count: number;
}

/** Construye el árbol de carpetas a partir de la lista plana de rutas. */
export function buildTree(paths: string[]): TreeNode[] {
  const root: TreeNode = { name: "", path: "", dir: true, children: [], count: 0 };
  const dirs = new Map<string, TreeNode>([["", root]]);

  const dirNode = (path: string): TreeNode => {
    const existing = dirs.get(path);
    if (existing) return existing;
    const idx = path.lastIndexOf("/");
    const parent = dirNode(idx < 0 ? "" : path.slice(0, idx));
    const node: TreeNode = {
      name: idx < 0 ? path : path.slice(idx + 1),
      path,
      dir: true,
      children: [],
      count: 0,
    };
    parent.children.push(node);
    dirs.set(path, node);
    return node;
  };

  for (const p of [...paths].sort()) {
    const idx = p.lastIndexOf("/");
    const parent = dirNode(idx < 0 ? "" : p.slice(0, idx));
    parent.children.push({
      name: idx < 0 ? p : p.slice(idx + 1),
      path: p,
      dir: false,
      children: [],
      count: 0,
    });
  }

  const finish = (node: TreeNode): number => {
    node.children.sort((a, b) => Number(b.dir) - Number(a.dir) || a.name.localeCompare(b.name));
    node.count = node.children.reduce((n, c) => n + (c.dir ? finish(c) : 1), 0);
    return node.count;
  };
  finish(root);
  return root.children;
}

/** Rutas de todas las carpetas que contienen a «path» (para desplegar el árbol). */
export function ancestorDirs(path: string): string[] {
  const parts = path.split("/");
  parts.pop();
  const out: string[] = [];
  let acc = "";
  for (const p of parts) {
    acc = acc ? `${acc}/${p}` : p;
    out.push(acc);
  }
  return out;
}
