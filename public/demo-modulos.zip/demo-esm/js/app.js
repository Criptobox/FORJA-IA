import { saludo } from "./saludo.js";
import { suma } from "./mat/index.js";

document.getElementById("titulo").textContent = saludo("módulos ES");
document.getElementById("suma").textContent = `2 + 3 = ${suma(2, 3)}`;
console.log("app.js con módulos ES cargado");
