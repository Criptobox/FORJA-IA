import { MARCA } from "./mat/constantes.js";
export const saludo = (que) => `Funcionan los ${que} — ${MARCA}`;
