# Demo con módulos ES

Proyecto de ejemplo que reparte el código en módulos que se importan entre sí:

- `js/app.js` — entrada (`<script type="module">`)
- `js/saludo.js` — importa una constante de otra carpeta
- `js/mat/index.js` — reexporta desde `ops.js`
- `js/mat/ops.js`, `js/mat/constantes.js`

El Sandbox lo ejecuta sin empaquetador ni `npm install`: reescribe los
especificadores y los sirve por un import map.
